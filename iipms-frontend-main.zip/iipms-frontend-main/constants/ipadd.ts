// const ipfront = "http://192.168.137.1:5001";
const ipfront = "https://iipms-backend.onrender.com";

// const ipfront = "http://localhost:5001";
// const ipfront = "https://attendance.intellisurgetechnologies.com";
export default ipfront;