const mongoose = require('mongoose');

const timesheetSchema = new mongoose.Schema({
  employeeId: { type: String, required: true },
  projectName: { type: String, required: true },
  activityName: { type: String, required: true },
  weekStartDate: { type: Date, required: true },
  hours: [{ type: String }],
  loginTimes: [{ type: String }],
  logoutTimes: [{ type: String }],
  createdAt: {
    type: Date,
    defautlt: Date.now()
  },
});

module.exports = mongoose.model('Timesheet', timesheetSchema);
