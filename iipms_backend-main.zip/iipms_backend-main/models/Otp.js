const mongoose = require('mongoose');

const otpSchema = new mongoose.Schema({
  email: { type: String, required: true },
  otp: { type: String, required: true },
  expires: { type: Date, required: true },
  ipAddress: { type: String },
  createdAt: {
    type: Date,
    default: () => require('moment-timezone')().tz('Asia/Kolkata').toDate(),
  },
});

module.exports = mongoose.model('OTP', otpSchema);