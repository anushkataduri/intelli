const mongoose = require('mongoose');

const taskSchema = new mongoose.Schema({
  employeeId: { type: String, required: true },
  projectName: { type: String, required: true, trim: true },
  activityName: { type: String, required: true, trim: true },
  taskDescription: { type: String, trim: true },
  percentComplete: { type: String, default: '0', trim: true },
  assignedBy: { type: String, trim: true },
  createdAt: { type: Date, default: Date.now },
});

const Task = mongoose.model('Task', taskSchema);

module.exports = Task;

// const mongoose = require('mongoose');

// const taskSchema = new mongoose.Schema({
//   employeeId: { type: String, required: true },
//   projectName: { type: String, required: true },
//   activityName: { type: String, required: true },
//   taskDescription: { type: String },
//   percentComplete: { type: Number, default: 0 },
//   assignedBy: { type: String },
//   status: { type: String, enum: ['Pending', 'Approved', 'Rejected'], default: 'Pending' },
//   createdAt: {
//     type: Date,
//     default: () => require('moment-timezone')().tz('Asia/Kolkata').toDate(),
//   },
// });

// module.exports = mongoose.model('Task', taskSchema);
