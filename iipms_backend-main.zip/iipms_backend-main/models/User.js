const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  employeeId: { type: String, required: true, unique: true },
  initial: { type: String, required: true },
  name: { type: String, required: true },
  role: { type: String, required: true },
  department: { type: String, required: true },
  roleType: { type: String, enum: ['Employee', 'Manager', 'Admin'], required: true },
  phoneNo: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  managerId: { type: String, default: null },
  assignedEmployees: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  address: { type: String },
  createdAt: {
    type: Date,
    default: () => require('moment-timezone')().tz('Asia/Kolkata').toDate(),
  },
});

module.exports = mongoose.model('User', userSchema);