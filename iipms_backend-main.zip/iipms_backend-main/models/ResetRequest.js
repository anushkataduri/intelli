const mongoose = require('mongoose');

const resetRequestSchema = new mongoose.Schema({
  email: { type: String, required: true },
  token: { type: String, required: true },
  expires: { type: Date, required: true },
  createdAt: {
    type: Date,
    default: () => require('moment-timezone')().tz('Asia/Kolkata').toDate(),
  },
});

module.exports = mongoose.model('ResetRequest', resetRequestSchema);