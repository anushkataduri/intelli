// require('dotenv').config();
// const express = require('express');
// const mongoose = require('mongoose');
// const bcrypt = require('bcryptjs');
// const { v4: uuid4 } = require('uuid');
// const jwt = require('jsonwebtoken');
// const { v4: uuidv4 } = require('uuid');
// const nodemailer = require('nodemailer');
// const http = require('http');
// const { Server } = require('socket.io');
// const User = require('./models/User');
// const Task = require('./models/Task');
// const Timesheet = require('./models/Timesheet');
// const Assignment = require('./models/Assignment');
// const LeaveRequest = require('./models/LeaveRequest');

// const app = express();
// const PORT = process.env.PORT || 5001;

// // Create HTTP server for Socket.IO
// const server = http.createServer(app);
// const io = new Server(server, {
//   cors: {
//     origin: process.env.APP_URL,
//     methods: ['GET', 'POST'],
//   },
// });


// // Middleware to parse JSON bodies
// app.use(express.json());

// // Connect to MongoDB
// mongoose.connect(process.env.MONGO_URI, {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// })
// .then(() => console.log('Connected to MongoDB'))
// .catch((error) => console.error('MongoDB connection error:', error));

// // Configure Nodemailer (using Gmail configuration)
// const transporter = nodemailer.createTransport({
//   service: 'gmail',
//   auth: {
//     user: process.env.EMAIL_USER,
//     pass: process.env.EMAIL_PASS,
//   },
// });





// // Health Check Endpoint
// app.get('/api/health', async (req, res) => {
//   try {
//     // Check MongoDB connection status
//     const mongoStatus = mongoose.connection.readyState === 1 ? 'Connected' : 'Disconnected';
//     const serverStartTime = new Date().toLocaleString();

//     // HTML response for health check
//     const html = `
//       <!DOCTYPE html>
//       <html lang="en">
//       <head>
//         <meta charset="UTF-8">
//         <meta name="viewport" content="width=device-width, initial-scale=1.0">
//         <title>Server Health Check</title>
//         <style>
//           body {
//             font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
//             background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
//             margin: 0;
//             padding: 0;
//             display: flex;
//             justify-content: center;
//             align-items: center;
//             min-height: 100vh;
//             color: #333;
//           }
//           .container {
//             max-width: 600px;
//             background-color: #ffffff;
//             border-radius: 12px;
//             box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
//             padding: 40px;
//             text-align: center;
//             animation: fadeIn 1s ease-in-out;
//           }
//           @keyframes fadeIn {
//             from { opacity: 0; transform: translateY(-20px); }
//             to { opacity: 1; transform: translateY(0); }
//           }
//           .header {
//             margin-bottom: 20px;
//           }
//           .header h1 {
//             color: #1e3c72;
//             font-size: 32px;
//             margin: 0;
//             text-transform: uppercase;
//             letter-spacing: 1px;
//           }
//           .status-box {
//             background-color: #f4f7fc;
//             border-radius: 8px;
//             padding: 20px;
//             margin: 20px 0;
//             border: 1px solid #e0e0e0;
//           }
//           .status-box p {
//             margin: 10px 0;
//             font-size: 18px;
//             color: #333;
//           }
//           .status-success {
//             color: #28a745;
//             font-weight: bold;
//           }
//           .status-error {
//             color: #dc3545;
//             font-weight: bold;
//           }
//           .footer {
//             margin-top: 30px;
//             font-size: 14px;
//             color: #666;
//           }
//           .footer a {
//             color: #1e3c72;
//             text-decoration: none;
//             font-weight: bold;
//           }
//           .footer a:hover {
//             text-decoration: underline;
//           }
//           .icon {
//             font-size: 50px;
//             margin-bottom: 20px;
//             color: #28a745;
//           }
//           @media (max-width: 600px) {
//             .container {
//               margin: 20px;
//               padding: 20px;
//             }
//             .header h1 {
//               font-size: 24px;
//             }
//             .status-box p {
//               font-size: 16px;
//             }
//           }
//         </style>
//       </head>
//       <body>
//         <div class="container">
//           <div class="header">
//             <h1>Server Health Check</h1>
//           </div>
//           <div class="icon">✅</div>
//           <div class="status-box">
//             <p><strong>Server Status:</strong> <span class="status-success">Running</span></p>
//             <p><strong>Server Started At:</strong> ${serverStartTime}</p>
//             <p><strong>MongoDB Connection:</strong> <span class="${
//               mongoStatus === 'Connected' ? 'status-success' : 'status-error'
//             }">${mongoStatus}</span></p>
//             <p><strong>Environment:</strong> ${process.env.NODE_ENV || 'Production'}</p>
//             <p><strong>Port:</strong> ${PORT}</p>
//           </div>
//           <div class="footer">
//             <p>© 2025 Intellisurge Technologies. All Rights Reserved.</p>
//             <p><a href="${process.env.APP_URL}/dashboard">Go to Dashboard</a></p>
//           </div>
//         </div>
//       </body>
//       </html>
//     `;

//     res.status(200).send(html);
//   } catch (error) {
//     console.error('Health check error:', error);
//     res.status(500).send(`
//       <!DOCTYPE html>
//       <html lang="en">
//       <head>
//         <meta charset="UTF-8">
//         <meta name="viewport" content="width=device-width, initial-scale=1.0">
//         <title>Server Health Check</title>
//         <style>
//           body {
//             font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
//             background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
//             margin: 0;
//             padding: 0;
//             display: flex;
//             justify-content: center;
//             align-items: center;
//             min-height: 100vh;
//             color: #333;
//           }
//           .container {
//             max-width: 600px;
//             background-color: #ffffff;
//             border-radius: 12px;
//             box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
//             padding: 40px;
//             text-align: center;
//           }
//           .header h1 {
//             color: #dc3545;
//             font-size: 32px;
//             margin: 0;
//           }
//           .icon {
//             font-size: 50px;
//             margin-bottom: 20px;
//             color: #dc3545;
//           }
//           p {
//             font-size: 18px;
//             color: #333;
//             margin: 10px 0;
//           }
//           a {
//             color: #1e3c72;
//             text-decoration: none;
//             font-weight: bold;
//           }
//           a:hover {
//             text-decoration: underline;
//           }
//         </style>
//       </head>
//       <body>
//         <div class="container">
//           <div class="header">
//             <h1>Server Error</h1>
//           </div>
//           <div class="icon">❌</div>
//           <p>Server Status: <span style="color: #dc3545;">Not Running Properly</span></p>
//           <p>Error: ${error.message}</p>
//           <p><a href="${process.env.APP_URL}/dashboard">Go to Dashboard</a></p>
//         </div>
//       </body>
//       </html>
//     `);
//   }
// });






// // Email Template for Leave Requests
// const generateEmailTemplate = (leaveRequest, employeeName, recipientRole) => {
//   const { _id, employeeId, leaveType, fromDate, toDate, reason } = leaveRequest;
//   const leaveTypeFormatted = leaveType.charAt(0).toUpperCase() + leaveType.slice(1) + ' Leave';
//   let subject;
//   if (recipientRole === 'employee') {
//     subject = 'Leave Request Submitted Successfully';
//   } else if (recipientRole === 'manager') {
//     subject = `Action Required: Leave Request from ${employeeName} (${employeeId})`;
//   } else {
//     subject = `New Leave Request for Approval - ${employeeName} (${employeeId})`;
//   }

//   const html = `
//     <!DOCTYPE html>
//     <html lang="en">
//     <head lang="en">
//       <head>
//         <meta charset="UTF-8">
//         <meta name="viewport" content="width=device-width, initial-scale=1.0">
//         <title>Leave Request Notification</title>
//         <meta name="viewport" content="width=device-width, initial-scale=1.0">
//         <title>Leave Request Notification</title>
//         <style>
//           body {
//             font-family: 'Helvetica Neue', Arial, sans-serif;
//             background-color: #f4f4f4;
//             margin: 0;
//             padding: 0;
//           }
//           .container {
//             max-width: 600px;
//             margin: 20px auto;
//             background-color: #ffffff;
//             border-radius: 8px;
//             box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
//             overflow: hidden;
//           }
//           .header {
//             background-color: #003087;
//             padding: 20px;
//             text-align: center;
//             }
//           .header h1 {
//               color: #ffffff;
//               margin: 0;
//               font-size: 24px;
//             }
//           }
//           .content {
//             padding: 20px;
//             }
//           .content h2 {
//               color: #333333;
//               font-size: 20px;
//               margin-bottom: 15px;
//             }
//             }
//           .details-table {
//             width: 100%;
//             border-collapse: collapse;
//             margin-bottom: 20px;
//             }
//           .details-table th,
//           .details-table td {
//             padding: 12px;
//             text-align: left;
//             border-bottom: 1px solid #e0e0e0;
//           }
//           .details-table th {
//             background-color: #f9f9f9;
//             color: #333333;
//             width: 30%;
//             font-weight: 600;
//           }
//           .details-table td {
//             color: #555555;
//             }
//           }
//           .action-buttons {
//             margin: 20px 0;
//             text-align: center;
//             }
//           .action-buttons a {
//             display: inline-block;
//             padding: 10px 20px;
//             margin: 0 10px;
//             text-decoration: none;
//             font-weight: 600;
//             border-radius: 4px;
//             transition: background-color 0.3s;
//           }
//             .approve-btn {
//               background-color: #28a745;
//               color: #ffffff;
//             }
//             .approve-btn:hover {
//               background-color: #218838;
//             }
//             .reject-btn {
//               background-color: #dc3545;
//               color: #ffffff;
//             }
//             .reject-btn:hover {
//               background-color: #c82333;
//             }
//             .action-text {
//               color: #555555;
//               font-size: 14px;
//               margin-top: 10px;
//             }
//           }
//           .footer {
//             background-color: #003087;
//             padding: 10px;
//             text-align: center;
//             }
//           .footer p {
//             color: #ffffff;
//             margin: 0;
//             font-size: 12px;
//           }
//         </style>
//       </head>
//       <body>
//         <div class="container">
//           <div class="header">
//             <h1>Leave Request Notification</h1>
//           </div>
//           <div class="content">
//             <h2>${
//               recipientRole === 'employee'
//                 ? 'Your Leave Request Has Been Submitted'
//                 : recipientRole === 'manager'
//                 ? 'Action Required: New Leave Request'
//                 : 'New Leave Request for Approval'
//             }</h2>
//             <p>Dear ${recipientRole === 'employee' ? employeeName : recipientRole},</p>
//             <p>
//               ${
//                 recipientRole === 'employee'
//                   ? 'Thank you for submitting your leave request. It has been sent for approval. You will be notified once it is reviewed.'
//                   : `A new leave request from ${employeeName} (${employeeId}) requires your approval.`
//               }
//             </p>
//             <table class="details-table">
//               <tr>
//                 <th>Employee ID</th>
//                 <td>${employeeId}</td>
//               </tr>
//               <tr>
//                 <th>Employee Name</th>
//                 <td>${employeeName}</td>
//               </tr>
//               <tr>
//                 <th>Leave Type</th>
//                 <td>${leaveTypeFormatted}</td>
//               </tr>
//               <tr>
//                 <th>From Date</th>
//                 <td>${fromDate}</td>
//               </tr>
//               <tr>
//                 <th>To Date</th>
//                 <td>${toDate}</td>
//               </tr>
//               <tr>
//                 <th>Reason</th>
//                 <td>${reason}</td>
//               </tr>
//             </table>
//             ${
//               recipientRole === 'manager'
//                 ? `
//                   <div class="action-buttons">
//                     <a href="${process.env.APP_URL}/api/leave/update/${_id}?status=approved&token=${jwt.sign({ leaveId: _id }, process.env.JWT_SECRET, { expiresIn: '24h' })}" class="approve-btn">Approve</a>
//                     <a href="${process.env.APP_URL}/api/leave/update/${_id}?status=rejected&token=${jwt.sign({ leaveId: _id }, process.env.JWT_SECRET, { expiresIn: '24h' })}" class="reject-btn">Reject</a>
//                   </div>
//                   <p class="action-text">Click the buttons above to approve or reject the leave request directly.</p>
//                 `
//                 : recipientRole !== 'employee'
//                 ? '<p class="action-text">Please review the request and take appropriate action on your dashboard.</p>'
//                 : ''
//             }
//           </div>
//           <div class="footer">
//             <p>© 2025 Intellisurge Technologies. All Rights Reserved.</p>
//           </div>
//         </div>
//       </body>
//     </html>
//   `;

//   return { subject, html };
// };

// // WebSocket connection
// io.on('connection', (socket) => {
//   console.log('A user connected:', socket.id);

//   socket.on('join', ({ employeeId, roleType }) => {
//     socket.join(employeeId);
//     if (roleType === 'Manager') {
//       socket.join('managers');
//     }
//     console.log(`${employeeId} joined room`);
//   });

//   socket.on('disconnect', () => {
//     console.log('User disconnected:', socket.id);
//   });
// });

// // Middleware to verify JWT
// const verifyToken = (req, res, next) => {
//   const token = req.headers['authorization']?.split(' ')[1] || req.query.token;
//   if (!token) {
//     return res.status(401).json({ message: 'Token required' });
//   }
//   try {
//     const decoded = jwt.verify(token, process.env.JWT_SECRET);
//     req.user = decoded;
//     next();
//   } catch (error) {
//     res.status(401).json({ message: 'Invalid token' });
//   }
// };

// // Middleware to check if user is an admin
// const isAdmin = async (req, res, next) => {
//   try {
//     const { employeeId } = req.user;
//     const user = await User.findOne({ employeeId });
//     if (!user) {
//       return res.status(401).json({ message: 'User not found' });
//     }
//     if (user.roleType !== 'Admin') {
//       return res.status(403).json({ message: 'Access denied: Admins only' });
//     }
//     next();
//   } catch (error) {
//     console.error('Admin check error:', error);
//     res.status(500).json({ message: 'Server error during admin verification' });
//   }
// };

// // Middleware to check if user is a manager
// const isManager = async (req, res, next) => {
//   try {
//     const { employeeId, roleType } = req.user;
//     if (roleType !== 'Manager') {
//       return res.status(403).json({ message: 'Access denied: Managers only' });
//     }
//     next();
//   } catch (error) {
//     console.error('Manager check error:', error);
//     res.status(500).json({ message: 'Server error during manager verification' });
//   }
// };

// // Middleware to check if user is an employee
// const isEmployee = async (req, res, next) => {
//   try {
//     const { employeeId, roleType } = req.user;
//     if (roleType !== 'Employee') {
//       return res.status(403).json({ message: 'Access denied: Employees only' });
//     }
//     next();
//   } catch (error) {
//     console.error('Employee check error:', error);
//     res.status(500).json({ message: 'Server error during employee verification' });
//   }
// };

// // Middleware to check if user is a manager or admin
// const isManagerOrAdmin = async (req, res, next) => {
//   try {
//     const { employeeId, roleType } = req.user;
//     if (roleType !== 'Manager' && roleType !== 'Admin') {
//       return res.status(403).json({ message: 'Access denied: Managers or Admins only' });
//     }
//     next();
//   } catch (error) {
//     console.error('Manager/Admin check error:', error);
//     res.status(500).json({ message: 'Server error during manager/admin verification' });
//   }
// };

// // Registration endpoint
// // app.post('/api/register', async (req, res) => {
// //   try {
// //     const { initial, name, role, department, roleType, phoneNo, email, password } = req.body;

// //     if (!initial || !name || !role || !department || !roleType || !phoneNo || !email || !password) {
// //       return res.status(400).json({ message: 'All fields are required' });
// //     }

// //     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// //     if (!emailRegex.test(email)) {
// //       return res.status(400).json({ message: 'Invalid email format' });
// //     }

// //     const phoneRegex = /^\d{10}$/;
// //     if (!phoneRegex.test(phoneNo)) {
// //       return res.status(400).json({ message: 'Phone number must be 10 digits' });
// //     }

// //     const existingUser = await User.findOne({ email });
// //     if (existingUser) {
// //       return res.status(400).json({ message: 'Email already registered' });
// //     }

// //     let prefix;
// //     switch (roleType) {
// //       case 'Employee':
// //         prefix = 'E';
// //         break;
// //       case 'Manager':
// //         prefix = 'M';
// //         break;
// //       case 'Admin':
// //         prefix = 'A';
// //         break;
// //       default:
// //         return res.status(400).json({ message: 'Invalid role type' });
// //     }
// //     const uniqueId = uuidv4().split('-')[0];
// //     const employeeId = `${prefix}-${uniqueId}`;

// //     const saltRounds = 10;
// //     const hashedPassword = await bcrypt.hash(password, saltRounds);

// //     const newUser = new User({
// //       employeeId,
// //       initial,
// //       name,
// //       role,
// //       department,
// //       roleType,
// //       phoneNo,
// //       email,
// //       password: hashedPassword,
// //       managerId: roleType === 'Employee' ? req.body.managerId || null : null,
// //     });

// //     await newUser.save();

// //     res.status(201).json({ message: 'User registered successfully', employeeId });
// //   } catch (error) {
// //     console.error('Registration error:', error);
// //     res.status(500).json({ message: 'Server error during registration' });
// //   }
// // });


// app.post('/api/register', async (req, res) => {
//   try {
//     const { initial, name, role, department, roleType, phoneNo, email, password } = req.body;

//     if (!initial || !name || !role || !department || !roleType || !phoneNo || !email || !password) {
//       return res.status(400).json({ message: 'All fields are required' });
//     }

//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//     if (!emailRegex.test(email)) {
//       return res.status(400).json({ message: 'Invalid email format' });
//     }

//     const phoneRegex = /^\d{10}$/;
//     if (!phoneRegex.test(phoneNo)) {
//       return res.status(400).json({ message: 'Phone number must be 10 digits' });
//     }

//     const existingUser = await User.findOne({ email });
//     if (existingUser) {
//       return res.status(400).json({ message: 'Email already registered' });
//     }

//     let prefix;
//     switch (roleType) {
//       case 'Employee':
//         prefix = 'E';
//         break;
//       case 'Manager':
//         prefix = 'M';
//         break;
//       case 'Admin':
//         prefix = 'A';
//         break;
//       default:
//         return res.status(400).json({ message: 'Invalid role type' });
//     }
//     const uniqueId = uuidv4().split('-')[0];
//     const employeeId = `${prefix}-${uniqueId}`;

//     const saltRounds = 10;
//     const hashedPassword = await bcrypt.hash(password, saltRounds);

//     const newUser = new User({
//       employeeId,
//       initial,
//       name,
//       role,
//       department,
//       roleType,
//       phoneNo,
//       email,
//       password: hashedPassword,
//       managerId: roleType === 'Employee' ? req.body.managerId || null : null,
//     });

//     await newUser.save();

//     res.status(201).json({ message: 'User registered successfully', employeeId });
//   } catch (error) {
//     console.error('Registration error:', error);
//     res.status(500).json({ message: 'Server error during registration' });
//   }
// });

// // Login endpoint
// app.post('/api/login', async (req, res) => {
//   try {
//     const { email, password } = req.body;

//     if (!email || !password) {
//       return res.status(400).json({ message: 'Email and password are required' });
//     }

//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//     if (!emailRegex.test(email)) {
//       return res.status(400).json({ message: 'Invalid email format' });
//     }

//     const user = await User.findOne({ email });
//     if (!user) {
//       return res.status(401).json({ message: 'Invalid email or password' });
//     }

//     const isPasswordValid = await bcrypt.compare(password, user.password);
//     if (!isPasswordValid) {
//       return res.status(401).json({ message: 'Invalid email or password' });
//     }

//     const token = jwt.sign(
//       {
//         employeeId: user.employeeId,
//         roleType: user.roleType,
//         managerId: user.managerId || null,
//       },
//       process.env.JWT_SECRET,
//       { expiresIn: '1h' }
//     );

//     res.status(200).json({
//       message: 'Login successful',
//       roleType: user.roleType,
//       employeeId: user.employeeId,
//       token,
//       user: {
//         employeeId: user.employeeId,
//         initial: user.initial,
//         name: user.name,
//         role: user.role,
//         department: user.department,
//         roleType: user.roleType,
//         phoneNo: user.phoneNo,
//         email: user.email,
//         managerId: user.managerId || null,
//       },
//     });
//   } catch (error) {
//     console.error('Login error:', error);
//     res.status(500).json({ message: 'Server error during login' });
//   }
// });

// // Add Task endpoint
// app.post('/api/tasks', verifyToken, async (req, res) => {
//   try {
//     const { employeeId, projectName, activityName, taskDescription, percentComplete, assignedBy } = req.body;

//     if (!employeeId || !projectName || !activityName) {
//       return res.status(400).json({ message: 'Employee ID, project name, and activity name are required' });
//     }

//     const user = await User.findOne({ employeeId });
//     if (!user) {
//       return res.status(400).json({ message: 'Invalid employee ID' });
//     }

//     const newTask = new Task({
//       employeeId,
//       projectName,
//       activityName,
//       taskDescription,
//       percentComplete,
//       assignedBy,
//     });

//     await newTask.save();

//     res.status(201).json({ message: 'Task added successfully', task: newTask });
//   } catch (error) {
//     console.error('Task creation error:', error);
//     res.status(500).json({ message: 'Server error during task creation' });
//   }
// });

// // Get Tasks endpoint
// app.get('/api/tasks/:employeeId', verifyToken, async (req, res) => {
//   try {
//     const { employeeId } = req.params;

//     const tasks = await Task.find({ employeeId });

//     res.status(200).json({ tasks });
//   } catch (error) {
//     console.error('Task fetch error:', error);
//     res.status(500).json({ message: 'Server error during task retrieval' });
//   }
// });

// // Update Task Status endpoint
// app.put('/api/tasks/:taskId', verifyToken, isManager, async (req, res) => {
//   try {
//     const { taskId } = req.params;
//     const { status } = req.body;

//     if (!['Approved', 'Rejected'].includes(status)) {
//       return res.status(400).json({ message: 'Invalid status. Must be Approved or Rejected' });
//     }

//     const task = await Task.findById(taskId);
//     if (!task) {
//       return res.status(404).json({ message: 'Task not found' });
//     }

//     const manager = await User.findOne({ employeeId: req.user.employeeId });
//     if (!manager.assignedEmployees.some(emp => emp.equals(task.employeeId))) {
//       return res.status(403).json({ message: 'Task does not belong to an employee assigned to you' });
//     }

//     task.status = status;
//     await task.save();

//     res.status(200).json({ message: `Task ${status.toLowerCase()} successfully`, task });
//   } catch (error) {
//     console.error('Update task status error:', error);
//     res.status(500).json({ message: 'Server error during task status update' });
//   }
// });

// // Add/Update Timesheet endpoint
// app.post('/api/timesheet', verifyToken, async (req, res) => {
//   try {
//     const { employeeId, projectName, activityName, weekStartDate, hours, loginTimes, logoutTimes } = req.body;

//     if (!employeeId || !projectName || !activityName || !weekStartDate) {
//       return res.status(400).json({ message: 'Employee ID, project name, activity name, and week start date are required' });
//     }

//     const user = await User.findOne({ employeeId });
//     if (!user) {
//       return res.status(400).json({ message: 'Invalid employee ID' });
//     }

//     let timesheet = await Timesheet.findOne({ employeeId, projectName, activityName, weekStartDate });

//     if (timesheet) {
//       timesheet.hours = hours || timesheet.hours;
//       timesheet.loginTimes = loginTimes || timesheet.loginTimes;
//       timesheet.logoutTimes = logoutTimes || timesheet.logoutTimes;
//       await timesheet.save();
//     } else {
//       timesheet = new Timesheet({
//         employeeId,
//         projectName,
//         activityName,
//         weekStartDate,
//         hours: hours || Array(7).fill('00:00'),
//         loginTimes: loginTimes || Array(7).fill(null),
//         logoutTimes: logoutTimes || Array(7).fill(null),
//       });
//       await timesheet.save();
//     }

//     res.status(201).json({ message: 'Timesheet saved successfully', timesheet });
//   } catch (error) {
//     console.error('Timesheet save error:', error);
//     res.status(500).json({ message: 'Server error during timesheet save' });
//   }
// });

// // Get Timesheet endpoint
// app.get('/api/timesheet/:employeeId', verifyToken, async (req, res) => {
//   try {
//     const { employeeId } = req.params;

//     const timesheets = await Timesheet.find({ employeeId });

//     res.status(200).json({ timesheets });
//   } catch (error) {
//     console.error('Timesheet fetch error:', error);
//     res.status(500).json({ message: 'Server error during timesheet retrieval' });
//   }
// });

// // Get all employee details (Admin only)
// app.get('/api/admin/employees', verifyToken, isAdmin, async (req, res) => {
//   try {
//     const { page = 1, limit = 10, roleType, department } = req.query;
//     let query = {};
//     if (roleType) query.roleType = roleType;
//     if (department) query.department = department;

//     const employees = await User.find(query, { password: 0, __v: 0 })
//       .skip((page - 1) * limit)
//       .limit(parseInt(limit));
//     const total = await User.countDocuments(query);

//     res.status(200).json({
//       message: 'Employee details retrieved successfully',
//       employees,
//       total,
//       page: parseInt(page),
//       pages: Math.ceil(total / limit)
//     });
//   } catch (error) {
//     console.error('Fetch employees error:', error);
//     res.status(500).json({ message: 'Server error during employee retrieval' });
//   }
// });

// // Update employee (Admin only)
// app.put('/api/admin/employees/:employeeId', verifyToken, isAdmin, async (req, res) => {
//   try {
//     const { employeeId } = req.params;
//     const { initial, name, role, department, roleType, phoneNo, email, createdAt, address } = req.body;

//     if (!initial || !name || !role || !department || !roleType || !phoneNo || !email) {
//       return res.status(400).json({ message: 'All fields except address and createdAt are required' });
//     }

//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//     if (!emailRegex.test(email)) {
//       return res.status(400).json({ message: 'Invalid email format' });
//     }

//     const phoneRegex = /^\d{10}$/;
//     if (!phoneNo || !phoneRegex.test(phoneNo)) {
//       return res.status(400).json({ message: 'Phone number must be 10 digits' });
//     }

//     const prefix = roleType === 'Employee' ? 'E' : roleType === 'Manager' ? 'M' : 'A';
//     if (!employeeId.startsWith(prefix)) {
//       return res.status(400).json({ message: `Employee ID must start with '${prefix}'` });
//     }

//     const existingUser = await User.findOne({ email, employeeId: { $ne: employeeId } });
//     if (existingUser) {
//       return res.status(400).json({ message: 'Email already registered' });
//     }

//     const updatedUser = await User.findOneAndUpdate(
//       { employeeId },
//       { initial, name, role, department, roleType, phoneNo, email, address, createdAt: createdAt ? new Date(createdAt) : undefined },
//       { new: true, runValidators: true, select: '-password -__v' }
//     );

//     if (!updatedUser) {
//       return res.status(404).json({ message: 'Employee not found' });
//     }

//     res.status(200).json({ message: 'Employee updated successfully', employee: updatedUser });
//   } catch (error) {
//     console.error('Update employee error:', error);
//     res.status(500).json({ message: 'Server error during employee update' });
//   }
// });

// // Delete employee (Admin only)
// app.delete('/api/admin/employees/:employeeId', verifyToken, isAdmin, async (req, res) => {
//   try {
//     const { employeeId } = req.params;

//     const deletedUser = await User.findOneAndDelete({ employeeId });
//     if (!deletedUser) {
//       return res.status(404).json({ message: 'Employee not found' });
//     }

//     await Task.deleteMany({ employeeId });
//     await Timesheet.deleteMany({ employeeId });
//     await Assignment.deleteMany({ $or: [{ employeeId: deletedUser._id }, { managerId: employeeId }] });
//     await LeaveRequest.deleteMany({ employeeId });

//     res.status(200).json({ message: 'Employee deleted successfully' });
//   } catch (error) {
//     console.error('Delete employee error:', error);
//     res.status(500).json({ message: 'Server error during employee deletion' });
//   }
// });

// // Assign employee to manager (Admin only)
// app.post('/api/admin/assign-employee', verifyToken, isAdmin, async (req, res) => {
//   try {
//     const { employeeId, managerId } = req.body;

//     if (!employeeId || !managerId) {
//       return res.status(400).json({ message: 'Employee ID and Manager ID are required' });
//     }

//     const employee = await User.findOne({ employeeId, roleType: 'Employee' });
//     if (!employee) {
//       return res.status(404).json({ message: 'Employee not found or invalid role type' });
//     }

//     const manager = await User.findOne({ employeeId: managerId, roleType: 'Manager' });
//     if (!manager) {
//       return res.status(404).json({ message: 'Manager not found or invalid role type' });
//     }

//     const admin = await User.findOne({ employeeId: req.user.employeeId });
//     if (!admin) {
//       return res.status(404).json({ message: 'Admin not found' });
//     }

//     const existingAssignment = await Assignment.findOne({ employeeId: employee._id, managerId, status: 'Pending' });
//     if (existingAssignment) {
//       return res.status(400).json({ message: 'Employee is already assigned to this manager and pending approval' });
//     }

//     const assignment = new Assignment({
//       employeeId: employee._id,
//       managerId,
//       assignedBy: admin._id,
//       status: 'Pending',
//     });

//     await assignment.save();

//     await User.findOneAndUpdate(
//       { employeeId },
//       { managerId },
//       { new: true }
//     );

//     res.status(201).json({ message: 'Employee assigned to manager successfully', assignment });
//   } catch (error) {
//     console.error('Assign employee error:', error);
//     res.status(500).json({ message: 'Server error during employee assignment' });
//   }
// });

// // Get pending assignments for a manager
// app.get('/api/manager/assignments', verifyToken, async (req, res) => {
//   try {
//     const { employeeId, roleType } = req.user;

//     if (roleType !== 'Manager') {
//       return res.status(403).json({ message: 'Access denied: Managers only' });
//     }

//     const assignments = await Assignment.find({ managerId: employeeId, status: 'Pending' })
//       .populate('employeeId', 'name initial employeeId email')
//       .populate('assignedBy', 'name employeeId');

//     res.status(200).json({ assignments });
//   } catch (error) {
//     console.error('Fetch assignments error:', error);
//     res.status(500).json({ message: 'Server error during assignments retrieval' });
//   }
// });

// // Accept or reject assignment (Manager only)
// app.put('/api/manager/assignments/:assignmentId', verifyToken, async (req, res) => {
//   try {
//     const { assignmentId } = req.params;
//     const { status } = req.body;
//     const { employeeId, roleType } = req.user;

//     if (roleType !== 'Manager') {
//       return res.status(403).json({ message: 'Access denied: Managers only' });
//     }

//     if (!['Accepted', 'Rejected'].includes(status)) {
//       return res.status(400).json({ message: 'Invalid status. Must be Accepted or Rejected' });
//     }

//     const assignment = await Assignment.findOne({ _id: assignmentId, managerId: employeeId });
//     if (!assignment) {
//       return res.status(404).json({ message: 'Assignment not found or you are not authorized' });
//     }

//     assignment.status = status;
//     await assignment.save();

//     if (status === 'Accepted') {
//       await User.findOneAndUpdate(
//         { employeeId: assignment.managerId },
//         { $addToSet: { assignedEmployees: assignment.employeeId } },
//         { new: true }
//       );
//     }

//     res.status(200).json({ message: `Assignment ${status.toLowerCase()} successfully`, assignment });
//   } catch (error) {
//     console.error('Update assignment error:', error);
//     res.status(500).json({ message: 'Server error during assignment update' });
//   }
// });

// // Get assigned employees for a manager
// app.get('/api/manager/employees', verifyToken, async (req, res) => {
//   try {
//     const { employeeId, roleType } = req.user;

//     if (roleType !== 'Manager') {
//       return res.status(403).json({ message: 'Access denied: Managers only' });
//     }

//     const manager = await User.findOne({ employeeId }).populate('assignedEmployees', 'name initial employeeId email department role');
//     if (!manager) {
//       return res.status(404).json({ message: 'Manager not found' });
//     }

//     res.status(200).json({ employees: manager.assignedEmployees });
//   } catch (error) {
//     console.error('Fetch assigned employees error:', error);
//     res.status(500).json({ message: 'Server error during assigned employees retrieval' });
//   }
// });

// // Get attendance report for a manager's assigned employees
// app.get('/api/manager/attendance', verifyToken, isManager, async (req, res) => {
//   try {
//     const { employeeId } = req.user;

//     const manager = await User.findOne({ employeeId }).populate('assignedEmployees', 'name employeeId');
//     if (!manager) {
//       return res.status(404).json({ message: 'Manager not found' });
//     }

//     const employeeIds = manager.assignedEmployees.map(emp => emp.employeeId);
//     if (employeeIds.length === 0) {
//       return res.status(200).json({ attendance: [] });
//     }

//     const timesheets = await Timesheet.find({ employeeId: { $in: employeeIds } });

//     const attendance = [];
//     for (const timesheet of timesheets) {
//       const employee = manager.assignedEmployees.find(emp => emp.employeeId === timesheet.employeeId);
//       const weekStartDate = new Date(timesheet.weekStartDate);

//       for (let day = 0; day < 7; day++) {
//         const currentDate = new Date(weekStartDate);
//         currentDate.setDate(weekStartDate.getDate() + day);

//         const loginTime = timesheet.loginTimes[day];
//         const logoutTime = timesheet.logoutTimes[day];
//         const status = loginTime ? 'Present' : 'Absent';

//         attendance.push({
//           employeeId: timesheet.employeeId,
//           name: employee.name,
//           date: currentDate.toISOString().split('T')[0],
//           checkInTime: loginTime || 'N/A',
//           checkOutTime: logoutTime || 'N/A',
//           status,
//         });
//       }
//     }

//     res.status(200).json({ attendance });
//   } catch (error) {
//     console.error('Fetch attendance error:', error);
//     res.status(500).json({ message: 'Server error during attendance retrieval' });
//   }
// });

// // Get attendance report for an employee
// app.get('/api/employee/attendance', verifyToken, isEmployee, async (req, res) => {
//   try {
//     const { employeeId } = req.user;

//     const timesheets = await Timesheet.find({ employeeId });

//     const attendance = [];
//     for (const timesheet of timesheets) {
//       const weekStartDate = new Date(timesheet.weekStartDate);

//       for (let day = 0; day < 7; day++) {
//         const currentDate = new Date(weekStartDate);
//         currentDate.setDate(weekStartDate.getDate() + day);

//         const loginTime = timesheet.loginTimes[day];
//         const logoutTime = timesheet.logoutTimes[day];

//         let totalWorkedTime = 'N/A';
//         if (loginTime && logoutTime) {
//           const login = new Date(`2025-05-06 ${loginTime}`);
//           const logout = new Date(`2025-05-06 ${logoutTime}`);
//           const hoursWorked = (logout - login) / (1000 * 60 * 60);
//           totalWorkedTime = `${hoursWorked.toFixed(2)} hrs`;
//         }

//         if (loginTime || logoutTime) {
//           attendance.push({
//             date: currentDate.toISOString().split('T')[0],
//             login: loginTime || 'N/A',
//             logout: logoutTime || 'N/A',
//             totalWorkedTime,
//           });
//         }
//       }
//     }

//     res.status(200).json({ attendance });
//   } catch (error) {
//     console.error('Fetch employee attendance error:', error);
//     res.status(500).json({ message: 'Server error during employee attendance retrieval' });
//   }
// });

// // Get user details by employeeId
// app.get('/api/user/:employeeId', verifyToken, async (req, res) => {
//   try {
//     const { employeeId } = req.params;

//     const user = await User.findOne({ employeeId }, { password: 0, __v: 0 });
//     if (!user) {
//       return res.status(404).json({ message: 'User not found' });
//     }

//     res.status(200).json({ user });
//   } catch (error) {
//     console.error('Fetch user error:', error);
//     res.status(500).json({ message: 'Server error during user retrieval' });
//   }
// });

// // Submit Leave Request (Employee only)
// app.post('/api/leave/apply', verifyToken, isEmployee, async (req, res) => {
//   try {
//     const { employeeId, leaveType, fromDate, toDate, reason, status } = req.body;

//     // Validate request
//     if (!employeeId || !leaveType || !fromDate || !toDate || !reason) {
//       return res.status(400).json({ message: 'All fields are required' });
//     }

//     if (!['sick', 'casual', 'emergency'].includes(leaveType)) {
//       return res.status(400).json({ message: 'Invalid leave type. Must be sick, casual, or emergency' });
//     }

//     const dateRegex = /^\d{2}-\d{2}-\d{4}$/;
//     if (!dateRegex.test(fromDate) || !dateRegex.test(toDate)) {
//       return res.status(400).json({ message: 'Dates must be in DD-MM-YYYY format' });
//     }

//     const fromDateObj = new Date(fromDate.split('-').reverse().join('-'));
//     const toDateObj = new Date(toDate.split('-').reverse().join('-'));
//     if (fromDateObj > toDateObj) {
//       return res.status(400).json({ message: 'From date cannot be later than to date' });
//     }

//     // Fetch employee details
//     const employee = await User.findOne({ employeeId });
//     if (!employee) {
//       return res.status(404).json({ message: 'Employee not found' });
//     }

//     // Fetch manager details
//     let manager = null;
//     if (employee.managerId) {
//       manager = await User.findOne({ employeeId: employee.managerId });
//       if (!manager) {
//         return res.status(404).json({ message: 'Manager not found' });
//       }
//     }

//     // Store leave request in the database
//     const leaveRequest = new LeaveRequest({
//       employeeId,
//       employeeName: employee.name,
//       leaveType,
//       fromDate,
//       toDate,
//       reason,
//       status: status || 'pending',
//     });
//     await leaveRequest.save();

//     // Prepare email details
//     const employeeEmail = generateEmailTemplate(leaveRequest, employee.name, 'employee');
//     const adminEmail = generateEmailTemplate(leaveRequest, employee.name, 'admin');
//     const emails = [
//       {
//         from: process.env.EMAIL_USER,
//         to: employee.email,
//         subject: employeeEmail.subject,
//         html: employeeEmail.html,
//       },
//       {
//         from: process.env.EMAIL_USER,
//         to: process.env.ADMIN_EMAIL || 'admin@company.com',
//         subject: adminEmail.subject,
//         html: adminEmail.html,
//       },
//     ];

//     // Add manager email if manager exists
//     if (manager) {
//       const managerEmail = generateEmailTemplate(leaveRequest, employee.name, 'manager');
//       emails.push({
//         from: process.env.EMAIL_USER,
//         to: manager.email,
//         subject: managerEmail.subject,
//         html: managerEmail.html,
//       });
//     }

//     // Send emails
//     await Promise.all(emails.map(email => transporter.sendMail(email)));

//     // Emit WebSocket event to notify managers
//     io.to('managers').emit('newLeaveRequest', {
//       leaveId: leaveRequest._id,
//       employeeId,
//       employeeName: employee.name,
//       leaveType,
//       fromDate,
//       toDate,
//       reason,
//       status: 'pending',
//       createdAt: leaveRequest.createdAt,
//     });

//     res.status(201).json({ message: 'Leave request submitted successfully', leaveRequest });
//   } catch (error) {
//     console.error('Submit leave request error:', error);
//     res.status(500).json({ message: 'Server error during leave request submission' });
//   }
// });

// // Approve or Reject Leave Request (Manager or Admin only)
// // Approve or Reject Leave Request via GET (for email links, Manager or Admin only)
// app.get('/api/leave/update/:leaveId', verifyToken, isManagerOrAdmin, async (req, res) => {
//   try {
//     const { leaveId } = req.params;
//     const { status } = req.query;
//     const { employeeId, roleType } = req.user;

//     if (!['approved', 'rejected'].includes(status)) {
//       return res.status(400).json({ message: 'Invalid status. Must be approved or rejected' });
//     }

//     const leaveRequest = await LeaveRequest.findById(leaveId);
//     if (!leaveRequest) {
//       return res.status(404).json({ message: 'Leave request not found' });
//     }

//     // Authorization check
//     if (roleType === 'Manager') {
//       const manager = await User.findOne({ employeeId }).populate('assignedEmployees', 'employeeId');
//       if (!manager) {
//         return res.status(404).json({ message: 'Manager not found' });
//       }
//       const employeeIds = manager.assignedEmployees.map(emp => emp.employeeId);
//       if (!employeeIds.includes(leaveRequest.employeeId)) {
//         return res.status(403).json({ message: 'You are not authorized to review this leave request' });
//       }
//     }

//     // Update leave request
//     leaveRequest.status = status;
//     leaveRequest.reviewedBy = employeeId;
//     leaveRequest.reviewedAt = new Date();
//     await leaveRequest.save();

//     // Fetch employee details for email notification
//     const employee = await User.findOne({ employeeId: leaveRequest.employeeId });
//     if (!employee) {
//       return res.status(404).json({ message: 'Employee not found' });
//     }

//     // Send email to employee about the status update
//     const statusEmail = {
//       subject: `Leave Request ${status.charAt(0).toUpperCase() + status.slice(1)}`,
//       html: `
//         <!DOCTYPE html>
//         <html lang="en">
//         <head>
//           <meta charset="UTF-8">
//           <meta name="viewport" content="width=device-width, initial-scale=1.0">
//           <title>Leave Request Status Update</title>
//           <style>
//             body {
//               font-family: 'Helvetica Neue', Arial, sans-serif;
//               background-color: #f4f4f4;
//               margin: 0;
//               padding: 0;
//             }
//             .container {
//               max-width: 600px;
//               margin: 20px auto;
//               background-color: #ffffff;
//               border-radius: 8px;
//               box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
//               overflow: hidden;
//             }
//             .header {
//               background-color: #003087;
//               padding: 20px;
//               text-align: center;
//             }
//             .header h1 {
//               color: #ffffff;
//               margin: 0;
//               font-size: 24px;
//             }
//             .content {
//               padding: 20px;
//             }
//             .content h2 {
//               color: #333333;
//               font-size: 20px;
//               margin-bottom: 15px;
//             }
//             .details-table {
//               width: 100%;
//               border-collapse: collapse;
//               margin-bottom: 20px;
//             }
//             .details-table th,
//             .details-table td {
//               padding: 12px;
//               text-align: left;
//               border-bottom: 1px solid #e0e0e0;
//             }
//             .details-table th {
//               background-color: #f9f9f9;
//               color: #333333;
//               width: 30%;
//               font-weight: 600;
//             }
//             .details-table td {
//               color: #555555;
//             }
//             .footer {
//               background-color: #003087;
//               padding: 10px;
//               text-align: center;
//             }
//             .footer p {
//               color: #ffffff;
//               margin: 0;
//               font-size: 12px;
//             }
//           </style>
//         </head>
//         <body>
//           <div class="container">
//             <div class="header">
//               <h1>Leave Request Status Update</h1>
//             </div>
//             <div class="content">
//               <h2>Your Leave Request Has Been ${status.charAt(0).toUpperCase() + status.slice(1)}</h2>
//               <p>Dear ${employee.name},</p>
//               <p>Your leave request has been ${status} by ${roleType} (${employeeId}).</p>
//               <table class="details-table">
//                 <tr>
//                   <th>Leave Type</th>
//                   <td>${leaveRequest.leaveType.charAt(0).toUpperCase() + leaveRequest.leaveType.slice(1)} Leave</td>
//                 </tr>
//                 <tr>
//                   <th>From Date</th>
//                   <td>${leaveRequest.fromDate}</td>
//                 </tr>
//                 <tr>
//                   <th>To Date</th>
//                   <td>${leaveRequest.toDate}</td>
//                 </tr>
//                 <tr>
//                   <th>Reason</th>
//                   <td>${leaveRequest.reason}</td>
//                 </tr>
//               </table>
//             </div>
//             <div class="footer">
//               <p>© 2025 Intellisurge Technologies. All Rights Reserved.</p>
//             </div>
//           </div>
//         </body>
//         </html>
//       `,
//     };

//     await transporter.sendMail({
//       from: process.env.EMAIL_USER,
//       to: employee.email,
//       subject: statusEmail.subject,
//       html: statusEmail.html,
//     });

//     // Emit WebSocket event to notify clients
//     io.to(leaveRequest.employeeId).emit('leaveStatusUpdate', {
//       leaveId,
//       status,
//       reviewedBy: employeeId,
//       reviewedAt: new Date(),
//     });
//     io.to('managers').emit('leaveStatusUpdate', {
//       leaveId,
//       status,
//       employeeId: leaveRequest.employeeId,
//       reviewedBy: employeeId,
//       reviewedAt: new Date(),
//     });

//     // Redirect to the frontend app for email link actions
//     const redirectUrl = `${process.env.APP_URL}/leave-decisions?leaveId=${leaveId}&status=${status}&employeeId=${employeeId}`;
//     res.redirect(redirectUrl);
//   } catch (error) {
//     console.error('Update leave request error:', error);
//     res.status(500).send(`
//       <!DOCTYPE html>
//       <html lang="en">
//       <head>
//         <meta charset="UTF-8">
//         <meta name="viewport" content="width=device-width, initial-scale=1.0">
//         <title>Error</title>
//         <style>
//           body {
//             font-family: 'Helvetica Neue', Arial, sans-serif;
//             background-color: #f4f4f4;
//             margin: 0;
//             padding: 0;
//             display: flex;
//             justify-content: center;
//             align-items: center;
//             height: 100vh;
//           }
//           .container {
//             max-width: 600px;
//             background-color: #ffffff;
//             border-radius: 8px;
//             padding: 20px;
//             text-align: center;
//           }
//           .header h1 {
//             color: #333333;
//             font-size: 24px;
//             margin-bottom: 20px;
//           }
//           p {
//             color: #555555;
//             font-size: 16px;
//             margin-bottom: 20px;
//           }
//           a {
//             display: inline-block;
//             padding: 10px 20px;
//             background-color: #003087;
//             color: #ffffff;
//             text-decoration: none;
//             border-radius: 4px;
//             font-weight: 600;
//           }
//           a:hover {
//             background-color: #002343;
//           }
//         </style>
//       </head>
//       <body>
//         <div class="container">
//           <div class="header">
//             <h1>Error Updating Leave Request</h1>
//           </div>
//           <p>An error occurred: ${error.message}</p>
//           <a href="${process.env.APP_URL}/dashboard">Return to Dashboard</a>
//         </div>
//       </body>
//       </html>
//     `);
//   }
// });

// // Approve or Reject Leave Request via PUT (for frontend API calls, Manager or Admin only)
// app.put('/api/leave/update/:leaveId', verifyToken, isManagerOrAdmin, async (req, res) => {
//   try {
//     const { leaveId } = req.params;
//     const { status } = req.body;
//     const { employeeId, roleType } = req.user;

//     if (!['approved', 'rejected'].includes(status)) {
//       return res.status(400).json({ message: 'Invalid status. Must be approved or rejected' });
//     }

//     const leaveRequest = await LeaveRequest.findById(leaveId);
//     if (!leaveRequest) {
//       return res.status(404).json({ message: 'Leave request not found' });
//     }

//     // Authorization check
//     if (roleType === 'Manager') {
//       const manager = await User.findOne({ employeeId }).populate('assignedEmployees', 'employeeId');
//       if (!manager) {
//         return res.status(404).json({ message: 'Manager not found' });
//       }
//       const employeeIds = manager.assignedEmployees.map(emp => emp.employeeId);
//       if (!employeeIds.includes(leaveRequest.employeeId)) {
//         return res.status(403).json({ message: 'You are not authorized to review this leave request' });
//       }
//     }

//     // Update leave request
//     leaveRequest.status = status;
//     leaveRequest.reviewedBy = employeeId;
//     leaveRequest.reviewedAt = new Date();
//     await leaveRequest.save();

//     // Fetch employee details for email notification
//     const employee = await User.findOne({ employeeId: leaveRequest.employeeId });
//     if (!employee) {
//       return res.status(404).json({ message: 'Employee not found' });
//     }

//     // Send email to employee about the status update
//     const statusEmail = {
//       subject: `Leave Request ${status.charAt(0).toUpperCase() + status.slice(1)}`,
//       html: `
//         <!DOCTYPE html>
//         <html lang="en">
//         <head>
//           <meta charset="UTF-8">
//           <meta name="viewport" content="width=device-width, initial-scale=1.0">
//           <title>Leave Request Status Update</title>
//           <style>
//             body {
//               font-family: 'Helvetica Neue', Arial, sans-serif;
//               background-color: #f4f4f4;
//               margin: 0;
//               padding: 0;
//             }
//             .container {
//               max-width: 600px;
//               margin: 20px auto;
//               background-color: #ffffff;
//               border-radius: 8px;
//               box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
//               overflow: hidden;
//             }
//             .header {
//               background-color: #003087;
//               padding: 20px;
//               text-align: center;
//             }
//             .header h1 {
//               color: #ffffff;
//               margin: 0;
//               font-size: 24px;
//             }
//             .content {
//               padding: 20px;
//             }
//             .content h2 {
//               color: #333333;
//               font-size: 20px;
//               margin-bottom: 15px;
//             }
//             .details-table {
//               width: 100%;
//               border-collapse: collapse;
//               margin-bottom: 20px;
//             }
//             .details-table th,
//             .details-table td {
//               padding: 12px;
//               text-align: left;
//               border-bottom: 1px solid #e0e0e0;
//             }
//             .details-table th {
//               background-color: #f9f9f9;
//               color: #333333;
//               width: 30%;
//               font-weight: 600;
//             }
//             .details-table td {
//               color: #555555;
//             }
//             .footer {
//               background-color: #003087;
//               padding: 10px;
//               text-align: center;
//             }
//             .footer p {
//               color: #ffffff;
//               margin: 0;
//               font-size: 12px;
//             }
//           </style>
//         </head>
//         <body>
//           <div class="container">
//             <div class="header">
//               <h1>Leave Request Status Update</h1>
//             </div>
//             <div class="content">
//               <h2>Your Leave Request Has Been ${status.charAt(0).toUpperCase() + status.slice(1)}</h2>
//               <p>Dear ${employee.name},</p>
//               <p>Your leave request has been ${status} by ${roleType} (${employeeId}).</p>
//               <table class="details-table">
//                 <tr>
//                   <th>Leave Type</th>
//                   <td>${leaveRequest.leaveType.charAt(0).toUpperCase() + leaveRequest.leaveType.slice(1)} Leave</td>
//                 </tr>
//                 <tr>
//                   <th>From Date</th>
//                   <td>${leaveRequest.fromDate}</td>
//                 </tr>
//                 <tr>
//                   <th>To Date</th>
//                   <td>${leaveRequest.toDate}</td>
//                 </tr>
//                 <tr>
//                   <th>Reason</th>
//                   <td>${leaveRequest.reason}</td>
//                 </tr>
//               </table>
//             </div>
//             <div class="footer">
//               <p>© 2025 Intellisurge Technologies. All Rights Reserved.</p>
//             </div>
//           </div>
//         </body>
//         </html>
//       `,
//     };

//     await transporter.sendMail({
//       from: process.env.EMAIL_USER,
//       to: employee.email,
//       subject: statusEmail.subject,
//       html: statusEmail.html,
//     });

//     // Emit WebSocket event to notify clients
//     io.to(leaveRequest.employeeId).emit('leaveStatusUpdate', {
//       leaveId,
//       status,
//       reviewedBy: employeeId,
//       reviewedAt: new Date(),
//     });
//     io.to('managers').emit('leaveStatusUpdate', {
//       leaveId,
//       status,
//       employeeId: leaveRequest.employeeId,
//       reviewedBy: employeeId,
//       reviewedAt: new Date(),
//     });

//     // Return JSON response for frontend
//     res.status(200).json({
//       message: `Leave request ${status} successfully`,
//       leaveRequest: {
//         _id: leaveRequest._id,
//         employeeId: leaveRequest.employeeId,
//         employeeName: leaveRequest.employeeName,
//         leaveType: leaveRequest.leaveType,
//         fromDate: leaveRequest.fromDate,
//         toDate: leaveRequest.toDate,
//         reason: leaveRequest.reason,
//         status: leaveRequest.status,
//         reviewedBy: leaveRequest.reviewedBy,
//         reviewedAt: leaveRequest.reviewedAt,
//         createdAt: leaveRequest.createdAt,
//       },
//     });
//   } catch (error) {
//     console.error('Update leave request error:', error);
//     res.status(500).json({ message: `Server error during leave request update: ${error.message}` });
//   }
// });

// // Get Pending Leave Requests (Manager or Admin only)
// app.get('/api/leave/pending', verifyToken, isManagerOrAdmin, async (req, res) => {
//   try {
//     const { employeeId, roleType } = req.user;
//     let leaveRequests = [];

//     if (roleType === 'Manager') {
//       const manager = await User.findOne({ employeeId }).populate('assignedEmployees', 'employeeId');
//       if (!manager) {
//         return res.status(404).json({ message: 'Manager not found' });
//       }

//       const employeeIds = manager.assignedEmployees.map(emp => emp.employeeId);
//       if (employeeIds.length === 0) {
//         return res.status(200).json({ leaveRequests: [] });
//       }

//       leaveRequests = await LeaveRequest.find({
//         employeeId: { $in: employeeIds },
//         status: 'pending',
//       });
//     } else if (roleType === 'Admin') {
//       leaveRequests = await LeaveRequest.find({ status: 'pending' });
//     }

//     res.status(200).json({ leaveRequests });
//   } catch (error) {
//     console.error('Fetch pending leave requests error:', error);
//     res.status(500).json({ message: 'Server error during pending leave requests retrieval' });
//   }
// });

// // Get Leave Requests for an Employee (Employee only)
// app.get('/api/leave/status', verifyToken, isEmployee, async (req, res) => {
//   try {
//     const { employeeId } = req.user;

//     const leaveRequests = await LeaveRequest.find({ employeeId });

//     res.status(200).json({ leaveRequests });
//   } catch (error) {
//     console.error('Fetch leave status error:', error);
//     res.status(500).json({ message: 'Server error during leave status retrieval' });
//   }
// });

// // Start the server with Socket.IO
// server.listen(PORT, () => {
//   console.log(`Server running on port ${PORT}`);
// });

// working

// require('dotenv').config();
// const express = require('express');
// const mongoose = require('mongoose');
// const bcrypt = require('bcryptjs');
// const { v4: uuidv4 } = require('uuid');
// const jwt = require('jsonwebtoken');
// const nodemailer = require('nodemailer');
// const http = require('http');
// const { Server } = require('socket.io');
// const User = require('./models/User');
// const Task = require('./models/Task');
// const Timesheet = require('./models/Timesheet');
// const Assignment = require('./models/Assignment');
// const LeaveRequest = require('./models/LeaveRequest');

// const app = express();
// const PORT = process.env.PORT || 5001;

// const server = http.createServer(app);
// const io = new Server(server, {
//   cors: {
//     origin: process.env.APP_URL,
//     methods: ['GET', 'POST'],
//   },
// });

// app.use(express.json());

// mongoose.connect(process.env.MONGO_URI, {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// })
// .then(() => console.log('Connected to MongoDB'))
// .catch((error) => console.error('MongoDB connection error:', error));

// const transporter = nodemailer.createTransport({
//   service: 'gmail',
//   auth: {
//     user: process.env.EMAIL_USER,
//     pass: process.env.EMAIL_PASS,
//   },
// });


// // Endpoint to check Nodemailer transporter status
// app.get('/api/health/email', async (req, res) => {
//   try {
//     // Verify the transporter configuration
//     await transporter.verify();
    
//     // If verification succeeds, return success response
//     res.status(200).json({
//       status: 'success',
//       message: 'Nodemailer transporter is active and configured correctly',
//       emailService: 'Gmail',
//       emailUser: process.env.EMAIL_USER,
//     });
//   } catch (error) {
//     // Handle specific errors for better debugging
//     let errorMessage = 'Nodemailer transporter verification failed';
//     let errorDetails = error.message;

//     if (error.code === 'EAUTH') {
//       errorMessage = 'Authentication failed';
//       errorDetails = 'Invalid EMAIL_USER or EMAIL_PASS. Please check your Gmail credentials or App Password.';
//     } else if (error.code === 'ECONNREFUSED') {
//       errorMessage = 'Connection refused';
//       errorDetails = 'Unable to connect to Gmail SMTP server. Check your network or Gmail service status.';
//     }

//     console.error('Nodemailer verification error:', error);
//     res.status(500).json({
//       status: 'error',
//       message: errorMessage,
//       details: errorDetails,
//     });
//   }
// });


// // // Generate OTP
// // const generateOTP = () => {
// //   return Math.floor(100000 + Math.random() * 900000).toString();
// // };

// // // Store OTPs temporarily (in-memory for simplicity, consider Redis in production)
// // const otpStore = new Map();

// // // Forgot Password - Send OTP
// // app.post('/api/forgot-password', async (req, res) => {
// //   try {
// //     const { email } = req.body;

// //     if (!email) {
// //       return res.status(400).json({ message: 'Email is required' });
// //     }

// //     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// //     if (!emailRegex.test(email)) {
// //       return res.status(400).json({ message: 'Invalid email format' });
// //     }

// //     const user = await User.findOne({ email });
// //     if (!user) {
// //       return res.status(404).json({ message: 'User not found' });
// //     }

// //     const otp = generateOTP();
// //     otpStore.set(email, { otp, expires: Date.now() + 10 * 60 * 1000 }); // OTP expires in 10 minutes

// //     const otpEmail = {
// //       from: process.env.EMAIL_USER,
// //       to: email,
// //       subject: 'Password Reset OTP',
// //       html: `
// //         <!DOCTYPE html>
// //         <html lang="en">
// //         <head>
// //           <meta charset="UTF-8">
// //           <meta name="viewport" content="width=device-width, initial-scale=1.0">
// //           <title>Password Reset OTP</title>
// //           <style>
// //             body {
// //               font-family: 'Helvetica Neue', Arial, sans-serif;
// //               background-color: #f4f4f4;
// //               margin: 0;
// //               padding: 0;
// //             }
// //             .container {
// //               max-width: 600px;
// //               margin: 20px auto;
// //               background-color: #ffffff;
// //               border-radius: 8px;
// //               box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
// //               overflow: hidden;
// //             }
// //             .header {
// //               background: linear-gradient(90deg, #003087, #0059b3);
// //               padding: 30px;
// //               text-align: center;
// //             }
// //             .header h1 {
// //               color: #ffffff;
// //               margin: 0;
// //               font-size: 28px;
// //               font-weight: 700;
// //             }
// //             .content {
// //               padding: 30px;
// //               text-align: center;
// //             }
// //             .otp {
// //               font-size: 32px;
// //               font-weight: bold;
// //               color: #003087;
// //               letter-spacing: 5px;
// //               margin: 20px 0;
// //               padding: 15px;
// //               background-color: #f0f4f8;
// //               border-radius: 8px;
// //               display: inline-block;
// //             }
// //             .content p {
// //               color: #333333;
// //               font-size: 16px;
// //               line-height: 1.6;
// //               margin: 10px 0;
// //             }
// //             .warning {
// //               color: #e67e22;
// //               font-size: 14px;
// //               margin-top: 20px;
// //             }
// //             .footer {
// //               background-color: #003087;
// //               padding: 15px;
// //               text-align: center;
// //             }
// //             .footer p {
// //               color: #ffffff;
// //               margin: 0;
// //               font-size: 12px;
// //             }
// //           </style>
// //         </head>
// //         <body>
// //           <div class="container">
// //             <div class="header">
// //               <h1>Password Reset Request</h1>
// //             </div>
// //             <div class="content">
// //               <p>Dear ${user.name},</p>
// //               <p>We received a request to reset your password. Use the OTP below to proceed:</p>
// //               <div class="otp">${otp}</div>
// //               <p>This OTP is valid for 10 minutes. If you did not request a password reset, please ignore this email.</p>
// //               <p class="warning">Do not share this OTP with anyone for security reasons.</p>
// //             </div>
// //             <div class="footer">
// //               <p>© 2025 Intellisurge Technologies. All Rights Reserved.</p>
// //             </div>
// //           </div>
// //         </body>
// //         </html>
// //       `,
// //     };

// //     await transporter.sendMail(otpEmail);
// //     res.status(200).json({ message: 'OTP sent to your email' });
// //   } catch (error) {
// //     console.error('Forgot password error:', error);
// //     res.status(500).json({ message: 'Server error during OTP generation' });
// //   }
// // });

// // // Verify OTP
// // app.post('/api/verify-otp', async (req, res) => {
// //   try {
// //     const { email, otp } = req.body;

// //     if (!email || !otp) {
// //       return res.status(400).json({ message: 'Email and OTP are required' });
// //     }

// //     const storedOTP = otpStore.get(email);
// //     if (!storedOTP) {
// //       return res.status(400).json({ message: 'OTP not found or expired' });
// //     }

// //     if (storedOTP.expires < Date.now()) {
// //       otpStore.delete(email);
// //       return res.status(400).json({ message: 'OTP expired' });
// //     }

// //     if (storedOTP.otp !== otp) {
// //       return res.status(400).json({ message: 'Invalid OTP' });
// //     }

// //     const user = await User.findOne({ email });
// //     if (!user) {
// //       return res.status(404).json({ message: 'User not found' });
// //     }

// //     const resetToken = jwt.sign({ employeeId: user.employeeId }, process.env.JWT_SECRET, { expiresIn: '15m' });
// //     otpStore.delete(email); // Clear OTP after successful verification

// //     res.status(200).json({ message: 'OTP verified', resetToken });
// //   } catch (error) {
// //     console.error('OTP verification error:', error);
// //     res.status(500).json({ message: 'Server error during OTP verification' });
// //   }
// // });

// // // Reset Password
// // app.post('/api/reset-password', async (req, res) => {
// //   try {
// //     const { token, newPassword } = req.body;

// //     if (!token || !newPassword) {
// //       return res.status(400).json({ message: 'Token and new password are required' });
// //     }

// //     let decoded;
// //     try {
// //       decoded = jwt.verify(token, process.env.JWT_SECRET);
// //     } catch (error) {
// //       return res.status(401).json({ message: 'Invalid or expired token' });
// //     }

// //     const user = await User.findOne({ employeeId: decoded.employeeId });
// //     if (!user) {
// //       return res.status(404).json({ message: 'User not found' });
// //     }

// //     const saltRounds = 10;
// //     const hashedPassword = await bcrypt.hash(newPassword, saltRounds);
// //     user.password = hashedPassword;
// //     await user.save();

// //     res.status(200).json({ message: 'Password reset successfully' });
// //   } catch (error) {
// //     console.error('Reset password error:', error);
// //     res.status(500).json({ message: 'Server error during password reset' });
// //   }
// // });

// // Enhanced Email Template for Leave Requests






// const generateEmailTemplate = (leaveRequest, employeeName, recipientRole) => {
//   const { _id, employeeId, leaveType, fromDate, toDate, reason } = leaveRequest;
//   const leaveTypeFormatted = leaveType.charAt(0).toUpperCase() + leaveType.slice(1) + ' Leave';
//   let subject;
//   if (recipientRole === 'employee') {
//     subject = 'Your Leave Request Submission';
//   } else if (recipientRole === 'manager') {
//     subject = `New Leave Request from ${employeeName} (${employeeId})`;
//   } else {
//     subject = `Leave Request for Approval - ${employeeName} (${employeeId})`;
//   }

//   const html = `
//     <!DOCTYPE html>
//     <html lang="en">
//     <head>
//       <meta charset="UTF-8">
//       <meta name="viewport" content="width=device-width, initial-scale=1.0">
//       <title>Leave Request Notification</title>
//       <style>
//         body {
//           font-family: 'Helvetica Neue', Arial, sans-serif;
//           background-color: #f4f4f4;
//           margin: 0;
//           padding: 0;
//         }
//         .container {
//           max-width: 600px;
//           margin: 20px auto;
//           background-color: #ffffff;
//           border-radius: 12px;
//           box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
//           overflow: hidden;
//         }
//         .header {
//           background: linear-gradient(90deg, #003087, #0059b3);
//           padding: 30px;
//           text-align: center;
//         }
//         .header h1 {
//           color: #ffffff;
//           margin: 0;
//           font-size: 28px;
//           font-weight: 700;
//         }
//         .content {
//           padding: 30px;
//         }
//         .content h2 {
//           color: #003087;
//           font-size: 22px;
//           margin-bottom: 20px;
//           text-align: center;
//         }
//         .content p {
//           color: #333333;
//           font-size: 16px;
//           line-height: 1.6;
//           margin: 10px 0;
//         }
//         .details-table {
//           width: 100%;
//           border-collapse: collapse;
//           margin: 20px 0;
//           background-color: #f9f9f9;
//           border-radius: 8px;
//           overflow: hidden;
//         }
//         .details-table th,
//         .details-table td {
//           padding: 15px;
//           text-align: left;
//           border-bottom: 1px solid #e0e0e0;
//         }
//         .details-table th {
//           background-color: #003087;
//           color: #ffffff;
//           width: 35%;
//           font-weight: 600;
//         }
//         .details-table td {
//           color: #333333;
//         }
//         .action-buttons {
//           text-align: center;
//           margin: 30px 0;
//         }
//         .action-buttons a {
//           display: inline-block;
//           padding: 12px 24px;
//           margin: 0 10px;
//           text-decoration: none;
//           font-weight: 600;
//           border-radius: 6px;
//           transition: all 0.3s ease;
//         }
//         .approve-btn {
//           background-color: #28a745;
//           color: #ffffff;
//         }
//         .approve-btn:hover {
//           background-color: #218838;
//           transform: translateY(-2px);
//         }
//         .reject-btn {
//           background-color: #dc3545;
//           color: #ffffff;
//         }
//         .reject-btn:hover {
//           background-color: #c82333;
//           transform: translateY(-2px);
//         }
//         .action-text {
//           color: #555555;
//           font-size: 14px;
//           margin-top: 15px;
//           text-align: center;
//         }
//         .footer {
//           background-color: #003087;
//           padding: 15px;
//           text-align: center;
//         }
//         .footer p {
//           color: #ffffff;
//           margin: 0;
//           font-size: 12px;
//         }
//       </style>
//     </head>
//     <body>
//       <div class="container">
//         <div class="header">
//           <h1>Leave Request Notification</h1>
//         </div>
//         <div class="content">
//           <h2>${
//             recipientRole === 'employee'
//               ? 'Your Leave Request Has Been Submitted'
//               : recipientRole === 'manager'
//               ? 'New Leave Request for Your Review'
//               : 'New Leave Request for Approval'
//           }</h2>
//           <p>Dear ${recipientRole === 'employee' ? employeeName : recipientRole.charAt(0).toUpperCase() + recipientRole.slice(1)},</p>
//           <p>${
//             recipientRole === 'employee'
//               ? 'Thank you for submitting your leave request. It has been sent for approval and you will be notified once reviewed.'
//               : `A leave request from ${employeeName} (${employeeId}) awaits your approval.`
//           }</p>
//           <table class="details-table">
//             <tr>
//               <th>Employee ID</th>
//               <td>${employeeId}</td>
//             </tr>
//             <tr>
//               <th>Employee Name</th>
//               <td>${employeeName}</td>
//             </tr>
//             <tr>
//               <th>Leave Type</th>
//               <td>${leaveTypeFormatted}</td>
//             </tr>
//             <tr>
//               <th>From Date</th>
//               <td>${fromDate}</td>
//             </tr>
//             <tr>
//               <th>To Date</th>
//               <td>${toDate}</td>
//             </tr>
//             <tr>
//               <th>Reason</th>
//               <td>${reason}</td>
//             </tr>
//           </table>
//           ${
//             recipientRole === 'manager'
//               ? `
//                 <div class="action-buttons">
//                   <a href="${process.env.APP_URL}/api/leave/update/${_id}?status=approved&token=${jwt.sign({ leaveId: _id }, process.env.JWT_SECRET, { expiresIn: '24h' })}" class="approve-btn">Approve</a>
//                   <a href="${process.env.APP_URL}/api/leave/update/${_id}?status=rejected&token=${jwt.sign({ leaveId: _id }, process.env.JWT_SECRET, { expiresIn: '24h' })}" class="reject-btn">Reject</a>
//                 </div>
//                 <p class="action-text">Please review and approve or reject the leave request using the buttons above.</p>
//               `
//               : recipientRole !== 'employee'
//               ? '<p class="action-text">Please review the request on your dashboard.</p>'
//               : ''
//           }
//         </div>
//         <div class="footer">
//           <p>© 2025 Intellisurge Technologies. All Rights Reserved.</p>
//         </div>
//       </div>
//     </body>
//     </html>
//   `;

//   return { subject, html };
// };

// // WebSocket connection
// io.on('connection', (socket) => {
//   console.log('A user connected:', socket.id);

//   socket.on('join', ({ employeeId, roleType }) => {
//     socket.join(employeeId);
//     if (roleType === 'Manager') {
//       socket.join('managers');
//     }
//     console.log(`${employeeId} joined room`);
//   });

//   socket.on('disconnect', () => {
//     console.log('User disconnected:', socket.id);
//   });
// });

// // Middleware to verify JWT
// const verifyToken = (req, res, next) => {
//   const token = req.headers['authorization']?.split(' ')[1] || req.query.token;
//   if (!token) {
//     return res.status(401).json({ message: 'Token required' });
//   }
//   try {
//     const decoded = jwt.verify(token, process.env.JWT_SECRET);
//     req.user = decoded;
//     next();
//   } catch (error) {
//     res.status(401).json({ message: 'Invalid token' });
//   }
// };

// // Middleware to check if user is an admin
// const isAdmin = async (req, res, next) => {
//   try {
//     const { employeeId } = req.user;
//     const user = await User.findOne({ employeeId });
//     if (!user) {
//       return res.status(401).json({ message: 'User not found' });
//     }
//     if (user.roleType !== 'Admin') {
//       return res.status(403).json({ message: 'Access denied: Admins only' });
//     }
//     next();
//   } catch (error) {
//     console.error('Admin check error:', error);
//     res.status(500).json({ message: 'Server error during admin verification' });
//   }
// };

// // Middleware to check if user is a manager
// const isManager = async (req, res, next) => {
//   try {
//     const { employeeId, roleType } = req.user;
//     if (roleType !== 'Manager') {
//       return res.status(403).json({ message: 'Access denied: Managers only' });
//     }
//     next();
//   } catch (error) {
//     console.error('Manager check error:', error);
//     res.status(500).json({ message: 'Server error during manager verification' });
//   }
// };

// // Middleware to check if user is an employee
// const isEmployee = async (req, res, next) => {
//   try {
//     const { employeeId, roleType } = req.user;
//     if (roleType !== 'Employee') {
//       return res.status(403).json({ message: 'Access denied: Employees only' });
//     }
//     next();
//   } catch (error) {
//     console.error('Employee check error:', error);
//     res.status(500).json({ message: 'Server error during employee verification' });
//   }
// };

// // Middleware to check if user is a manager or admin
// const isManagerOrAdmin = async (req, res, next) => {
//   try {
//     const { employeeId, roleType } = req.user;
//     if (roleType !== 'Manager' && roleType !== 'Admin') {
//       return res.status(403).json({ message: 'Access denied: Managers or Admins only' });
//     }
//     next();
//   } catch (error) {
//     console.error('Manager/Admin check error:', error);
//     res.status(500).json({ message: 'Server error during manager/admin verification' });
//   }
// };

// // Registration endpoint
// app.post('/api/register', async (req, res) => {
//   try {
//     const { initial, name, role, department, roleType, phoneNo, email, password } = req.body;

//     if (!initial || !name || !role || !department || !roleType || !phoneNo || !email || !password) {
//       return res.status(400).json({ message: 'All fields are required' });
//     }

//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//     if (!emailRegex.test(email)) {
//       return res.status(400).json({ message: 'Invalid email format' });
//     }

//     const phoneRegex = /^\d{10}$/;
//     if (!phoneRegex.test(phoneNo)) {
//       return res.status(400).json({ message: 'Phone number must be 10 digits' });
//     }

//     const existingUser = await User.findOne({ email });
//     if (existingUser) {
//       return res.status(400).json({ message: 'Email already registered' });
//     }

//     let prefix;
//     switch (roleType) {
//       case 'Employee':
//         prefix = 'E';
//         break;
//       case 'Manager':
//         prefix = 'M';
//         break;
//       case 'Admin':
//         prefix = 'A';
//         break;
//       default:
//         return res.status(400).json({ message: 'Invalid role type' });
//     }
//     const uniqueId = uuidv4().split('-')[0];
//     const employeeId = `${prefix}-${uniqueId}`;

//     const saltRounds = 10;
//     const hashedPassword = await bcrypt.hash(password, saltRounds);

//     const newUser = new User({
//       employeeId,
//       initial,
//       name,
//       role,
//       department,
//       roleType,
//       phoneNo,
//       email,
//       password: hashedPassword,
//       managerId: roleType === 'Employee' ? req.body.managerId || null : null,
//     });

//     await newUser.save();

//     res.status(201).json({ message: 'User registered successfully', employeeId });
//   } catch (error) {
//     console.error('Registration error:', error);
//     res.status(500).json({ message: 'Server error during registration' });
//   }
// });

// // Login endpoint
// app.post('/api/login', async (req, res) => {
//   try {
//     const { email, password } = req.body;

//     if (!email || !password) {
//       return res.status(400).json({ message: 'Email and password are required' });
//     }

//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//     if (!emailRegex.test(email)) {
//       return res.status(400).json({ message: 'Invalid email format' });
//     }

//     const user = await User.findOne({ email });
//     if (!user) {
//       return res.status(401).json({ message: 'Invalid email or password' });
//     }

//     const isPasswordValid = await bcrypt.compare(password, user.password);
//     if (!isPasswordValid) {
//       return res.status(401).json({ message: 'Invalid email or password' });
//     }

//     const token = jwt.sign(
//       {
//         employeeId: user.employeeId,
//         roleType: user.roleType,
//         managerId: user.managerId || null,
//       },
//       process.env.JWT_SECRET,
//       { expiresIn: '1h' }
//     );

//     res.status(200).json({
//       message: 'Login successful',
//       roleType: user.roleType,
//       employeeId: user.employeeId,
//       token,
//       user: {
//         employeeId: user.employeeId,
//         initial: user.initial,
//         name: user.name,
//         role: user.role,
//         department: user.department,
//         roleType: user.roleType,
//         phoneNo: user.phoneNo,
//         email: user.email,
//         managerId: user.managerId || null,
//       },
//     });
//   } catch (error) {
//     console.error('Login error:', error);
//     res.status(500).json({ message: 'Server error during login' });
//   }
// });

// // Add Task endpoint
// app.post('/api/tasks', verifyToken, async (req, res) => {
//   try {
//     const { employeeId, projectName, activityName, taskDescription, percentComplete, assignedBy } = req.body;

//     if (!employeeId || !projectName || !activityName) {
//       return res.status(400).json({ message: 'Employee ID, project name, and activity name are required' });
//     }

//     const user = await User.findOne({ employeeId });
//     if (!user) {
//       return res.status(400).json({ message: 'Invalid employee ID' });
//     }

//     const newTask = new Task({
//       employeeId,
//       projectName,
//       activityName,
//       taskDescription,
//       percentComplete,
//       assignedBy,
//     });

//     await newTask.save();

//     res.status(201).json({ message: 'Task added successfully', task: newTask });
//   } catch (error) {
//     console.error('Task creation error:', error);
//     res.status(500).json({ message: 'Server error during task creation' });
//   }
// });

// // Get Tasks endpoint
// app.get('/api/tasks/:employeeId', verifyToken, async (req, res) => {
//   try {
//     const { employeeId } = req.params;

//     const tasks = await Task.find({ employeeId });

//     res.status(200).json({ tasks });
//   } catch (error) {
//     console.error('Task fetch error:', error);
//     res.status(500).json({ message: 'Server error during task retrieval' });
//   }
// });

// // Update Task Status endpoint
// app.put('/api/tasks/:taskId', verifyToken, isManager, async (req, res) => {
//   try {
//     const { taskId } = req.params;
//     const { status } = req.body;

//     if (!['Approved', 'Rejected'].includes(status)) {
//       return res.status(400).json({ message: 'Invalid status. Must be Approved or Rejected' });
//     }

//     const task = await Task.findById(taskId);
//     if (!task) {
//       return res.status(404).json({ message: 'Task not found' });
//     }

//     const manager = await User.findOne({ employeeId: req.user.employeeId });
//     if (!manager.assignedEmployees.some(emp => emp.equals(task.employeeId))) {
//       return res.status(403).json({ message: 'Task does not belong to an employee assigned to you' });
//     }

//     task.status = status;
//     await task.save();

//     res.status(200).json({ message: `Task ${status.toLowerCase()} successfully`, task });
//   } catch (error) {
//     console.error('Update task status error:', error);
//     res.status(500).json({ message: 'Server error during task status update' });
//   }
// });

// // Add/Update Timesheet endpoint
// app.post('/api/timesheet', verifyToken, async (req, res) => {
//   try {
//     const { employeeId, projectName, activityName, weekStartDate, hours, loginTimes, logoutTimes } = req.body;

//     if (!employeeId || !projectName || !activityName || !weekStartDate) {
//       return res.status(400).json({ message: 'Employee ID, project name, activity name, and week start date are required' });
//     }

//     const user = await User.findOne({ employeeId });
//     if (!user) {
//       return res.status(400).json({ message: 'Invalid employee ID' });
//     }

//     let timesheet = await Timesheet.findOne({ employeeId, projectName, activityName, weekStartDate });

//     if (timesheet) {
//       timesheet.hours = hours || timesheet.hours;
//       timesheet.loginTimes = loginTimes || timesheet.loginTimes;
//       timesheet.logoutTimes = logoutTimes || timesheet.logoutTimes;
//       await timesheet.save();
//     } else {
//       timesheet = new Timesheet({
//         employeeId,
//         projectName,
//         activityName,
//         weekStartDate,
//         hours: hours || Array(7).fill('00:00'),
//         loginTimes: loginTimes || Array(7).fill(null),
//         logoutTimes: logoutTimes || Array(7).fill(null),
//       });
//       await timesheet.save();
//     }

//     res.status(201).json({ message: 'Timesheet saved successfully', timesheet });
//   } catch (error) {
//     console.error('Timesheet save error:', error);
//     res.status(500).json({ message: 'Server error during timesheet save' });
//   }
// });

// // Get Timesheet endpoint
// app.get('/api/timesheet/:employeeId', verifyToken, async (req, res) => {
//   try {
//     const { employeeId } = req.params;

//     const timesheets = await Timesheet.find({ employeeId });

//     res.status(200).json({ timesheets });
//   } catch (error) {
//     console.error('Timesheet fetch error:', error);
//     res.status(500).json({ message: 'Server error during timesheet retrieval' });
//   }
// });

// // Get all employee details (Admin only)
// app.get('/api/admin/employees', verifyToken, isAdmin, async (req, res) => {
//   try {
//     const { page = 1, limit = 10, roleType, department } = req.query;
//     let query = {};
//     if (roleType) query.roleType = roleType;
//     if (department) query.department = department;

//     const employees = await User.find(query, { password: 0, __v: 0 })
//       .skip((page - 1) * limit)
//       .limit(parseInt(limit));
//     const total = await User.countDocuments(query);

//     res.status(200).json({
//       message: 'Employee details retrieved successfully',
//       employees,
//       total,
//       page: parseInt(page),
//       pages: Math.ceil(total / limit)
//     });
//   } catch (error) {
//     console.error('Fetch employees error:', error);
//     res.status(500).json({ message: 'Server error during employee retrieval' });
//   }
// });

// // Update employee (Admin only)
// app.put('/api/admin/employees/:employeeId', verifyToken, isAdmin, async (req, res) => {
//   try {
//     const { employeeId } = req.params;
//     const { initial, name, role, department, roleType, phoneNo, email, createdAt, address } = req.body;

//     if (!initial || !name || !role || !department || !roleType || !phoneNo || !email) {
//       return res.status(400).json({ message: 'All fields except address and createdAt are required' });
//     }

//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//     if (!emailRegex.test(email)) {
//       return res.status(400).json({ message: 'Invalid email format' });
//     }

//     const phoneRegex = /^\d{10}$/;
//     if (!phoneNo || !phoneRegex.test(phoneNo)) {
//       return res.status(400).json({ message: 'Phone number must be 10 digits' });
//     }

//     const prefix = roleType === 'Employee' ? 'E' : roleType === 'Manager' ? 'M' : 'A';
//     if (!employeeId.startsWith(prefix)) {
//       return res.status(400).json({ message: `Employee ID must start with '${prefix}'` });
//     }

//     const existingUser = await User.findOne({ email, employeeId: { $ne: employeeId } });
//     if (existingUser) {
//       return res.status(400).json({ message: 'Email already registered' });
//     }

//     const updatedUser = await User.findOneAndUpdate(
//       { employeeId },
//       { initial, name, role, department, roleType, phoneNo, email, address, createdAt: createdAt ? new Date(createdAt) : undefined },
//       { new: true, runValidators: true, select: '-password -__v' }
//     );

//     if (!updatedUser) {
//       return res.status(404).json({ message: 'Employee not found' });
//     }

//     res.status(200).json({ message: 'Employee updated successfully', employee: updatedUser });
//   } catch (error) {
//     console.error('Update employee error:', error);
//     res.status(500).json({ message: 'Server error during employee update' });
//   }
// });

// // Delete employee (Admin only)
// app.delete('/api/admin/employees/:employeeId', verifyToken, isAdmin, async (req, res) => {
//   try {
//     const { employeeId } = req.params;

//     const deletedUser = await User.findOneAndDelete({ employeeId });
//     if (!deletedUser) {
//       return res.status(404).json({ message: 'Employee not found' });
//     }

//     await Task.deleteMany({ employeeId });
//     await Timesheet.deleteMany({ employeeId });
//     await Assignment.deleteMany({ $or: [{ employeeId: deletedUser._id }, { managerId: employeeId }] });
//     await LeaveRequest.deleteMany({ employeeId });

//     res.status(200).json({ message: 'Employee deleted successfully' });
//   } catch (error) {
//     console.error('Delete employee error:', error);
//     res.status(500).json({ message: 'Server error during employee deletion' });
//   }
// });

// // Assign employee to manager (Admin only)
// app.post('/api/admin/assign-employee', verifyToken, isAdmin, async (req, res) => {
//   try {
//     const { employeeId, managerId } = req.body;

//     if (!employeeId || !managerId) {
//       return res.status(400).json({ message: 'Employee ID and Manager ID are required' });
//     }

//     const employee = await User.findOne({ employeeId, roleType: 'Employee' });
//     if (!employee) {
//       return res.status(404).json({ message: 'Employee not found or invalid role type' });
//     }

//     const manager = await User.findOne({ employeeId: managerId, roleType: 'Manager' });
//     if (!manager) {
//       return res.status(404).json({ message: 'Manager not found or invalid role type' });
//     }

//     const admin = await User.findOne({ employeeId: req.user.employeeId });
//     if (!admin) {
//       return res.status(404).json({ message: 'Admin not found' });
//     }

//     const existingAssignment = await Assignment.findOne({ employeeId: employee._id, managerId, status: 'Pending' });
//     if (existingAssignment) {
//       return res.status(400).json({ message: 'Employee is already assigned to this manager and pending approval' });
//     }

//     const assignment = new Assignment({
//       employeeId: employee._id,
//       managerId,
//       assignedBy: admin._id,
//       status: 'Pending',
//     });

//     await assignment.save();

//     await User.findOneAndUpdate(
//       { employeeId },
//       { managerId },
//       { new: true }
//     );

//     res.status(201).json({ message: 'Employee assigned to manager successfully', assignment });
//   } catch (error) {
//     console.error('Assign employee error:', error);
//     res.status(500).json({ message: 'Server error during employee assignment' });
//   }
// });

// // Get pending assignments for a manager
// app.get('/api/manager/assignments', verifyToken, async (req, res) => {
//   try {
//     const { employeeId, roleType } = req.user;

//     if (roleType !== 'Manager') {
//       return res.status(403).json({ message: 'Access denied: Managers only' });
//     }

//     const assignments = await Assignment.find({ managerId: employeeId, status: 'Pending' })
//       .populate('employeeId', 'name initial employeeId email')
//       .populate('assignedBy', 'name employeeId');

//     res.status(200).json({ assignments });
//   } catch (error) {
//     console.error('Fetch assignments error:', error);
//     res.status(500).json({ message: 'Server error during assignments retrieval' });
//   }
// });

// // Accept or reject assignment (Manager only)
// app.put('/api/manager/assignments/:assignmentId', verifyToken, async (req, res) => {
//   try {
//     const { assignmentId } = req.params;
//     const { status } = req.body;
//     const { employeeId, roleType } = req.user;

//     if (roleType !== 'Manager') {
//       return res.status(403).json({ message: 'Access denied: Managers only' });
//     }

//     if (!['Accepted', 'Rejected'].includes(status)) {
//       return res.status(400).json({ message: 'Invalid status. Must be Accepted or Rejected' });
//     }

//     const assignment = await Assignment.findOne({ _id: assignmentId, managerId: employeeId });
//     if (!assignment) {
//       return res.status(404).json({ message: 'Assignment not found or you are not authorized' });
//     }

//     assignment.status = status;
//     await assignment.save();

//     if (status === 'Accepted') {
//       await User.findOneAndUpdate(
//         { employeeId: assignment.managerId },
//         { $addToSet: { assignedEmployees: assignment.employeeId } },
//         { new: true }
//       );
//     }

//     res.status(200).json({ message: `Assignment ${status.toLowerCase()} successfully`, assignment });
//   } catch (error) {
//     console.error('Update assignment error:', error);
//     res.status(500).json({ message: 'Server error during assignment update' });
//   }
// });

// // Get assigned employees for a manager
// app.get('/api/manager/employees', verifyToken, async (req, res) => {
//   try {
//     const { employeeId, roleType } = req.user;

//     if (roleType !== 'Manager') {
//       return res.status(403).json({ message: 'Access denied: Managers only' });
//     }

//     const manager = await User.findOne({ employeeId }).populate('assignedEmployees', 'name initial employeeId email department role');
//     if (!manager) {
//       return res.status(404).json({ message: 'Manager not found' });
//     }

//     res.status(200).json({ employees: manager.assignedEmployees });
//   } catch (error) {
//     console.error('Fetch assigned employees error:', error);
//     res.status(500).json({ message: 'Server error during assigned employees retrieval' });
//   }
// });

// // Get attendance report for a manager's assigned employees
// app.get('/api/manager/attendance', verifyToken, isManager, async (req, res) => {
//   try {
//     const { employeeId } = req.user;

//     const manager = await User.findOne({ employeeId }).populate('assignedEmployees', 'name employeeId');
//     if (!manager) {
//       return res.status(404).json({ message: 'Manager not found' });
//     }

//     const employeeIds = manager.assignedEmployees.map(emp => emp.employeeId);
//     if (employeeIds.length === 0) {
//       return res.status(200).json({ attendance: [] });
//     }

//     const timesheets = await Timesheet.find({ employeeId: { $in: employeeIds } });

//     const attendance = [];
//     for (const timesheet of timesheets) {
//       const employee = manager.assignedEmployees.find(emp => emp.employeeId === timesheet.employeeId);
//       const weekStartDate = new Date(timesheet.weekStartDate);

//       for (let day = 0; day < 7; day++) {
//         const currentDate = new Date(weekStartDate);
//         currentDate.setDate(weekStartDate.getDate() + day);

//         const loginTime = timesheet.loginTimes[day];
//         const logoutTime = timesheet.logoutTimes[day];
//         const status = loginTime ? 'Present' : 'Absent';

//         attendance.push({
//           employeeId: timesheet.employeeId,
//           name: employee.name,
//           date: currentDate.toISOString().split('T')[0],
//           checkInTime: loginTime || 'N/A',
//           checkOutTime: logoutTime || 'N/A',
//           status,
//         });
//       }
//     }

//     res.status(200).json({ attendance });
//   } catch (error) {
//     console.error('Fetch attendance error:', error);
//     res.status(500).json({ message: 'Server error during attendance retrieval' });
//   }
// });

// // Get attendance report for an employee
// app.get('/api/employee/attendance', verifyToken, isEmployee, async (req, res) => {
//   try {
//     const { employeeId } = req.user;

//     const timesheets = await Timesheet.find({ employeeId });

//     const attendance = [];
//     for (const timesheet of timesheets) {
//       const weekStartDate = new Date(timesheet.weekStartDate);

//       for (let day = 0; day < 7; day++) {
//         const currentDate = new Date(weekStartDate);
//         currentDate.setDate(weekStartDate.getDate() + day);

//         const loginTime = timesheet.loginTimes[day];
//         const logoutTime = timesheet.logoutTimes[day];

//         let totalWorkedTime = 'N/A';
//         if (loginTime && logoutTime) {
//           const login = new Date(`2025-05-06 ${loginTime}`);
//           const logout = new Date(`2025-05-06 ${logoutTime}`);
//           const hoursWorked = (logout - login) / (1000 * 60 * 60);
//           totalWorkedTime = `${hoursWorked.toFixed(2)} hrs`;
//         }

//         if (loginTime || logoutTime) {
//           attendance.push({
//             date: currentDate.toISOString().split('T')[0],
//             login: loginTime || 'N/A',
//             logout: logoutTime || 'N/A',
//             totalWorkedTime,
//           });
//         }
//       }
//     }

//     res.status(200).json({ attendance });
//   } catch (error) {
//     console.error('Fetch employee attendance error:', error);
//     res.status(500).json({ message: 'Server error during employee attendance retrieval' });
//   }
// });

// // Get user details by employeeId
// app.get('/api/user/:employeeId', verifyToken, async (req, res) => {
//   try {
//     const { employeeId } = req.params;

//     const user = await User.findOne({ employeeId }, { password: 0, __v: 0 });
//     if (!user) {
//       return res.status(404).json({ message: 'User not found' });
//     }

//     res.status(200).json({ user });
//   } catch (error) {
//     console.error('Fetch user error:', error);
//     res.status(500).json({ message: 'Server error during user retrieval' });
//   }
// });

// // Submit Leave Request (Employee only)
// app.post('/api/leave/apply', verifyToken, isEmployee, async (req, res) => {
//   try {
//     const { employeeId, leaveType, fromDate, toDate, reason, status } = req.body;

//     if (!employeeId || !leaveType || !fromDate || !toDate || !reason) {
//       return res.status(400).json({ message: 'All fields are required' });
//     }

//     if (!['sick', 'casual', 'emergency'].includes(leaveType)) {
//       return res.status(400).json({ message: 'Invalid leave type. Must be sick, casual, or emergency' });
//     }

//     const dateRegex = /^\d{2}-\d{2}-\d{4}$/;
//     if (!dateRegex.test(fromDate) || !dateRegex.test(toDate)) {
//       return res.status(400).json({ message: 'Dates must be in DD-MM-YYYY format' });
//     }

//     const fromDateObj = new Date(fromDate.split('-').reverse().join('-'));
//     const toDateObj = new Date(toDate.split('-').reverse().join('-'));
//     if (fromDateObj > toDateObj) {
//       return res.status(400).json({ message: 'From date cannot be later than to date' });
//     }

//     const employee = await User.findOne({ employeeId });
//     if (!employee) {
//       return res.status(404).json({ message: 'Employee not found' });
//     }

//     let manager = null;
//     if (employee.managerId) {
//       manager = await User.findOne({ employeeId: employee.managerId });
//       if (!manager) {
//         return res.status(404).json({ message: 'Manager not found' });
//       }
//     }

//     const leaveRequest = new LeaveRequest({
//       employeeId,
//       employeeName: employee.name,
//       leaveType,
//       fromDate,
//       toDate,
//       reason,
//       status: status || 'pending',
//     });
//     await leaveRequest.save();

//     const employeeEmail = generateEmailTemplate(leaveRequest, employee.name, 'employee');
//     const adminEmail = generateEmailTemplate(leaveRequest, employee.name, 'admin');
//     const emails = [
//       {
//         from: process.env.EMAIL_USER,
//         to: employee.email,
//         subject: employeeEmail.subject,
//         html: employeeEmail.html,
//       },
//       {
//         from: process.env.EMAIL_USER,
//         to: process.env.ADMIN_EMAIL || 'admin@company.com',
//         subject: adminEmail.subject,
//         html: adminEmail.html,
//       },
//     ];

//     if (manager) {
//       const managerEmail = generateEmailTemplate(leaveRequest, employee.name, 'manager');
//       emails.push({
//         from: process.env.EMAIL_USER,
//         to: manager.email,
//         subject: managerEmail.subject,
//         html: managerEmail.html,
//       });
//     }

//     await Promise.all(emails.map(email => transporter.sendMail(email)));

//     io.to('managers').emit('newLeaveRequest', {
//       leaveId: leaveRequest._id,
//       employeeId,
//       employeeName: employee.name,
//       leaveType,
//       fromDate,
//       toDate,
//       reason,
//       status: 'pending',
//       createdAt: leaveRequest.createdAt,
//     });

//     res.status(201).json({ message: 'Leave request submitted successfully', leaveRequest });
//   } catch (error) {
//     console.error('Submit leave request error:', error);
//     res.status(500).json({ message: 'Server error during leave request submission' });
//   }
// });

// // Approve or Reject Leave Request via GET (for email links, Manager or Admin only)
// app.get('/api/leave/update/:leaveId', verifyToken, isManagerOrAdmin, async (req, res) => {
//   try {
//     const { leaveId } = req.params;
//     const { status } = req.query;
//     const { employeeId, roleType } = req.user;

//     if (!['approved', 'rejected'].includes(status)) {
//       return res.status(400).json({ message: 'Invalid status. Must be approved or rejected' });
//     }

//     const leaveRequest = await LeaveRequest.findById(leaveId);
//     if (!leaveRequest) {
//       return res.status(404).json({ message: 'Leave request not found' });
//     }

//     if (roleType === 'Manager') {
//       const manager = await User.findOne({ employeeId }).populate('assignedEmployees', 'employeeId');
//       if (!manager) {
//         return res.status(404).json({ message: 'Manager not found' });
//       }
//       const employeeIds = manager.assignedEmployees.map(emp => emp.employeeId);
//       if (!employeeIds.includes(leaveRequest.employeeId)) {
//         return res.status(403).json({ message: 'You are not authorized to review this leave request' });
//       }
//     }

//     leaveRequest.status = status;
//     leaveRequest.reviewedBy = employeeId;
//     leaveRequest.reviewedAt = new Date();
//     await leaveRequest.save();

//     const employee = await User.findOne({ employeeId: leaveRequest.employeeId });
//     if (!employee) {
//       return res.status(404).json({ message: 'Employee not found' });
//     }

//     const statusEmail = {
//       subject: `Leave Request ${status.charAt(0).toUpperCase() + status.slice(1)}`,
//       html: `
//         <!DOCTYPE html>
//         <html lang="en">
//         <head>
//           <meta charset="UTF-8">
//           <meta name="viewport" content="width=device-width, initial-scale=1.0">
//           <title>Leave Request Status Update</title>
//           <style>
//             body {
//               font-family: 'Helvetica Neue', Arial, sans-serif;
//               background-color: #f4f4f4;
//               margin: 0;
//               padding: 0;
//             }
//             .container {
//               max-width: 600px;
//               margin: 20px auto;
//               background-color: #ffffff;
//               border-radius: 12px;
//               box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
//               overflow: hidden;
//             }
//             .header {
//               background: linear-gradient(90deg, #003087, #0059b3);
//               padding: 30px;
//               text-align: center;
//             }
//             .header h1 {
//               color: #ffffff;
//               margin: 0;
//               font-size: 28px;
//               font-weight: 700;
//             }
//             .content {
//               padding: 30px;
//             }
//             .content h2 {
//               color: #003087;
//               font-size: 22px;
//               margin-bottom: 20px;
//               text-align: center;
//             }
//             .content p {
//               color: #333333;
//               font-size: 16px;
//               line-height: 1.6;
//               margin: 10px 0;
//             }
//             .details-table {
//               width: 100%;
//               border-collapse: collapse;
//               margin: 20px 0;
//               background-color: #f9f9f9;
//               border-radius: 8px;
//               overflow: hidden;
//             }
//             .details-table th,
//             .details-table td {
//               padding: 15px;
//               text-align: left;
//               border-bottom: 1px solid #e0e0e0;
//             }
//             .details-table th {
//               background-color: #003087;
//               color: #ffffff;
//               width: 35%;
//               font-weight: 600;
//             }
//             .details-table td {
//               color: #333333;
//             }
//             .footer {
//               background-color: #003087;
//               padding: 15px;
//               text-align: center;
//             }
//             .footer p {
//               color: #ffffff;
//               margin: 0;
//               font-size: 12px;
//             }
//           </style>
//         </head>
//         <body>
//           <div class="container">
//             <div class="header">
//               <h1>Leave Request Status Update</h1>
//             </div>
//             <div class="content">
//               <h2>Your Leave Request Has Been ${status.charAt(0).toUpperCase() + status.slice(1)}</h2>
//               <p>Dear ${employee.name},</p>
//               <p>Your leave request has been ${status} by ${roleType} (${employeeId}).</p>
//               <table class="details-table">
//                 <tr>
//                   <th>Leave Type</th>
//                   <td>${leaveRequest.leaveType.charAt(0).toUpperCase() + leaveRequest.leaveType.slice(1)} Leave</td>
//                 </tr>
//                 <tr>
//                   <th>From Date</th>
//                   <td>${leaveRequest.fromDate}</td>
//                 </tr>
//                 <tr>
//                   <th>To Date</th>
//                   <td>${leaveRequest.toDate}</td>
//                 </tr>
//                 <tr>
//                   <th>Reason</th>
//                   <td>${leaveRequest.reason}</td>
//                 </tr>
//               </table>
//             </div>
//             <div class="footer">
//               <p>© 2025 Intellisurge Technologies. All Rights Reserved.</p>
//             </div>
//           </div>
//         </body>
//         </html>
//       `,
//     };

//     await transporter.sendMail({
//       from: process.env.EMAIL_USER,
//       to: employee.email,
//       subject: statusEmail.subject,
//       html: statusEmail.html,
//     });

//     io.to(leaveRequest.employeeId).emit('leaveStatusUpdate', {
//       leaveId,
//       status,
//       reviewedBy: employeeId,
//       reviewedAt: new Date(),
//     });
//     io.to('managers').emit('leaveStatusUpdate', {
//       leaveId,
//       status,
//       employeeId: leaveRequest.employeeId,
//       reviewedBy: employeeId,
//       reviewedAt: new Date(),
//     });

//     const redirectUrl = `${process.env.APP_URL}/leave-decisions?leaveId=${leaveId}&status=${status}&employeeId=${employeeId}`;
//     res.redirect(redirectUrl);
//   } catch (error) {
//     console.error('Update leave request error:', error);
//     res.status(500).send(`
//       <!DOCTYPE html>
//       <html lang="en">
//       <head>
//         <meta charset="UTF-8">
//         <meta name="viewport" content="width=device-width, initial-scale=1.0">
//         <title>Error</title>
//         <style>
//           body {
//             font-family: 'Helvetica Neue', Arial, sans-serif;
//             background-color: #f4f4f4;
//             margin: 0;
//             padding: 0;
//             display: flex;
//             justify-content: center;
//             align-items: center;
//             height: 100vh;
//           }
//           .container {
//             max-width: 600px;
//             background-color: #ffffff;
//             border-radius: 8px;
//             padding: 20px;
//             text-align: center;
//           }
//           .header h1 {
//             color: #333333;
//             font-size: 24px;
//             margin-bottom: 20px;
//           }
//           p {
//             color: #555555;
//             font-size: 16px;
//             margin-bottom: 20px;
//           }
//           a {
//             display: inline-block;
//             padding: 10px 20px;
//             background-color: #003087;
//             color: #ffffff;
//             text-decoration: none;
//             border-radius: 4px;
//             font-weight: 600;
//           }
//           a:hover {
//             background-color: #002343;
//           }
//         </style>
//       </head>
//       <body>
//         <div class="container">
//           <div class="header">
//             <h1>Error Updating Leave Request</h1>
//           </div>
//           <p>An error occurred: ${error.message}</p>
//           <a href="${process.env.APP_URL}/dashboard">Return to Dashboard</a>
//         </div>
//       </body>
//       </html>
//     `);
//   }
// });

// // Approve or Reject Leave Request via PUT (for frontend API calls, Manager or Admin only)
// app.put('/api/leave/update/:leaveId', verifyToken, isManagerOrAdmin, async (req, res) => {
//   try {
//     const { leaveId } = req.params;
//     const { status } = req.body;
//     const { employeeId, roleType } = req.user;

//     if (!['approved', 'rejected'].includes(status)) {
//       return res.status(400).json({ message: 'Invalid status. Must be approved or rejected' });
//     }

//     const leaveRequest = await LeaveRequest.findById(leaveId);
//     if (!leaveRequest) {
//       return res.status(404).json({ message: 'Leave request not found' });
//     }

//     if (roleType === 'Manager') {
//       const manager = await User.findOne({ employeeId }).populate('assignedEmployees', 'employeeId');
//       if (!manager) {
//         return res.status(404).json({ message: 'Manager not found' });
//       }
//       const employeeIds = manager.assignedEmployees.map(emp => emp.employeeId);
//       if (!employeeIds.includes(leaveRequest.employeeId)) {
//         return res.status(403).json({ message: 'You are not authorized to review this leave request' });
//       }
//     }

//     leaveRequest.status = status;
//     leaveRequest.reviewedBy = employeeId;
//     leaveRequest.reviewedAt = new Date();
//     await leaveRequest.save();

//     const employee = await User.findOne({ employeeId: leaveRequest.employeeId });
//     if (!employee) {
//       return res.status(404).json({ message: 'Employee not found' });
//     }

//     const statusEmail = {
//       subject: `Leave Request ${status.charAt(0).toUpperCase() + status.slice(1)}`,
//       html: `
//         <!DOCTYPE html>
//         <html lang="en">
//         <head>
//           <meta charset="UTF-8">
//           <meta name="viewport" content="width=device-width, initial-scale=1.0">
//           <title>Leave Request Status Update</title>
//           <style>
//             body {
//               font-family: 'Helvetica Neue', Arial, sans-serif;
//               background-color: #f4f4f4;
//               margin: 0;
//               padding: 0;
//             }
//             .container {
//               max-width: 600px;
//               margin: 20px auto;
//               background-color: #ffffff;
//               border-radius: 12px;
//               box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
//               overflow: hidden;
//             }
//             .header {
//               background: linear-gradient(90deg, #003087, #0059b3);
//               padding: 30px;
//               text-align: center;
//             }
//             .header h1 {
//               color: #ffffff;
//               margin: 0;
//               font-size: 28px;
//               font-weight: 700;
//             }
//             .content {
//               padding: 30px;
//             }
//             .content h2 {
//               color: #003087;
//               font-size: 22px;
//               margin-bottom: 20px;
//               text-align: center;
//             }
//             .content p {
//               color: #333333;
//               font-size: 16px;
//               line-height: 1.6;
//               margin: 10px 0;
//             }
//             .details-table {
//               width: 100%;
//               border-collapse: collapse;
//               margin: 20px 0;
//               background-color: #f9f9f9;
//               border-radius: 8px;
//               overflow: hidden;
//             }
//             .details-table th,
//             .details-table td {
//               padding: 15px;
//               text-align: left;
//               border-bottom: 1px solid #e0e0e0;
//             }
//             .details-table th {
//               background-color: #003087;
//               color: #ffffff;
//               width: 35%;
//               font-weight: 600;
//             }
//             .details-table td {
//               color: #333333;
//             }
//             .footer {
//               background-color: #003087;
//               padding: 15px;
//               text-align: center;
//             }
//             .footer p {
//               color: #ffffff;
//               margin: 0;
//               font-size: 12px;
//             }
//           </style>
//         </head>
//         <body>
//           <div class="container">
//             <div class="header">
//               <h1>Leave Request Status Update</h1>
//             </div>
//             <div class="content">
//               <h2>Your Leave Request Has Been ${status.charAt(0).toUpperCase() + status.slice(1)}</h2>
//               <p>Dear ${employee.name},</p>
//               <p>Your leave request has been ${status} by ${roleType} (${employeeId}).</p>
//               <table class="details-table">
//                 <tr>
//                   <th>Leave Type</th>
//                   <td>${leaveRequest.leaveType.charAt(0).toUpperCase() + leaveRequest.leaveType.slice(1)} Leave</td>
//                 </tr>
//                 <tr>
//                   <th>From Date</th>
//                   <td>${leaveRequest.fromDate}</td>
//                 </tr>
//                 <tr>
//                   <th>To Date</th>
//                   <td>${leaveRequest.toDate}</td>
//                 </tr>
//                 <tr>
//                   <th>Reason</th>
//                   <td>${leaveRequest.reason}</td>
//                 </tr>
//               </table>
//             </div>
//             <div class="footer">
//               <p>© 2025 Intellisurge Technologies. All Rights Reserved.</p>
//             </div>
//           </div>
//         </body>
//         </html>
//       `,
//     };

//     await transporter.sendMail({
//       from: process.env.EMAIL_USER,
//       to: employee.email,
//       subject: statusEmail.subject,
//       html: statusEmail.html,
//     });

//     io.to(leaveRequest.employeeId).emit('leaveStatusUpdate', {
//       leaveId,
//       status,
//       reviewedBy: employeeId,
//       reviewedAt: new Date(),
//     });
//     io.to('managers').emit('leaveStatusUpdate', {
//       leaveId,
//       status,
//       employeeId: leaveRequest.employeeId,
//       reviewedBy: employeeId,
//       reviewedAt: new Date(),
//     });

//     res.status(200).json({
//       message: `Leave request ${status} successfully`,
//       leaveRequest: {
//         _id: leaveRequest._id,
//         employeeId: leaveRequest.employeeId,
//         employeeName: leaveRequest.employeeName,
//         leaveType: leaveRequest.leaveType,
//         fromDate: leaveRequest.fromDate,
//         toDate: leaveRequest.toDate,
//         reason: leaveRequest.reason,
//         status: leaveRequest.status,
//         reviewedBy: leaveRequest.reviewedBy,
//         reviewedAt: leaveRequest.reviewedAt,
//         createdAt: leaveRequest.createdAt,
//       },
//     });
//   } catch (error) {
//     console.error('Update leave request error:', error);
//     res.status(500).json({ message: `Server error during leave request update: ${error.message}` });
//   }
// });



// new 


//working 

// require('dotenv').config();
// const express = require('express');
// const mongoose = require('mongoose');
// const bcrypt = require('bcryptjs');
// const { v4: uuidv4 } = require('uuid');
// const jwt = require('jsonwebtoken');
// const nodemailer = require('nodemailer');
// const http = require('http');
// const { Server } = require('socket.io');
// const User = require('./models/User');
// const Task = require('./models/Task');
// const Timesheet = require('./models/Timesheet');
// const Assignment = require('./models/Assignment');
// const LeaveRequest = require('./models/LeaveRequest');
// const OTP = require('./models/Otp');
// const ResetRequest = require('./models/ResetRequest');

// const app = express();
// const PORT = process.env.PORT || 5001;

// const server = http.createServer(app);
// const io = new Server(server, {
//   cors: {
//     origin: process.env.APP_URL ,
//     methods: ['GET', 'POST'],
//   },
// });

// app.use(express.json());

// mongoose.connect(process.env.MONGO_URI, {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// })
//   .then(() => console.log('Connected to MongoDB'))
//   .catch((error) => console.error('MongoDB connection error:', error));

// const transporter = nodemailer.createTransport({
//   service: 'gmail',
//   auth: {
//     user: process.env.EMAIL_USER,
//     pass: process.env.EMAIL_PASS,
//   },
// });

// // Endpoint to check Nodemailer transporter status
// app.get('/api/health/email', async (req, res) => {
//   try {
//     await transporter.verify();
//     res.status(200).json({
//       status: 'success',
//       message: 'Nodemailer transporter is active and configured correctly',
//       emailService: 'Gmail',
//       emailUser: process.env.EMAIL_USER,
//     });
//   } catch (error) {
//     let errorMessage = 'Nodemailer transporter verification failed';
//     let errorDetails = error.message;
//     if (error.code === 'EAUTH') {
//       errorMessage = 'Authentication failed';
//       errorDetails = 'Invalid EMAIL_USER or EMAIL_PASS. Please check your Gmail credentials or App Password.';
//     } else if (error.code === 'ECONNREFUSED') {
//       errorMessage = 'Connection refused';
//       errorDetails = 'Unable to connect to Gmail SMTP server. Check your network or Gmail service status.';
//     }
//     console.error('Nodemailer verification error:', error);
//     res.status(500).json({
//       status: 'error',
//       message: errorMessage,
//       details: errorDetails,
//     });
//   }
// });





// const verifyToken = (req, res, next) => {
//   const token = req.headers['authorization']?.split(' ')[1] || req.query.token;
//   if (!token) {
//     return res.status(401).json({ message: 'Token required' });
//   }
//   try {
//     const decoded = jwt.verify(token, process.env.JWT_SECRET);
//     req.user = decoded;
//     next();
//   } catch (error) {
//     res.status(401).json({ message: 'Invalid token' });
//   }
// };

// // Middleware to check if user is an admin
// const isAdmin = async (req, res, next) => {
//   try {
//     const { employeeId } = req.user;
//     const user = await User.findOne({ employeeId });
//     if (!user) {
//       return res.status(401).json({ message: 'User not found' });
//     }
//     if (user.roleType !== 'Admin') {
//       return res.status(403).json({ message: 'Access denied: Admins only' });
//     }
//     next();
//   } catch (error) {
//     console.error('Admin check error:', error);
//     res.status(500).json({ message: 'Server error during admin verification' });
//   }
// };

// // Middleware to check if user is a manager
// const isManager = async (req, res, next) => {
//   try {
//     const { employeeId, roleType } = req.user;
//     if (roleType !== 'Manager') {
//       return res.status(403).json({ message: 'Access denied: Managers only' });
//     }
//     next();
//   } catch (error) {
//     console.error('Manager check error:', error);
//     res.status(500).json({ message: 'Server error during manager verification' });
//   }
// };

// // Middleware to check if user is an employee
// const isEmployee = async (req, res, next) => {
//   try {
//     const { employeeId, roleType } = req.user;
//     if (roleType !== 'Employee') {
//       return res.status(403).json({ message: 'Access denied: Employees only' });
//     }
//     next();
//   } catch (error) {
//     console.error('Employee check error:', error);
//     res.status(500).json({ message: 'Server error during employee verification' });
//   }
// };

// // Middleware to check if user is a manager or admin
// const isManagerOrAdmin = async (req, res, next) => {
//   try {
//     const { employeeId, roleType } = req.user;
//     if (roleType !== 'Manager' && roleType !== 'Admin') {
//       return res.status(403).json({ message: 'Access denied: Managers or Admins only' });
//     }
//     next();
//   } catch (error) {
//     console.error('Manager/Admin check error:', error);
//     res.status(500).json({ message: 'Server error during manager/admin verification' });
//   }
// };

// // Generate OTP
// const generateOTP = () => {
//   return Math.floor(100000 + Math.random() * 900000).toString();
// };

// // Store OTPs and password reset requests temporarily (in-memory for simplicity, consider Redis in production)
// const otpStore = new Map();
// const resetRequestStore = new Map();

// // Password reset approval email template
// // Password reset approval email template

// // Send Email Function
// const sendEmail = async (to, subject, html) => {
//   try {
//     await transporter.sendMail({
//       from: process.env.EMAIL_USER,
//       to,
//       subject,
//       html,
//     });
//     console.log(`Email sent to ${to}`);
//   } catch (error) {
//     console.error(`Email sending error to ${to}:`, error);
//     throw new Error('Failed to send email');
//   }
// };
// const generateApprovalEmail = (email, userName, approvalToken) => {
//   return {
//     subject: `Password Reset Approval Request for ${userName}`,
//     html: `
//       <!DOCTYPE html>
//       <html lang="en">
//       <head>
//         <meta charset="UTF-8">
//         <meta name="viewport" content="width=device-width, initial-scale=1.0">
//         <title>Password Reset Approval Request</title>
//         <style>
//           body {
//             font-family: 'Helvetica Neue', Arial, sans-serif;
//             background-color: #f4f4f4;
//             margin: 0;
//             padding: 0;
//           }
//           .container {
//             max-width: 600px;
//             margin: 20px auto;
//             background-color: #ffffff;
//             border-radius: 8px;
//             box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
//             overflow: hidden;
//           }
//           .header {
//             background: linear-gradient(90deg, #003087, #0059b3);
//             padding: 30px;
//             text-align: center;
//           }
//           .header h1 {
//             color: #ffffff;
//             margin: 0;
//             font-size: 28px;
//             font-weight: 700;
//           }
//           .content {
//             padding: 30px;
//             text-align: center;
//           }
//           .content p {
//             color: #333333;
//             font-size: 16px;
//             line-height: 1.6;
//             margin: 10px 0;
//           }
//           .action-buttons {
//             margin: 20px 0;
//           }
//           .action-buttons a {
//             display: inline-block;
//             padding: 12px 24px;
//             margin: 0 10px;
//             text-decoration: none;
//             font-weight: 600;
//             border-radius: 6px;
//             color: #ffffff;
//           }
//           .approve-btn {
//             background-color: #28a745;
//           }
//           .reject-btn {
//             background-color: #dc3545;
//           }
//           .footer {
//             background-color: #003087;
//             padding: 15px;
//             text-align: center;
//           }
//           .footer p {
//             color: #ffffff;
//             margin: 0;
//             font-size: 12px;
//           }
//         </style>
//       </head>
//       <body>
//         <div class="container">
//           <div class="header">
//             <h1>Password Reset Approval Request</h1>
//           </div>
//           <div class="content">
//             <p>Dear Admin,</p>
//             <p>A password reset request has been received for ${userName} (${email}).</p>
//             <p>Please approve or reject this request using the buttons below.</p>
//             <div class="action-buttons">
//               <a href="${process.env.APP_URL}/api/reset-approval/${approvalToken}?status=approved" class="approve-btn">Approve</a>
//               <a href="${process.env.APP_URL}/api/reset-approval/${approvalToken}?status=rejected" class="reject-btn">Reject</a>
//             </div>
//             <p>If you did not initiate this action, please contact support immediately.</p>
//           </div>
//           <div class="footer">
//             <p>© 2025 Intellisurge Technologies. All Rights Reserved.</p>
//           </div>
//         </div>
//       </body>
//       </html>
//     `,
//   };
// };

// // Forgot Password Endpoint
// app.post('/api/forgot-password', async (req, res) => {
//   try {
//     const { email } = req.body;
//     console.log('Received forgot password request for email:', email);
//     if (!email) {
//       return res.status(400).json({ message: 'Email is required' });
//     }

//     // Case-insensitive email lookup
//     const user = await User.findOne({ email: { $regex: `^${email}$`, $options: 'i' } });
//     if (!user) {
//       console.log('No user found for email:', email);
//       return res.status(404).json({ message: 'Email not registered. Please check the email or contact support.' });
//     }
//     console.log('User found:', { email: user.email, employeeId: user.employeeId });

//     if (!user.employeeId) {
//       console.log('User missing employeeId:', user.email);
//       return res.status(400).json({ message: 'Invalid user data. Contact support.' });
//     }

//     if (user.roleType !== 'Employee') {
//       // Non-employee flow: Send OTP directly to user
//       const otp = generateOTP();
//       await OTP.create({
//         email: user.email,
//         otp,
//         expires: new Date(Date.now() + 10 * 60 * 1000),
//         ipAddress: req.ip,
//       });
//       const otpEmailHtml = `
//         <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4;">
//           <div style="background-color: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
//             <h2 style="color: #003087; text-align: center;">Password Reset OTP</h2>
//             <p style="color: #333333; font-size: 16px; text-align: center;">
//               Your OTP for password reset is:
//             </p>
//             <p style="font-size: 24px; font-weight: bold; color: #28a745; text-align: center; margin: 20px 0;">
//               ${otp}
//             </p>
//             <p style="color: #333333; font-size: 14px; text-align: center;">
//               This OTP is valid for 10 minutes. Do not share it with anyone.
//             </p>
//           </div>
//         </div>
//       `;
//       await sendEmail(user.email, 'Password Reset OTP', otpEmailHtml);
//       console.log('OTP email sent to:', user.email);
//       return res.status(200).json({ message: 'OTP sent to your email' });
//     }

//     // Employee flow: Send approval email to admin
//     const admin = await User.findOne({ roleType: 'Admin' });
//     if (!admin) {
//       console.log('No admin found');
//       return res.status(404).json({ message: 'Admin not found' });
//     }

//     const approvalToken = jwt.sign(
//       { email: user.email, employeeId: user.employeeId },
//       process.env.JWT_SECRET,
//       { expiresIn: '1h' }
//     );

//     const approvalEmail = generateApprovalEmail(user.email, user.name, approvalToken);
//     await sendEmail(admin.email, approvalEmail.subject, approvalEmail.html);
//     console.log('Approval email sent to admin:', admin.email);

//     res.status(200).json({ message: 'Reset request sent to admin for approval' });
//   } catch (error) {
//     console.error('Forgot password error:', error);
//     res.status(500).json({ message: 'Server error' });
//   }
// });

// // Reset Approval/Rejection Endpoint
// app.get('/api/reset-approval/:approvalToken', async (req, res) => {
//   try {
//     const { approvalToken } = req.params;
//     const { status } = req.query;
//     console.log('Processing reset approval:', { approvalToken, status });

//     if (!['approved', 'rejected'].includes(status)) {
//       return res.status(400).json({ message: 'Invalid status' });
//     }

//     let decoded;
//     try {
//       decoded = jwt.verify(approvalToken, process.env.JWT_SECRET);
//     } catch (error) {
//       console.log('Invalid approval token:', error.message);
//       return res.status(401).json({ message: 'Invalid or expired approval token' });
//     }

//     const user = await User.findOne({ email: { $regex: `^${decoded.email}$`, $options: 'i' } });
//     if (!user) {
//       console.log('User not found for email:', decoded.email);
//       return res.status(404).json({ message: 'User not found. Contact support.' });
//     }
//     console.log('User found:', { email: user.email, employeeId: user.employeeId });

//     if (user.employeeId !== decoded.employeeId) {
//       console.log('Employee ID mismatch:', { user: user.employeeId, token: decoded.employeeId });
//       return res.status(400).json({ message: 'Employee ID does not match' });
//     }

//     if (status === 'rejected') {
//       const rejectionEmailHtml = `
//         <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4;">
//           <div style="background-color: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
//             <h2 style="color: #dc3545; text-align: center;">Password Reset Request Rejected</h2>
//             <p style="color: #333333; font-size: 16px; text-align: center;">
//               Your password reset request was rejected by the admin.
//             </p>
//             <p style="color: #333333; font-size: 14px; text-align: center;">
//               Please contact support for assistance.
//             </p>
//           </div>
//         </div>
//       `;
//       await sendEmail(user.email, 'Password Reset Request Rejected', rejectionEmailHtml);
//       console.log('Rejection email sent to:', user.email);
//       return res.redirect(`${process.env.APP_URL}/reset-decision?status=rejected`);
//     }

//     // Approval: Send OTP to manager
//     const manager = await User.findOne({ employeeId: user.managerId, roleType: 'Manager' });
//     if (!manager) {
//       console.log('Manager not found for managerId:', user.managerId);
//       return res.status(404).json({ message: 'Manager not found. Please assign a valid manager or contact support.' });
//     }

//     const otp = generateOTP();
//     await OTP.create({
//       email: user.email,
//       otp,
//       expires: new Date(Date.now() + 10 * 60 * 1000),
//       ipAddress: req.ip,
//     });
//     console.log('OTP created for email:', user.email);

//     const otpEmailHtml = `
//       <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4;">
//         <div style="background-color: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
//           <h2 style="color: #003087; text-align: center;">Employee Password Reset OTP</h2>
//           <p style="color: #333333; font-size: 16px; text-align: center;">
//             An OTP has been generated for resetting the password of ${user.email}.
//           </p>
//           <p style="font-size: 24px; font-weight: bold; color: #28a745; text-align: center; margin: 20px 0;">
//             ${otp}
//           </p>
//           <p style="color: #333333; font-size: 14px; text-align: center;">
//             Please provide this OTP to the admin. It is valid for 10 minutes.
//           </p>
//         </div>
//       </div>
//     `;

//     await sendEmail(manager.email, 'Employee Password Reset OTP', otpEmailHtml);
//     console.log('OTP email sent to manager:', manager.email);

//     res.redirect(`${process.env.APP_URL}/reset-decision?status=approved`);
//   } catch (error) {
//     console.error('Reset approval error:', error);
//     res.status(500).send(`
//       <!DOCTYPE html>
//       <html lang="en">
//       <head>
//         <meta charset="UTF-8">
//         <meta name="viewport" content="width=device-width, initial-scale=1.0">
//         <title>Error</title>
//         <style>
//           body {
//             font-family: 'Helvetica Neue', Arial, sans-serif;
//             background-color: #f4f4f4;
//             margin: 0;
//             padding: 0;
//             display: flex;
//             justify-content: center;
//             align-items: center;
//             height: 100vh;
//           }
//           .container {
//             max-width: 600px;
//             background-color: #ffffff;
//             border-radius: 8px;
//             padding: 20px;
//             text-align: center;
//           }
//           .header h1 {
//             color: #333333;
//             font-size: 24px;
//             margin-bottom: 20px;
//           }
//           p {
//             color: #555555;
//             font-size: 16px;
//             margin-bottom: 20px;
//           }
//           a {
//             display: inline-block;
//             padding: 10px 20px;
//             background-color: #003087;
//             color: #ffffff;
//             text-decoration: none;
//             border-radius: 4px;
//             font-weight: 600;
//           }
//           a:hover {
//             background-color: #002343;
//           }
//         </style>
//       </head>
//       <body>
//         <div class="container">
//           <div class="header">
//             <h1>Error Processing Approval</h1>
//           </div>
//           <p>An error occurred: ${error.message}</p>
//           <a href="${process.env.APP_URL}/dashboard">Return to Dashboard</a>
//         </div>
//       </body>
//       </html>
//     `);
//   }
// });

// // Verify OTP Route
// app.post('/api/verify-otp', verifyToken, isAdmin, async (req, res) => {
//   try {
//     const { email, otp } = req.body;
//     console.log('Verifying OTP for email:', email, 'OTP:', otp);

//     if (!email || !otp) {
//       return res.status(400).json({ message: 'Email and OTP are required' });
//     }

//     const storedOTP = await OTP.findOne({ email: { $regex: `^${email}$`, $options: 'i' } });
//     if (!storedOTP) {
//       console.log('OTP not found for email:', email);
//       return res.status(400).json({ message: 'OTP not found or expired' });
//     }

//     if (storedOTP.expires < new Date()) {
//       await OTP.deleteOne({ email: storedOTP.email });
//       console.log('OTP expired for email:', email);
//       return res.status(400).json({ message: 'OTP expired' });
//     }

//     if (storedOTP.otp !== otp) {
//       console.log('Invalid OTP for email:', email);
//       return res.status(400).json({ message: 'Invalid OTP' });
//     }

//     const user = await User.findOne({ email: { $regex: `^${email}$`, $options: 'i' } });
//     if (!user) {
//       console.log('User not found for email:', email);
//       return res.status(404).json({ message: 'User not found' });
//     }
//     console.log('User found for OTP verification:', { email: user.email, employeeId: user.employeeId });

//     const resetToken = jwt.sign(
//       { employeeId: user.employeeId, adminId: req.user.employeeId },
//       process.env.JWT_SECRET,
//       { expiresIn: '15m' }
//     );

//     await OTP.deleteOne({ email: storedOTP.email });
//     console.log('OTP deleted for email:', email);

//     res.status(200).json({ message: 'OTP verified', resetToken });
//   } catch (error) {
//     console.error('OTP verification error:', error);
//     res.status(500).json({ message: 'Server error during OTP verification' });
//   }
// });

// // Reset Password Route
// app.post('/api/reset-password', verifyToken, isAdmin, async (req, res) => {
//   try {
//     const { employeeEmail, otp, newPassword } = req.body;
//     console.log('Resetting password for email:', employeeEmail);

//     if (!employeeEmail || !otp || !newPassword) {
//       return res.status(400).json({ message: 'Employee email, OTP, and new password are required' });
//     }

//     const user = await User.findOne({ email: { $regex: `^${employeeEmail}$`, $options: 'i' } });
//     if (!user) {
//       console.log('User not found for email:', employeeEmail);
//       return res.status(404).json({ message: 'User not found' });
//     }
//     console.log('User found for password reset:', { email: user.email, employeeId: user.employeeId });

//     const storedOTP = await OTP.findOne({ email: { $regex: `^${employeeEmail}$`, $options: 'i' } });
//     if (!storedOTP) {
//       console.log('OTP not found for email:', employeeEmail);
//       return res.status(400).json({ message: 'OTP not found or expired' });
//     }

//     if (storedOTP.expires < new Date()) {
//       await OTP.deleteOne({ email: storedOTP.email });
//       console.log('OTP expired for email:', employeeEmail);
//       return res.status(400).json({ message: 'OTP expired' });
//     }

//     if (storedOTP.otp !== otp) {
//       console.log('Invalid OTP for email:', employeeEmail);
//       return res.status(400).json({ message: 'Invalid OTP' });
//     }

//     user.password = await bcrypt.hash(newPassword, 10);
//     await user.save();
//     console.log('Password updated for user:', user.email);

//     await OTP.deleteOne({ email: storedOTP.email });
//     console.log('OTP deleted for email:', employeeEmail);

//     const confirmationEmailHtml = `
//       <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #ddd; border-radius: 8px;">
//         <h2 style="color: #003087; text-align: center;">Password Reset Successful</h2>
//         <p>Your password has been successfully reset by an admin.</p>
//         <p>If you did not request this, please contact support immediately.</p>
//       </div>
//     `;
//     await sendEmail(user.email, 'Password Reset Confirmation', confirmationEmailHtml);
//     console.log('Password reset confirmation email sent to:', user.email);

//     res.status(200).json({ message: 'Password reset successful' });
//   } catch (error) {
//     console.error('Reset password error:', error);
//     res.status(500).json({ message: 'Server error during password reset' });
//   }
// });
// // Enhanced Email Template for Leave Requests
// const generateEmailTemplate = (leaveRequest, employeeName, recipientRole) => {
//   const { _id, employeeId, leaveType, fromDate, toDate, reason } = leaveRequest;
//   const leaveTypeFormatted = leaveType.charAt(0).toUpperCase() + leaveType.slice(1) + ' Leave';
//   let subject;
//   if (recipientRole === 'employee') {
//     subject = 'Your Leave Request Submission';
//   } else if (recipientRole === 'manager') {
//     subject = `New Leave Request from ${employeeName} (${employeeId})`;
//   } else {
//     subject = `Leave Request for Approval - ${employeeName} (${employeeId})`;
//   }

//   const html = `
//     <!DOCTYPE html>
//     <html lang="en">
//     <head>
//       <meta charset="UTF-8">
//       <meta name="viewport" content="width=device-width, initial-scale=1.0">
//       <title>Leave Request Notification</title>
//       <style>
//         body {
//           font-family: 'Helvetica Neue', Arial, sans-serif;
//           background-color: #f4f4f4;
//           margin: 0;
//           padding: 0;
//         }
//         .container {
//           max-width: 600px;
//           margin: 20px auto;
//           background-color: #ffffff;
//           border-radius: 12px;
//           box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
//           overflow: hidden;
//         }
//         .header {
//           background: linear-gradient(90deg, #003087, #0059b3);
//           padding: 30px;
//           text-align: center;
//         }
//         .header h1 {
//           color: #ffffff;
//           margin: 0;
//           font-size: 28px;
//           font-weight: 700;
//         }
//         .content {
//           padding: 30px;
//         }
//         .content h2 {
//           color: #003087;
//           font-size: 22px;
//           margin-bottom: 20px;
//           text-align: center;
//         }
//         .content p {
//           color: #333333;
//           font-size: 16px;
//           line-height: 1.6;
//           margin: 10px 0;
//         }
//         .details-table {
//           width: 100%;
//           border-collapse: collapse;
//           margin: 20px 0;
//           background-color: #f9f9f9;
//           border-radius: 8px;
//           overflow: hidden;
//         }
//         .details-table th,
//         .details-table td {
//           padding: 15px;
//           text-align: left;
//           border-bottom: 1px solid #e0e0e0;
//         }
//         .details-table th {
//           background-color: #003087;
//           color: #ffffff;
//           width: 35%;
//           font-weight: 600;
//         }
//         .details-table td {
//           color: #333333;
//         }
//         .action-buttons {
//           text-align: center;
//           margin: 30px 0;
//         }
//         .action-buttons a {
//           display: inline-block;
//           padding: 12px 24px;
//           margin: 0 10px;
//           text-decoration: none;
//           font-weight: 600;
//           border-radius: 6px;
//           transition: all 0.3s ease;
//         }
//         .approve-btn {
//           background-color: #28a745;
//           color: #ffffff;
//         }
//         .approve-btn:hover {
//           background-color: #218838;
//           transform: translateY(-2px);
//         }
//         .reject-btn {
//           background-color: #dc3545;
//           color: #ffffff;
//         }
//         .reject-btn:hover {
//           background-color: #c82333;
//           transform: translateY(-2px);
//         }
//         .action-text {
//           color: #555555;
//           font-size: 14px;
//           margin-top: 15px;
//           text-align: center;
//         }
//         .footer {
//           background-color: #003087;
//           padding: 15px;
//           text-align: center;
//         }
//         .footer p {
//           color: #ffffff;
//           margin: 0;
//           font-size: 12px;
//         }
//       </style>
//     </head>
//     <body>
//       <div class="container">
//         <div class="header">
//           <h1>Leave Request Notification</h1>
//         </div>
//         <div class="content">
//           <h2>${
//             recipientRole === 'employee'
//               ? 'Your Leave Request Has Been Submitted'
//               : recipientRole === 'manager'
//               ? 'New Leave Request for Your Review'
//               : 'New Leave Request for Approval'
//           }</h2>
//           <p>Dear ${recipientRole === 'employee' ? employeeName : recipientRole.charAt(0).toUpperCase() + recipientRole.slice(1)},</p>
//           <p>${
//             recipientRole === 'employee'
//               ? 'Thank you for submitting your leave request. It has been sent for approval and you will be notified once reviewed.'
//               : `A leave request from ${employeeName} (${employeeId}) awaits your approval.`
//           }</p>
//           <table class="details-table">
//             <tr>
//               <th>Employee ID</th>
//               <td>${employeeId}</td>
//             </tr>
//             <tr>
//               <th>Employee Name</th>
//               <td>${employeeName}</td>
//             </tr>
//             <tr>
//               <th>Leave Type</th>
//               <td>${leaveTypeFormatted}</td>
//             </tr>
//             <tr>
//               <th>From Date</th>
//               <td>${fromDate}</td>
//             </tr>
//             <tr>
//               <th>To Date</th>
//               <td>${toDate}</td>
//             </tr>
//             <tr>
//               <th>Reason</th>
//               <td>${reason}</td>
//             </tr>
//           </table>
//           ${
//             recipientRole === 'manager'
//               ? `
//                 <div class="action-buttons">
//                   <a href="${process.env.APP_URL}/api/leave/update/${_id}?status=approved&token=${jwt.sign({ leaveId: _id }, process.env.JWT_SECRET, { expiresIn: '24h' })}" class="approve-btn">Approve</a>
//                   <a href="${process.env.APP_URL}/api/leave/update/${_id}?status=rejected&token=${jwt.sign({ leaveId: _id }, process.env.JWT_SECRET, { expiresIn: '24h' })}" class="reject-btn">Reject</a>
//                 </div>
//                 <p class="action-text">Please review and approve or reject the leave request using the buttons above.</p>
//               `
//               : recipientRole !== 'employee'
//               ? '<p class="action-text">Please review the request on your dashboard.</p>'
//               : ''
//           }
//         </div>
//         <div class="footer">
//           <p>© 2025 Intellisurge Technologies. All Rights Reserved.</p>
//         </div>
//       </div>
//     </body>
//     </html>
//   `;

//   return { subject, html };
// };

// // WebSocket connection
// io.on('connection', (socket) => {
//   console.log('A user connected:', socket.id);

//   socket.on('join', ({ employeeId, roleType }) => {
//     socket.join(employeeId);
//     if (roleType === 'Manager') {
//       socket.join('managers');
//     }
//     console.log(`${employeeId} joined room`);
//   });

//   socket.on('disconnect', () => {
//     console.log('User disconnected:', socket.id);
//   });
// });

// // Middleware to verify JWT


// // Registration endpoint
// app.post('/api/register', async (req, res) => {
//   try {
//     const { initial, name, role, department, roleType, phoneNo, email, password } = req.body;

//     if (!initial || !name || !role || !department || !roleType || !phoneNo || !email || !password) {
//       return res.status(400).json({ message: 'All fields are required' });
//     }

//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//     if (!emailRegex.test(email)) {
//       return res.status(400).json({ message: 'Invalid email format' });
//     }

//     const phoneRegex = /^\d{10}$/;
//     if (!phoneRegex.test(phoneNo)) {
//       return res.status(400).json({ message: 'Phone number must be 10 digits' });
//     }

//     const existingUser = await User.findOne({ email });
//     if (existingUser) {
//       return res.status(400).json({ message: 'Email already registered' });
//     }

//     let prefix;
//     switch (roleType) {
//       case 'Employee':
//         prefix = 'E';
//         break;
//       case 'Manager':
//         prefix = 'M';
//         break;
//       case 'Admin':
//         prefix = 'A';
//         break;
//       default:
//         return res.status(400).json({ message: 'Invalid role type' });
//     }
//     const uniqueId = uuidv4().split('-')[0];
//     const employeeId = `${prefix}-${uniqueId}`;

//     const saltRounds = 10;
//     const hashedPassword = await bcrypt.hash(password, saltRounds);

//     const newUser = new User({
//       employeeId,
//       initial,
//       name,
//       role,
//       department,
//       roleType,
//       phoneNo,
//       email,
//       password: hashedPassword,
//       managerId: roleType === 'Employee' ? req.body.managerId || null : null,
//     });

//     await newUser.save();

//     res.status(201).json({ message: 'User registered successfully', employeeId });
//   } catch (error) {
//     console.error('Registration error:', error);
//     res.status(500).json({ message: 'Server error during registration' });
//   }
// });

// // Login endpoint
// app.post('/api/login', async (req, res) => {
//   try {
//     const { email, password } = req.body;

//     if (!email || !password) {
//       return res.status(400).json({ message: 'Email and password are required' });
//     }

//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//     if (!emailRegex.test(email)) {
//       return res.status(400).json({ message: 'Invalid email format' });
//     }

//     const user = await User.findOne({ email });
//     if (!user) {
//       return res.status(401).json({ message: 'Invalid email or password' });
//     }

//     const isPasswordValid = await bcrypt.compare(password, user.password);
//     if (!isPasswordValid) {
//       return res.status(401).json({ message: 'Invalid email or password' });
//     }

//     const token = jwt.sign(
//       {
//         employeeId: user.employeeId,
//         roleType: user.roleType,
//         managerId: user.managerId || null,
//       },
//       process.env.JWT_SECRET,
//       { expiresIn: '1h' }
//     );

//     res.status(200).json({
//       message: 'Login successful',
//       roleType: user.roleType,
//       employeeId: user.employeeId,
//       token,
//       user: {
//         employeeId: user.employeeId,
//         initial: user.initial,
//         name: user.name,
//         role: user.role,
//         department: user.department,
//         roleType: user.roleType,
//         phoneNo: user.phoneNo,
//         email: user.email,
//         managerId: user.managerId || null,
//       },
//     });
//   } catch (error) {
//     console.error('Login error:', error);
//     res.status(500).json({ message: 'Server error during login' });
//   }
// });

// // Add Task endpoint
// app.post('/api/tasks', verifyToken, async (req, res) => {
//   try {
//     const { employeeId, projectName, activityName, taskDescription, percentComplete, assignedBy } = req.body;

//     if (!employeeId || !projectName || !activityName) {
//       return res.status(400).json({ message: 'Employee ID, project name, and activity name are required' });
//     }

//     const user = await User.findOne({ employeeId });
//     if (!user) {
//       return res.status(400).json({ message: 'Invalid employee ID' });
//     }

//     const newTask = new Task({
//       employeeId,
//       projectName,
//       activityName,
//       taskDescription,
//       percentComplete,
//       assignedBy,
//     });

//     await newTask.save();

//     res.status(201).json({ message: 'Task added successfully', task: newTask });
//   } catch (error) {
//     console.error('Task creation error:', error);
//     res.status(500).json({ message: 'Server error during task creation' });
//   }
// });

// // Get Tasks endpoint
// app.get('/api/tasks/:employeeId', verifyToken, async (req, res) => {
//   try {
//     const { employeeId } = req.params;

//     const tasks = await Task.find({ employeeId });

//     res.status(200).json({ tasks });
//   } catch (error) {
//     console.error('Task fetch error:', error);
//     res.status(500).json({ message: 'Server error during task retrieval' });
//   }
// });

// // Update Task Status endpoint
// app.put('/api/tasks/:taskId', verifyToken, isManager, async (req, res) => {
//   try {
//     const { taskId } = req.params;
//     const { status } = req.body;

//     if (!['Approved', 'Rejected'].includes(status)) {
//       return res.status(400).json({ message: 'Invalid status. Must be Approved or Rejected' });
//     }

//     const task = await Task.findById(taskId);
//     if (!task) {
//       return res.status(404).json({ message: 'Task not found' });
//     }

//     const manager = await User.findOne({ employeeId: req.user.employeeId });
//     if (!manager.assignedEmployees.some(emp => emp.equals(task.employeeId))) {
//       return res.status(403).json({ message: 'Task does not belong to an employee assigned to you' });
//     }

//     task.status = status;
//     await task.save();

//     res.status(200).json({ message: `Task ${status.toLowerCase()} successfully`, task });
//   } catch (error) {
//     console.error('Update task status error:', error);
//     res.status(500).json({ message: 'Server error during task status update' });
//   }
// });

// // Add/Update Timesheet endpoint
// // app.post('/api/timesheet', verifyToken, async (req, res) => {
// //   try {
// //     const { employeeId, projectName, activityName, weekStartDate, hours, loginTimes, logoutTimes } = req.body;

// //     if (!employeeId || !projectName || !activityName || !weekStartDate) {
// //       return res.status(400).json({ message: 'Employee ID, project name, activity name, and week start date are required' });
// //     }

// //     const user = await User.findOne({ employeeId });
// //     if (!user) {
// //       return res.status(400).json({ message: 'Invalid employee ID' });
// //     }

// //     let timesheet = await Timesheet.findOne({ employeeId, projectName, activityName, weekStartDate });

// //     if (timesheet) {
// //       timesheet.hours = hours || timesheet.hours;
// //       timesheet.loginTimes = loginTimes || timesheet.loginTimes;
// //       timesheet.logoutTimes = logoutTimes || timesheet.logoutTimes;
// //       await timesheet.save();
// //     } else {
// //       timesheet = new Timesheet({
// //         employeeId,
// //         projectName,
// //         activityName,
// //         weekStartDate,
// //         hours: hours || Array(7).fill('00:00'),
// //         loginTimes: loginTimes || Array(7).fill(null),
// //         logoutTimes: logoutTimes || Array(7).fill(null),
// //       });
// //       await timesheet.save();
// //     }

// //     res.status(201).json({ message: 'Timesheet saved successfully', timesheet });
// //   } catch (error) {
// //     console.error('Timesheet save error:', error);
// //     res.status(500).json({ message: 'Server error during timesheet save' });
// //   }
// // });

// app.post('/api/timesheet', verifyToken, async (req, res) => {
//   try {
//     const { employeeId, projectName, activityName, weekStartDate, hours, loginTimes, logoutTimes } = req.body;

//     if (!employeeId || !projectName || !activityName || !weekStartDate) {
//       return res.status(400).json({ message: 'Employee ID, project name, activity name, and week start date are required' });
//     }

//     const user = await User.findOne({ employeeId });
//     if (!user) {
//       return res.status(400).json({ message: 'Invalid employee ID' });
//     }

//     const istWeekStartDate = new Date(weekStartDate);
//     console.log('Received timesheet data:', {
//       employeeId,
//       projectName,
//       activityName,
//       weekStartDate: istWeekStartDate.toISOString(),
//       hours,
//       loginTimes,
//       logoutTimes,
//     }); // Debug

//     // Validate weekStartDate is a Monday
//     const isMonday = istWeekStartDate.getDay() === 1;
//     if (!isMonday) {
//       console.warn('weekStartDate is not a Monday:', istWeekStartDate.toISOString());
//     }

//     let timesheet = await Timesheet.findOne({ employeeId, projectName, activityName, weekStartDate: istWeekStartDate });

//     if (timesheet) {
//       timesheet.hours = hours || timesheet.hours;
//       timesheet.loginTimes = loginTimes || timesheet.loginTimes;
//       timesheet.logoutTimes = logoutTimes || timesheet.logoutTimes;
//       await timesheet.save();
//       console.log('Updated timesheet:', timesheet._id);
//     } else {
//       timesheet = new Timesheet({
//         employeeId,
//         projectName,
//         activityName,
//         weekStartDate: istWeekStartDate,
//         hours: hours || Array(7).fill('00:00'),
//         loginTimes: loginTimes || Array(7).fill(null),
//         logoutTimes: logoutTimes || Array(7).fill(null),
//       });
//       await timesheet.save();
//       console.log('Created new timesheet:', timesheet._id);
//     }

//     res.status(201).json({ message: 'Timesheet saved successfully', timesheet });
//   } catch (error) {
//     console.error('Timesheet save error:', error);
//     res.status(500).json({ message: 'Server error during timesheet save' });
//   }
// });

// // Get Timesheet endpoint
// // app.get('/api/timesheet/:employeeId', verifyToken, async (req, res) => {
// //   try {
// //     const { employeeId } = req.params;

// //     const timesheets = await Timesheet.find({ employeeId });

// //     res.status(200).json({ timesheets });
// //   } catch (error) {
// //     console.error('Timesheet fetch error:', error);
// //     res.status(500).json({ message: 'Server error during timesheet retrieval' });
// //   }
// // });


// app.get('/api/timesheet/:employeeId', verifyToken, async (req, res) => {
//   try {
//     const { employeeId } = req.params;

//     const timesheets = await Timesheet.find({ employeeId });
//     console.log('Fetched timesheets for employee:', employeeId, timesheets.map(t => ({
//       _id: t._id,
//       weekStartDate: t.weekStartDate.toISOString(),
//       projectName: t.projectName,
//       activityName: t.activityName,
//       loginTimes: t.loginTimes,
//     }))); // Debug

//     res.status(200).json({ timesheets });
//   } catch (error) {
//     console.error('Timesheet fetch error:', error);
//     res.status(500).json({ message: 'Server error during timesheet retrieval' });
//   }
// });


// // Get all employee details (Admin only)
// app.get('/api/admin/employees', verifyToken, isAdmin, async (req, res) => {
//   try {
//     const { page = 1, limit = 10, roleType, department } = req.query;
//     let query = {};
//     if (roleType) query.roleType = roleType;
//     if (department) query.department = department;

//     const employees = await User.find(query, { password: 0, __v: 0 })
//       .skip((page - 1) * limit)
//       .limit(parseInt(limit));
//     const total = await User.countDocuments(query);

//     res.status(200).json({
//       message: 'Employee details retrieved successfully',
//       employees,
//       total,
//       page: parseInt(page),
//       pages: Math.ceil(total / limit)
//     });
//   } catch (error) {
//     console.error('Fetch employees error:', error);
//     res.status(500).json({ message: 'Server error during employee retrieval' });
//   }
// });

// // Update employee (Admin only)
// app.put('/api/admin/employees/:employeeId', verifyToken, isAdmin, async (req, res) => {
//   try {
//     const { employeeId } = req.params;
//     const { initial, name, role, department, roleType, phoneNo, email, createdAt, address } = req.body;

//     if (!initial || !name || !role || !department || !roleType || !phoneNo || !email) {
//       return res.status(400).json({ message: 'All fields except address and createdAt are required' });
//     }

//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//     if (!emailRegex.test(email)) {
//       return res.status(400).json({ message: 'Invalid email format' });
//     }

//     const phoneRegex = /^\d{10}$/;
//     if (!phoneNo || !phoneRegex.test(phoneNo)) {
//       return res.status(400).json({ message: 'Phone number must be 10 digits' });
//     }

//     const prefix = roleType === 'Employee' ? 'E' : roleType === 'Manager' ? 'M' : 'A';
//     if (!employeeId.startsWith(prefix)) {
//       return res.status(400).json({ message: `Employee ID must start with '${prefix}'` });
//     }

//     const existingUser = await User.findOne({ email, employeeId: { $ne: employeeId } });
//     if (existingUser) {
//       return res.status(400).json({ message: 'Email already registered' });
//     }

//     const updatedUser = await User.findOneAndUpdate(
//       { employeeId },
//       { initial, name, role, department, roleType, phoneNo, email, address, createdAt: createdAt ? new Date(createdAt) : undefined },
//       { new: true, runValidators: true, select: '-password -__v' }
//     );

//     if (!updatedUser) {
//       return res.status(404).json({ message: 'Employee not found' });
//     }

//     res.status(200).json({ message: 'Employee updated successfully', employee: updatedUser });
//   } catch (error) {
//     console.error('Update employee error:', error);
//     res.status(500).json({ message: 'Server error during employee update' });
//   }
// });

// // Delete employee (Admin only)
// app.delete('/api/admin/employees/:employeeId', verifyToken, isAdmin, async (req, res) => {
//   try {
//     const { employeeId } = req.params;

//     const deletedUser = await User.findOneAndDelete({ employeeId });
//     if (!deletedUser) {
//       return res.status(404).json({ message: 'Employee not found' });
//     }

//     await Task.deleteMany({ employeeId });
//     await Timesheet.deleteMany({ employeeId });
//     await Assignment.deleteMany({ $or: [{ employeeId: deletedUser._id }, { managerId: employeeId }] });
//     await LeaveRequest.deleteMany({ employeeId });

//     res.status(200).json({ message: 'Employee deleted successfully' });
//   } catch (error) {
//     console.error('Delete employee error:', error);
//     res.status(500).json({ message: 'Server error during employee deletion' });
//   }
// });

// // Assign employee to manager (Admin only)
// app.post('/api/admin/assign-employee', verifyToken, isAdmin, async (req, res) => {
//   try {
//     const { employeeId, managerId } = req.body;

//     if (!employeeId || !managerId) {
//       return res.status(400).json({ message: 'Employee ID and Manager ID are required' });
//     }

//     const employee = await User.findOne({ employeeId, roleType: 'Employee' });
//     if (!employee) {
//       return res.status(404).json({ message: 'Employee not found or invalid role type' });
//     }

//     const manager = await User.findOne({ employeeId: managerId, roleType: 'Manager' });
//     if (!manager) {
//       return res.status(404).json({ message: 'Manager not found or invalid role type' });
//     }

//     const admin = await User.findOne({ employeeId: req.user.employeeId });
//     if (!admin) {
//       return res.status(404).json({ message: 'Admin not found' });
//     }

//     const existingAssignment = await Assignment.findOne({ employeeId: employee._id, managerId, status: 'Pending' });
//     if (existingAssignment) {
//       return res.status(400).json({ message: 'Employee is already assigned to this manager and pending approval' });
//     }

//     const assignment = new Assignment({
//       employeeId: employee._id,
//       managerId,
//       assignedBy: admin._id,
//       status: 'Pending',
//     });

//     await assignment.save();

//     await User.findOneAndUpdate(
//       { employeeId },
//       { managerId },
//       { new: true }
//     );

//     res.status(201).json({ message: 'Employee assigned to manager successfully', assignment });
//   } catch (error) {
//     console.error('Assign employee error:', error);
//     res.status(500).json({ message: 'Server error during employee assignment' });
//   }
// });

// // Get pending assignments for a manager
// app.get('/api/manager/assignments', verifyToken, async (req, res) => {
//   try {
//     const { employeeId, roleType } = req.user;

//     if (roleType !== 'Manager') {
//       return res.status(403).json({ message: 'Access denied: Managers only' });
//     }

//     const assignments = await Assignment.find({ managerId: employeeId, status: 'Pending' })
//       .populate('employeeId', 'name initial employeeId email')
//       .populate('assignedBy', 'name employeeId');

//     res.status(200).json({ assignments });
//   } catch (error) {
//     console.error('Fetch assignments error:', error);
//     res.status(500).json({ message: 'Server error during assignments retrieval' });
//   }
// });

// // Accept or reject assignment (Manager only)
// app.put('/api/manager/assignments/:assignmentId', verifyToken, async (req, res) => {
//   try {
//     const { assignmentId } = req.params;
//     const { status } = req.body;
//     const { employeeId, roleType } = req.user;

//     if (roleType !== 'Manager') {
//       return res.status(403).json({ message: 'Access denied: Managers only' });
//     }

//     if (!['Accepted', 'Rejected'].includes(status)) {
//       return res.status(400).json({ message: 'Invalid status. Must be Accepted or Rejected' });
//     }

//     const assignment = await Assignment.findOne({ _id: assignmentId, managerId: employeeId });
//     if (!assignment) {
//       return res.status(404).json({ message: 'Assignment not found or you are not authorized' });
//     }

//     assignment.status = status;
//     await assignment.save();

//     if (status === 'Accepted') {
//       await User.findOneAndUpdate(
//         { employeeId: assignment.managerId },
//         { $addToSet: { assignedEmployees: assignment.employeeId } },
//         { new: true }
//       );
//     }

//     res.status(200).json({ message: `Assignment ${status.toLowerCase()} successfully`, assignment });
//   } catch (error) {
//     console.error('Update assignment error:', error);
//     res.status(500).json({ message: 'Server error during assignment update' });
//   }
// });

// // Get assigned employees for a manager
// app.get('/api/manager/employees', verifyToken, async (req, res) => {
//   try {
//     const { employeeId, roleType } = req.user;

//     if (roleType !== 'Manager') {
//       return res.status(403).json({ message: 'Access denied: Managers only' });
//     }

//     const manager = await User.findOne({ employeeId }).populate('assignedEmployees', 'name initial employeeId email department role');
//     if (!manager) {
//       return res.status(404).json({ message: 'Manager not found' });
//     }

//     res.status(200).json({ employees: manager.assignedEmployees });
//   } catch (error) {
//     console.error('Fetch assigned employees error:', error);
//     res.status(500).json({ message: 'Server error during assigned employees retrieval' });
//   }
// });

// // Get attendance report for a manager's assigned employees
// app.get('/api/manager/attendance', verifyToken, isManager, async (req, res) => {
//   try {
//     const { employeeId } = req.user;

//     const manager = await User.findOne({ employeeId }).populate('assignedEmployees', 'name employeeId');
//     if (!manager) {
//       return res.status(404).json({ message: 'Manager not found' });
//     }

//     const employeeIds = manager.assignedEmployees.map(emp => emp.employeeId);
//     if (employeeIds.length === 0) {
//       return res.status(200).json({ attendance: [] });
//     }

//     const timesheets = await Timesheet.find({ employeeId: { $in: employeeIds } });

//     const attendance = [];
//     for (const timesheet of timesheets) {
//       const employee = manager.assignedEmployees.find(emp => emp.employeeId === timesheet.employeeId);
//       const weekStartDate = new Date(timesheet.weekStartDate);

//       for (let day = 0; day < 7; day++) {
//         const currentDate = new Date(weekStartDate);
//         currentDate.setDate(weekStartDate.getDate() + day);

//         const loginTime = timesheet.loginTimes[day];
//         const logoutTime = timesheet.logoutTimes[day];
//         const status = loginTime ? 'Present' : 'Absent';

//         attendance.push({
//           employeeId: timesheet.employeeId,
//           name: employee.name,
//           date: currentDate.toISOString().split('T')[0],
//           checkInTime: loginTime || 'N/A',
//           checkOutTime: logoutTime || 'N/A',
//           status,
//         });
//       }
//     }

//     res.status(200).json({ attendance });
//   } catch (error) {
//     console.error('Fetch attendance error:', error);
//     res.status(500).json({ message: 'Server error during attendance retrieval' });
//   }
// });

// // Get attendance report for an employee
// app.get('/api/employee/attendance', verifyToken, isEmployee, async (req, res) => {
//   try {
//     const { employeeId } = req.user;

//     const timesheets = await Timesheet.find({ employeeId });

//     const attendance = [];
//     for (const timesheet of timesheets) {
//       const weekStartDate = new Date(timesheet.weekStartDate);

//       for (let day = 0; day < 7; day++) {
//         const currentDate = new Date(weekStartDate);
//         currentDate.setDate(weekStartDate.getDate() + day);

//         const loginTime = timesheet.loginTimes[day];
//         const logoutTime = timesheet.logoutTimes[day];

//         let totalWorkedTime = 'N/A';
//         if (loginTime && logoutTime) {
//           const login = new Date(`2025-05-06 ${loginTime}`);
//           const logout = new Date(`2025-05-06 ${logoutTime}`);
//           const hoursWorked = (logout - login) / (1000 * 60 * 60);
//           totalWorkedTime = `${hoursWorked.toFixed(2)} hrs`;
//         }

//         if (loginTime || logoutTime) {
//           attendance.push({
//             date: currentDate.toISOString().split('T')[0],
//             login: loginTime || 'N/A',
//             logout: logoutTime || 'N/A',
//             totalWorkedTime,
//           });
//         }
//       }
//     }

//     res.status(200).json({ attendance });
//   } catch (error) {
//     console.error('Fetch employee attendance error:', error);
//     res.status(500).json({ message: 'Server error during employee attendance retrieval' });
//   }
// });

// // Get user details by employeeId
// app.get('/api/user/:employeeId', verifyToken, async (req, res) => {
//   try {
//     const { employeeId } = req.params;

//     const user = await User.findOne({ employeeId }, { password: 0, __v: 0 });
//     if (!user) {
//       return res.status(404).json({ message: 'User not found' });
//     }

//     res.status(200).json({ user });
//   } catch (error) {
//     console.error('Fetch user error:', error);
//     res.status(500).json({ message: 'Server error during user retrieval' });
//   }
// });

// // Submit Leave Request (Employee only)
// app.post('/api/leave/apply', verifyToken, isEmployee, async (req, res) => {
//   try {
//     const { employeeId, leaveType, fromDate, toDate, reason, status } = req.body;

//     if (!employeeId || !leaveType || !fromDate || !toDate || !reason) {
//       return res.status(400).json({ message: 'All fields are required' });
//     }

//     if (!['sick', 'casual', 'emergency'].includes(leaveType)) {
//       return res.status(400).json({ message: 'Invalid leave type. Must be sick, casual, or emergency' });
//     }

//     const dateRegex = /^\d{2}-\d{2}-\d{4}$/;
//     if (!dateRegex.test(fromDate) || !dateRegex.test(toDate)) {
//       return res.status(400).json({ message: 'Dates must be in DD-MM-YYYY format' });
//     }

//     const fromDateObj = new Date(fromDate.split('-').reverse().join('-'));
//     const toDateObj = new Date(toDate.split('-').reverse().join('-'));
//     if (fromDateObj > toDateObj) {
//       return res.status(400).json({ message: 'From date cannot be later than to date' });
//     }

//     const employee = await User.findOne({ employeeId });
//     if (!employee) {
//       return res.status(404).json({ message: 'Employee not found' });
//     }

//     let manager = null;
//     if (employee.managerId) {
//       manager = await User.findOne({ employeeId: employee.managerId });
//       if (!manager) {
//         return res.status(404).json({ message: 'Manager not found' });
//       }
//     }

//     const leaveRequest = new LeaveRequest({
//       employeeId,
//       employeeName: employee.name,
//       leaveType,
//       fromDate,
//       toDate,
//       reason,
//       status: status || 'pending',
//     });
//     await leaveRequest.save();

//     const employeeEmail = generateEmailTemplate(leaveRequest, employee.name, 'employee');
//     const adminEmail = generateEmailTemplate(leaveRequest, employee.name, 'admin');
//     const emails = [
//       {
//         from: process.env.EMAIL_USER,
//         to: employee.email,
//         subject: employeeEmail.subject,
//         html: employeeEmail.html,
//       },
//       {
//         from: process.env.EMAIL_USER,
//         to: process.env.ADMIN_EMAIL || 'admin@company.com',
//         subject: adminEmail.subject,
//         html: adminEmail.html,
//       },
//     ];

//     if (manager) {
//       const managerEmail = generateEmailTemplate(leaveRequest, employee.name, 'manager');
//       emails.push({
//         from: process.env.EMAIL_USER,
//         to: manager.email,
//         subject: managerEmail.subject,
//         html: managerEmail.html,
//       });
//     }

//     await Promise.all(emails.map(email => transporter.sendMail(email)));

//     io.to('managers').emit('newLeaveRequest', {
//       leaveId: leaveRequest._id,
//       employeeId,
//       employeeName: employee.name,
//       leaveType,
//       fromDate,
//       toDate,
//       reason,
//       status: 'pending',
//       createdAt: leaveRequest.createdAt,
//     });

//     res.status(201).json({ message: 'Leave request submitted successfully', leaveRequest });
//   } catch (error) {
//     console.error('Submit leave request error:', error);
//     res.status(500).json({ message: 'Server error during leave request submission' });
//   }
// });




require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');
const http = require('http');
const { Server } = require('socket.io');
const moment = require('moment-timezone');
const User = require('./models/User');
const Task = require('./models/Task');
const Timesheet = require('./models/Timesheet');
const Assignment = require('./models/Assignment');
const LeaveRequest = require('./models/LeaveRequest');
const OTP = require('./models/Otp');
const ResetRequest = require('./models/ResetRequest');

const app = express();
const PORT = process.env.PORT || 5001;

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: process.env.APP_URL,
    methods: ['GET', 'POST'],
  },
});

app.use(express.json());

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => console.log('Connected to MongoDB'))
  .catch((error) => console.error('MongoDB connection error:', error));

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});


app.use(cors({
    
    origin: 'https://attendance.intellisurgetechnologies.com',
    
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

// Endpoint to check Nodemailer transporter status
app.get('/api/health/email', async (req, res) => {
  try {
    await transporter.verify();
    res.status(200).json({
      status: 'success',
      message: 'Nodemailer transporter is active and configured correctly',
      emailService: 'Gmail',
      emailUser: process.env.EMAIL_USER,
    });
  } catch (error) {
    let errorMessage = 'Nodemailer transporter verification failed';
    let errorDetails = error.message;
    if (error.code === 'EAUTH') {
      errorMessage = 'Authentication failed';
      errorDetails = 'Invalid EMAIL_USER or EMAIL_PASS. Please check your Gmail credentials or App Password.';
    } else if (error.code === 'ECONNREFUSED') {
      errorMessage = 'Connection refused';
      errorDetails = 'Unable to connect to Gmail SMTP server. Check your network or Gmail service status.';
    }
    console.error('Nodemailer verification error:', error);
    res.status(500).json({
      status: 'error',
      message: errorMessage,
      details: errorDetails,
    });
  }
});

const verifyToken = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1] || req.query.token;
  if (!token) {
    return res.status(401).json({ message: 'Token required' });
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Invalid token' });
  }
};

// Middleware to check if user is an admin
const isAdmin = async (req, res, next) => {
  try {
    const { employeeId } = req.user;
    const user = await User.findOne({ employeeId });
    if (!user) {
      return res.status(401).json({ message: 'User not found' });
    }
    if (user.roleType !== 'Admin') {
      return res.status(403).json({ message: 'Access denied: Admins only' });
    }
    next();
  } catch (error) {
    console.error('Admin check error:', error);
    res.status(500).json({ message: 'Server error during admin verification' });
  }
};

// Middleware to check if user is a manager
const isManager = async (req, res, next) => {
  try {
    const { employeeId, roleType } = req.user;
    if (roleType !== 'Manager') {
      return res.status(403).json({ message: 'Access denied: Managers only' });
    }
    next();
  } catch (error) {
    console.error('Manager check error:', error);
    res.status(500).json({ message: 'Server error during manager verification' });
  }
};

// Middleware to check if user is an employee
const isEmployee = async (req, res, next) => {
  try {
    const { employeeId, roleType } = req.user;
    if (roleType !== 'Employee') {
      return res.status(403).json({ message: 'Access denied: Employees only' });
    }
    next();
  } catch (error) {
    console.error('Employee check error:', error);
    res.status(500).json({ message: 'Server error during employee verification' });
  }
};

// Middleware to check if user is a manager or admin
const isManagerOrAdmin = async (req, res, next) => {
  try {
    const { employeeId, roleType } = req.user;
    if (roleType !== 'Manager' && roleType !== 'Admin') {
      return res.status(403).json({ message: 'Access denied: Managers or Admins only' });
    }
    next();
  } catch (error) {
    console.error('Manager/Admin check error:', error);
    res.status(500).json({ message: 'Server error during manager/admin verification' });
  }
};

// Generate OTP
const generateOTP = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

// Send Email Function
const sendEmail = async (to, subject, html) => {
  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to,
      subject,
      html,
    });
    console.log(`Email sent to ${to}`);
  } catch (error) {
    console.error(`Email sending error to ${to}:`, error);
    throw new Error('Failed to send email');
  }
};

// Password reset approval email template
const generateApprovalEmail = (email, userName, approvalToken) => {
  return {
    subject: `Password Reset Approval Request for ${userName}`,
    html: `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Password Reset Approval Request</title>
        <style>
          body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
          }
          .container {
            max-width: 600px;
            margin: 20px auto;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
          }
          .header {
            background: linear-gradient(90deg, #003087, #0059b3);
            padding: 30px;
            text-align: center;
          }
          .header h1 {
            color: #ffffff;
            margin: 0;
            font-size: 28px;
            font-weight: 700;
          }
          .content {
            padding: 30px;
            text-align: center;
          }
          .content p {
            color: #333333;
            font-size: 16px;
            line-height: 1.6;
            margin: 10px 0;
          }
          .action-buttons {
            margin: 20px 0;
          }
          .action-buttons a {
            display: inline-block;
            padding: 12px 24px;
            margin: 0 10px;
            text-decoration: none;
            font-weight: 600;
            border-radius: 6px;
            color: #ffffff;
          }
          .approve-btn {
            background-color: #28a745;
          }
          .reject-btn {
            background-color: #dc3545;
          }
          .footer {
            background-color: #003087;
            padding: 15px;
            text-align: center;
          }
          .footer p {
            color: #ffffff;
            margin: 0;
            font-size: 12px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Password Reset Approval Request</h1>
          </div>
          <div class="content">
            <p>Dear Admin,</p>
            <p>A password reset request has been received for ${userName} (${email}).</p>
            <p>Please approve or reject this request using the buttons below.</p>
            <div class="action-buttons">
              <a href="${process.env.APP_URL}/api/reset-approval/${approvalToken}?status=approved" class="approve-btn">Approve</a>
              <a href="${process.env.APP_URL}/api/reset-approval/${approvalToken}?status=rejected" class="reject-btn">Reject</a>
            </div>
            <p>If you did not initiate this action, please contact support immediately.</p>
          </div>
          <div class="footer">
            <p>© 2025 Intellisurge Technologies. All Rights Reserved.</p>
          </div>
        </div>
      </body>
      </html>
    `,
  };
};

// Forgot Password Endpoint
app.post('/api/forgot-password', async (req, res) => {
  try {
    const { email } = req.body;
    console.log('Received forgot password request for email:', email);
    if (!email) {
      return res.status(400).json({ message: 'Email is required' });
    }

    const user = await User.findOne({ email: { $regex: `^${email}$`, $options: 'i' } });
    if (!user) {
      console.log('No user found for email:', email);
      return res.status(404).json({ message: 'Email not registered. Please check the email or contact support.' });
    }
    console.log('User found:', { email: user.email, employeeId: user.employeeId });

    if (!user.employeeId) {
      console.log('User missing employeeId:', user.email);
      return res.status(400).json({ message: 'Invalid user data. Contact support.' });
    }

    if (user.roleType !== 'Employee') {
      const otp = generateOTP();
      await OTP.create({
        email: user.email,
        otp,
        expires: new Date(Date.now() + 10 * 60 * 1000),
        ipAddress: req.ip,
        createdAt: moment().tz('Asia/Kolkata').toDate(),
      });
      const otpEmailHtml = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4;">
          <div style="background-color: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <h2 style="color: #003087; text-align: center;">Password Reset OTP</h2>
            <p style="color: #333333; font-size: 16px; text-align: center;">
              Your OTP for password reset is:
            </p>
            <p style="font-size: 24px; font-weight: bold; color: #28a745; text-align: center; margin: 20px 0;">
              ${otp}
            </p>
            <p style="color: #333333; font-size: 14px; text-align: center;">
              This OTP is valid for 10 minutes. Do not share it with anyone.
            </p>
          </div>
        </div>
      `;
      await sendEmail(user.email, 'Password Reset OTP', otpEmailHtml);
      console.log('OTP email sent to:', user.email);
      return res.status(200).json({ message: 'OTP sent to your email' });
    }

    const admin = await User.findOne({ roleType: 'Admin' });
    if (!admin) {
      console.log('No admin found');
      return res.status(404).json({ message: 'Admin not found' });
    }

    const approvalToken = jwt.sign(
      { email: user.email, employeeId: user.employeeId },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    const approvalEmail = generateApprovalEmail(user.email, user.name, approvalToken);
    await sendEmail(admin.email, approvalEmail.subject, approvalEmail.html);
    console.log('Approval email sent to admin:', admin.email);

    res.status(200).json({ message: 'Reset request sent to admin for approval' });
  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Reset Approval/Rejection Endpoint
app.get('/api/reset-approval/:approvalToken', async (req, res) => {
  try {
    const { approvalToken } = req.params;
    const { status } = req.query;
    console.log('Processing reset approval:', { approvalToken, status });

    if (!['approved', 'rejected'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status' });
    }

    let decoded;
    try {
      decoded = jwt.verify(approvalToken, process.env.JWT_SECRET);
    } catch (error) {
      console.log('Invalid approval token:', error.message);
      return res.status(401).json({ message: 'Invalid or expired approval token' });
    }

    const user = await User.findOne({ email: { $regex: `^${decoded.email}$`, $options: 'i' } });
    if (!user) {
      console.log('User not found for email:', decoded.email);
      return res.status(404).json({ message: 'User not found. Contact support.' });
    }
    console.log('User found:', { email: user.email, employeeId: user.employeeId });

    if (user.employeeId !== decoded.employeeId) {
      console.log('Employee ID mismatch:', { user: user.employeeId, token: decoded.employeeId });
      return res.status(400).json({ message: 'Employee ID does not match' });
    }

    if (status === 'rejected') {
      const rejectionEmailHtml = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4;">
          <div style="background-color: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
            <h2 style="color: #dc3545; text-align: center;">Password Reset Request Rejected</h2>
            <p style="color: #333333; font-size: 16px; text-align: center;">
              Your password reset request was rejected by the admin.
            </p>
            <p style="color: #333333; font-size: 14px; text-align: center;">
              Please contact support for assistance.
            </p>
          </div>
        </div>
      `;
      await sendEmail(user.email, 'Password Reset Request Rejected', rejectionEmailHtml);
      console.log('Rejection email sent to:', user.email);
      return res.redirect(`${process.env.APP_URL}/reset-decision?status=rejected`);
    }

    const manager = await User.findOne({ employeeId: user.managerId, roleType: 'Manager' });
    if (!manager) {
      console.log('Manager not found for managerId:', user.managerId);
      return res.status(404).json({ message: 'Manager not found. Please assign a valid manager or contact support.' });
    }

    const otp = generateOTP();
    await OTP.create({
      email: user.email,
      otp,
      expires: new Date(Date.now() + 10 * 60 * 1000),
      ipAddress: req.ip,
      createdAt: moment().tz('Asia/Kolkata').toDate(),
    });
    console.log('OTP created for email:', user.email);

    const otpEmailHtml = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4;">
        <div style="background-color: #ffffff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
          <h2 style="color: #003087; text-align: center;">Employee Password Reset OTP</h2>
          <p style="color: #333333; font-size: 16px; text-align: center;">
            An OTP has been generated for resetting the password of ${user.email}.
          </p>
          <p style="font-size: 24px; font-weight: bold; color: #28a745; text-align: center; margin: 20px 0;">
            ${otp}
          </p>
          <p style="color: #333333; font-size: 14px; text-align: center;">
            Please provide this OTP to the admin. It is valid for 10 minutes.
          </p>
        </div>
      </div>
    `;

    await sendEmail(manager.email, 'Employee Password Reset OTP', otpEmailHtml);
    console.log('OTP email sent to manager:', manager.email);

    res.redirect(`${process.env.APP_URL}/reset-decision?status=approved`);
  } catch (error) {
    console.error('Reset approval error:', error);
    res.status(500).send(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Error</title>
        <style>
          body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
          }
          .container {
            max-width: 600px;
            background-color: #ffffff;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
          }
          .header h1 {
            color: #333333;
            font-size: 24px;
            margin-bottom: 20px;
          }
          p {
            color: #555555;
            font-size: 16px;
            margin-bottom: 20px;
          }
          a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #003087;
            color: #ffffff;
            text-decoration: none;
            border-radius: 4px;
            font-weight: 600;
          }
          a:hover {
            background-color: #002343;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Error Processing Approval</h1>
          </div>
          <p>An error occurred: ${error.message}</p>
          <a href="${process.env.APP_URL}/dashboard">Return to Dashboard</a>
        </div>
      </body>
      </html>
    `);
  }
});

// Verify OTP Route
app.post('/api/verify-otp', verifyToken, isAdmin, async (req, res) => {
  try {
    const { email, otp } = req.body;
    console.log('Verifying OTP for email:', email, 'OTP:', otp);

    if (!email || !otp) {
      return res.status(400).json({ message: 'Email and OTP are required' });
    }

    const storedOTP = await OTP.findOne({ email: { $regex: `^${email}$`, $options: 'i' } });
    if (!storedOTP) {
      console.log('OTP not found for email:', email);
      return res.status(400).json({ message: 'OTP not found or expired' });
    }

    if (storedOTP.expires < new Date()) {
      await OTP.deleteOne({ email: storedOTP.email });
      console.log('OTP expired for email:', email);
      return res.status(400).json({ message: 'OTP expired' });
    }

    if (storedOTP.otp !== otp) {
      console.log('Invalid OTP for email:', email);
      return res.status(400).json({ message: 'Invalid OTP' });
    }

    const user = await User.findOne({ email: { $regex: `^${email}$`, $options: 'i' } });
    if (!user) {
      console.log('User not found for email:', email);
      return res.status(404).json({ message: 'User not found' });
    }
    console.log('User found for OTP verification:', { email: user.email, employeeId: user.employeeId });

    const resetToken = jwt.sign(
      { employeeId: user.employeeId, adminId: req.user.employeeId },
      process.env.JWT_SECRET,
      { expiresIn: '15m' }
    );

    await OTP.deleteOne({ email: storedOTP.email });
    console.log('OTP deleted for email:', email);

    res.status(200).json({ message: 'OTP verified', resetToken });
  } catch (error) {
    console.error('OTP verification error:', error);
    res.status(500).json({ message: 'Server error during OTP verification' });
  }
});

// Reset Password Route
app.post('/api/reset-password', verifyToken, isAdmin, async (req, res) => {
  try {
    const { employeeEmail, otp, newPassword } = req.body;
    console.log('Resetting password for email:', employeeEmail);

    if (!employeeEmail || !otp || !newPassword) {
      return res.status(400).json({ message: 'Employee email, OTP, and new password are required' });
    }

    const user = await User.findOne({ email: { $regex: `^${employeeEmail}$`, $options: 'i' } });
    if (!user) {
      console.log('User not found for email:', employeeEmail);
      return res.status(404).json({ message: 'User not found' });
    }
    console.log('User found for password reset:', { email: user.email, employeeId: user.employeeId });

    const storedOTP = await OTP.findOne({ email: { $regex: `^${employeeEmail}$`, $options: 'i' } });
    if (!storedOTP) {
      console.log('OTP not found for email:', employeeEmail);
      return res.status(400).json({ message: 'OTP not found or expired' });
    }

    if (storedOTP.expires < new Date()) {
      await OTP.deleteOne({ email: storedOTP.email });
      console.log('OTP expired for email:', employeeEmail);
      return res.status(400).json({ message: 'OTP expired' });
    }

    if (storedOTP.otp !== otp) {
      console.log('Invalid OTP for email:', employeeEmail);
      return res.status(400).json({ message: 'Invalid OTP' });
    }

    user.password = await bcrypt.hash(newPassword, 10);
    await user.save();
    console.log('Password updated for user:', user.email);

    await OTP.deleteOne({ email: storedOTP.email });
    console.log('OTP deleted for email:', employeeEmail);

    const confirmationEmailHtml = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #ddd; border-radius: 8px;">
        <h2 style="color: #003087; text-align: center;">Password Reset Successful</h2>
        <p>Your password has been successfully reset by an admin.</p>
        <p>If you did not request this, please contact support immediately.</p>
      </div>
    `;
    await sendEmail(user.email, 'Password Reset Confirmation', confirmationEmailHtml);
    console.log('Password reset confirmation email sent to:', user.email);

    res.status(200).json({ message: 'Password reset successful' });
  } catch (error) {
    console.error('Reset password error:', error);
    res.status(500).json({ message: 'Server error during password reset' });
  }
});

// Enhanced Email Template for Leave Requests
const generateEmailTemplate = (leaveRequest, employeeName, recipientRole) => {
  const { _id, employeeId, leaveType, fromDate, toDate, reason } = leaveRequest;
  const leaveTypeFormatted = leaveType.charAt(0).toUpperCase() + leaveType.slice(1) + ' Leave';
  let subject;
  if (recipientRole === 'employee') {
    subject = 'Your Leave Request Submission';
  } else if (recipientRole === 'manager') {
    subject = `New Leave Request from ${employeeName} (${employeeId})`;
  } else {
    subject = `Leave Request for Approval - ${employeeName} (${employeeId})`;
  }

  const html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Leave Request Notification</title>
      <style>
        body {
          font-family: 'Helvetica Neue', Arial, sans-serif;
          background-color: #f4f4f4;
          margin: 0;
          padding: 0;
        }
        .container {
          max-width: 600px;
          margin: 20px auto;
          background-color: #ffffff;
          border-radius: 12px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
          overflow: hidden;
        }
        .header {
          background: linear-gradient(90deg, #003087, #0059b3);
          padding: 30px;
          text-align: center;
        }
        .header h1 {
          color: #ffffff;
          margin: 0;
          font-size: 28px;
          font-weight: 700;
        }
        .content {
          padding: 30px;
        }
        .content h2 {
          color: #003087;
          font-size: 22px;
          margin-bottom: 20px;
          text-align: center;
        }
        .content p {
          color: #333333;
          font-size: 16px;
          line-height: 1.6;
          margin: 10px 0;
        }
        .details-table {
          width: 100%;
          border-collapse: collapse;
          margin: 20px 0;
          background-color: #f9f9f9;
          border-radius: 8px;
          overflow: hidden;
        }
        .details-table th,
        .details-table td {
          padding: 15px;
          text-align: left;
          border-bottom: 1px solid #e0e0e0;
        }
        .details-table th {
          background-color: #003087;
          color: #ffffff;
          width: 35%;
          font-weight: 600;
        }
        .details-table td {
          color: #333333;
        }
        .action-buttons {
          text-align: center;
          margin: 30px 0;
        }
        .action-buttons a {
          display: inline-block;
          padding: 12px 24px;
          margin: 0 10px;
          text-decoration: none;
          font-weight: 600;
          border-radius: 6px;
          transition: all 0.3s ease;
        }
        .approve-btn {
          background-color: #28a745;
          color: #ffffff;
        }
        .approve-btn:hover {
          background-color: #218838;
          transform: translateY(-2px);
        }
        .reject-btn {
          background-color: #dc3545;
          color: #ffffff;
        }
        .reject-btn:hover {
          background-color: #c82333;
          transform: translateY(-2px);
        }
        .action-text {
          color: #555555;
          font-size: 14px;
          margin-top: 15px;
          text-align: center;
        }
        .footer {
          background-color: #003087;
          padding: 15px;
          text-align: center;
        }
        .footer p {
          color: #ffffff;
          margin: 0;
          font-size: 12px;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Leave Request Notification</h1>
        </div>
        <div class="content">
          <h2>${
            recipientRole === 'employee'
              ? 'Your Leave Request Has Been Submitted'
              : recipientRole === 'manager'
              ? 'New Leave Request for Your Review'
              : 'New Leave Request for Approval'
          }</h2>
          <p>Dear ${recipientRole === 'employee' ? employeeName : recipientRole.charAt(0).toUpperCase() + recipientRole.slice(1)},</p>
          <p>${
            recipientRole === 'employee'
              ? 'Thank you for submitting your leave request. It has been sent for approval and you will be notified once reviewed.'
              : `A leave request from ${employeeName} (${employeeId}) awaits your approval.`
          }</p>
          <table class="details-table">
            <tr>
              <th>Employee ID</th>
              <td>${employeeId}</td>
            </tr>
            <tr>
              <th>Employee Name</th>
              <td>${employeeName}</td>
            </tr>
            <tr>
              <th>Leave Type</th>
              <td>${leaveTypeFormatted}</td>
            </tr>
            <tr>
              <th>From Date</th>
              <td>${fromDate}</td>
            </tr>
            <tr>
              <th>To Date</th>
              <td>${toDate}</td>
            </tr>
            <tr>
              <th>Reason</th>
              <td>${reason}</td>
            </tr>
          </table>
          ${
            recipientRole === 'manager'
              ? `
                <div class="action-buttons">
                  <a href="${process.env.APP_URL}/api/leave/update/${_id}?status=approved&token=${jwt.sign({ leaveId: _id }, process.env.JWT_SECRET, { expiresIn: '24h' })}" class="approve-btn">Approve</a>
                  <a href="${process.env.APP_URL}/api/leave/update/${_id}?status=rejected&token=${jwt.sign({ leaveId: _id }, process.env.JWT_SECRET, { expiresIn: '24h' })}" class="reject-btn">Reject</a>
                </div>
                <p class="action-text">Please review and approve or reject the leave request using the buttons above.</p>
              `
              : recipientRole !== 'employee'
              ? '<p class="action-text">Please review the request on your dashboard.</p>'
              : ''
          }
        </div>
        <div class="footer">
          <p>© 2025 Intellisurge Technologies. All Rights Reserved.</p>
        </div>
      </div>
    </body>
    </html>
  `;

  return { subject, html };
};

// WebSocket connection
io.on('connection', (socket) => {
  console.log('A user connected:', socket.id);

  socket.on('join', ({ employeeId, roleType }) => {
    socket.join(employeeId);
    if (roleType === 'Manager') {
      socket.join('managers');
    }
    console.log(`${employeeId} joined room`);
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

// Registration endpoint
// app.post('/api/register', async (req, res) => {
//   try {
//     const { initial, name, role, department, roleType, phoneNo, email, password } = req.body;

//     if (!initial || !name || !role || !department || !roleType || !phoneNo || !email || !password) {
//       return res.status(400).json({ message: 'All fields are required' });
//     }

//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//     if (!emailRegex.test(email)) {
//       return res.status(400).json({ message: 'Invalid email format' });
//     }

//     const phoneRegex = /^\d{10}$/;
//     if (!phoneRegex.test(phoneNo)) {
//       return res.status(400).json({ message: 'Phone number must be 10 digits' });
//     }

//     const existingUser = await User.findOne({ email });
//     if (existingUser) {
//       return res.status(400).json({ message: 'Email already registered' });
//     }

//     let prefix;
//     switch (roleType) {
//       case 'Employee':
//         prefix = 'E';
//         break;
//       case 'Manager':
//         prefix = 'M';
//         break;
//       case 'Admin':
//         prefix = 'A';
//         break;
//       default:
//         return res.status(400).json({ message: 'Invalid role type' });
//     }
//     const uniqueId = uuidv4().split('-')[0];
//     const employeeId = `${prefix}-${uniqueId}`;

//     const hashedPassword = await bcrypt.hash(password, 10);

//     const newUser = new User({
//       employeeId,
//       initial,
//       name,
//       role,
//       department,
//       roleType,
//       phoneNo,
//       email,
//       password: hashedPassword,
//       managerId: roleType === 'Employee' ? req.body.managerId || null : null,
//     });

//     await newUser.save();

//     res.status(201).json({ message: 'User registered successfully', employeeId });
//   } catch (error) {
//     console.error('Registration error:', error);
//     res.status(500).json({ message: 'Server error during registration' });
//   }
// });


// Registration endpoint
app.post('/api/register', async (req, res) => {
  try {
    const { initial, name, role, department, roleType, phoneNo, email, password } = req.body;

    if (!initial || !name || !role || !department || !roleType || !phoneNo || !email || !password) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ message: 'Invalid email format' });
    }

    const phoneRegex = /^\d{10}$/;
    if (!phoneRegex.test(phoneNo)) {
      return res.status(400).json({ message: 'Phone number must be 10 digits' });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    let prefix;
    switch (roleType) {
      case 'Employee':
        prefix = 'E';
        break;
      case 'Manager':
        prefix = 'M';
        break;
      case 'Admin':
        prefix = 'A';
        break;
      default:
        return res.status(400).json({ message: 'Invalid role type' });
    }
    const uniqueId = uuidv4().split('-')[0];
    const employeeId = `${prefix}-${uniqueId}`;

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
      employeeId,
      initial,
      name,
      role,
      department,
      roleType,
      phoneNo,
      email,
      password: hashedPassword,
    });

    await newUser.save();

    res.status(201).json({ message: 'User registered successfully', employeeId });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ message: 'Server error during registration' });
  }
});

// Login endpoint
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ message: 'Invalid email format' });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    const token = jwt.sign(
      {
        employeeId: user.employeeId,
        roleType: user.roleType,
        managerId: user.managerId || null,
      },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    res.status(200).json({
      message: 'Login successful',
      roleType: user.roleType,
      employeeId: user.employeeId,
      token,
      user: {
        employeeId: user.employeeId,
        initial: user.initial,
        name: user.name,
        role: user.role,
        department: user.department,
        roleType: user.roleType,
        phoneNo: user.phoneNo,
        email: user.email,
        managerId: user.managerId || null,
      },
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Server error during login' });
  }
});

// Add Task endpoint
// GET /api/tasks
app.get('/api/tasks', verifyToken, async (req, res) => {
  try {
    const tasks = await Task.find({ employeeId: req.user.employeeId });
    res.json({ tasks });
  } catch (error) {
    res.status(500).json({ message: 'Server error fetching tasks', error: error.message });
  }
});

// POST /api/tasks
app.post('/api/tasks', verifyToken, async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { employeeId, projectName, activityName, taskDescription, percentComplete, assignedBy } = req.body;
    if (!employeeId || !projectName || !activityName) {
      await session.abortTransaction();
      return res.status(400).json({ message: 'Employee ID, project name, and activity name are required' });
    }
    const task = new Task({
      employeeId,
      projectName: projectName.trim(),
      activityName: activityName.trim(),
      taskDescription: taskDescription ? taskDescription.trim() : '',
      percentComplete: parseFloat(percentComplete) || 0,
      assignedBy: assignedBy ? assignedBy.trim() : '',
    });
    await task.save({ session });
    await session.commitTransaction();
    res.status(201).json({ message: 'Task added successfully', task });
  } catch (error) {
    await session.abortTransaction();
    res.status(500).json({ message: 'Server error during task creation', error: error.message });
  } finally {
    session.endSession();
  }
});

// PUT /api/tasks
app.put('/api/tasks', verifyToken, async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { employeeId, projectName, activityName, percentComplete } = req.body;
    if (!employeeId || !projectName || !activityName || percentComplete === undefined) {
      await session.abortTransaction();
      return res.status(400).json({ message: 'Employee ID, project name, activity name, and percent complete are required' });
    }
    const newPercent = parseFloat(percentComplete);
    if (isNaN(newPercent) || newPercent < 0 || newPercent > 100) {
      await session.abortTransaction();
      return res.status(400).json({ message: 'Percent complete must be a number between 0 and 100' });
    }
    const task = await Task.findOneAndUpdate(
      { employeeId, projectName: projectName.trim(), activityName: activityName.trim() },
      { percentComplete: newPercent },
      { new: true, session }
    );
    if (!task) {
      await session.abortTransaction();
      return res.status(404).json({ message: 'Task not found' });
    }
    await session.commitTransaction();
    res.json({ message: 'Task updated successfully', task });
  } catch (error) {
    await session.abortTransaction();
    res.status(500).json({ message: 'Server error during task update', error: error.message });
  } finally {
    session.endSession();
  }
})




app.put('/api/user/:employeeId', verifyToken, async (req, res) => {
  try {
    const { employeeId } = req.params;
    const { name, phoneNo, email, role, department } = req.body;

    // Verify user is Admin or Manager and updating their own profile
    if (!['Admin', 'Manager'].includes(req.user.roleType) || req.user.employeeId !== employeeId) {
      return res.status(403).json({ message: 'Unauthorized to update this profile' });
    }

    // Validate input
    if (!name || !phoneNo || !email || !role || !department) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ message: 'Invalid email format' });
    }

    // Validate phone number (10 digits)
    const phoneRegex = /^\d{10}$/;
    if (!phoneRegex.test(phoneNo)) {
      return res.status(400).json({ message: 'Invalid phone number format' });
    }

    // Validate role (basic validation, adjust as needed)
    const validRoles = ['App developer', 'Web developer', 'Manager', 'Admin']; // Example roles
    if (!validRoles.includes(role)) {
      return res.status(400).json({ message: 'Invalid role' });
    }

    // Validate department (basic validation, adjust as needed)
    const validDepartments = ['IT', 'HR', 'Finance', 'Marketing']; // Example departments
    if (!validDepartments.includes(department)) {
      return res.status(400).json({ message: 'Invalid department' });
    }

    // Update user
    const updatedUser = await User.findOneAndUpdate(
      { employeeId },
      {
        name,
        phoneNo,
        email,
        role,
        department,
        initial: name.charAt(0).toUpperCase(),
      },
      { new: true, select: '-password' }
    );

    if (!updatedUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ user: updatedUser });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get Tasks endpoint
app.get('/api/tasks/:employeeId', verifyToken, async (req, res) => {
  try {
    const { employeeId } = req.params;

    const tasks = await Task.find({ employeeId });

    const tasksWithIST = tasks.map(task => ({
      ...task.toObject(),
      createdAt: moment(task.createdAt).tz('Asia/Kolkata').format('YYYY-MM-DD HH:mm:ss Z'),
    }));

    res.status(200).json({ tasks: tasksWithIST });
  } catch (error) {
    console.error('Task fetch error:', error);
    res.status(500).json({ message: 'Server error during task retrieval' });
  }
});



  app.put('/api/tasks/:taskId/percent', verifyToken, async (req, res) => {
    try {
      const { taskId } = req.params;
      const { percentComplete } = req.body;

      if (percentComplete === undefined || isNaN(percentComplete) || percentComplete < 0 || percentComplete > 100) {
        return res.status(400).json({ message: 'Invalid percent complete value' });
      }

      const task = await Task.findById(taskId);
      if (!task) {
        return res.status(404).json({ message: 'Task not found' });
      }

      if (task.employeeId !== req.user.employeeId) {
        return res.status(403).json({ message: 'Unauthorized to update this task' });
      }

      task.percentComplete = parseFloat(percentComplete);
      await task.save();

      res.status(200).json({ message: 'Task percentage updated successfully', task });
    } catch (error) {
      console.error('Update task percentage error:', error);
      res.status(500).json({ message: 'Server error during task percentage update' });
    }
  });
// Update Task Status endpoint
app.put('/api/tasks/:taskId', verifyToken, isManager, async (req, res) => {
  try {
    const { taskId } = req.params;
    const { status } = req.body;

    if (!['Approved', 'Rejected'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status. Must be Approved or Rejected' });
    }

    const task = await Task.findById(taskId);
    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    const manager = await User.findOne({ employeeId: req.user.employeeId });
    if (!manager.assignedEmployees.some(emp => emp.equals(task.employeeId))) {
      return res.status(403).json({ message: 'Task does not belong to an employee assigned to you' });
    }

    task.status = status;
    await task.save();

    res.status(200).json({ message: `Task ${status.toLowerCase()} successfully`, task });
  } catch (error) {
    console.error('Update task status error:', error);
    res.status(500).json({ message: 'Server error during task status update' });
  }
});

// Add/Update Timesheet endpoint
// Timesheet Endpoint



// Timesheet Endpoint - POST
app.post('/api/timesheet', verifyToken, async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { employeeId, projectName, activityName, weekStartDate, hours, loginTimes, logoutTimes } = req.body;

    console.log('Received timesheet request:', {
      employeeId,
      projectName,
      activityName,
      weekStartDate,
      hours,
      loginTimes,
      logoutTimes,
    });

    if (!employeeId || !projectName || !activityName || !weekStartDate) {
      await session.abortTransaction();
      return res.status(400).json({ message: 'Employee ID, project name, activity name, and week start date are required' });
    }

    const user = await User.findOne({ employeeId }).session(session);
    if (!user) {
      await session.abortTransaction();
      return res.status(400).json({ message: 'Invalid employee ID' });
    }

    const parsedWeekStartDate = moment(weekStartDate, 'YYYY-MM-DD').startOf('day').toDate();
    console.log('Parsed weekStartDate:', parsedWeekStartDate.toISOString());

    const isMonday = moment(parsedWeekStartDate).day() === 1;
    if (!isMonday) {
      console.warn('weekStartDate is not a Monday:', parsedWeekStartDate.toISOString());
      await session.abortTransaction();
      return res.status(400).json({ message: `weekStartDate is not a Monday: ${parsedWeekStartDate.toISOString()}` });
    }

    const existingTimesheet = await Timesheet.findOne({
      employeeId,
      projectName,
      activityName,
      weekStartDate: parsedWeekStartDate,
    }).session(session);

    if (existingTimesheet) {
      existingTimesheet.hours = hours || existingTimesheet.hours;
      existingTimesheet.loginTimes = loginTimes || existingTimesheet.loginTimes;
      existingTimesheet.logoutTimes = logoutTimes || existingTimesheet.logoutTimes;
      await existingTimesheet.save({ session });
      await session.commitTransaction();
      return res.json({ message: 'Timesheet updated successfully', timesheet: existingTimesheet });
    }

    const timesheet = new Timesheet({
      employeeId,
      projectName,
      activityName,
      weekStartDate: parsedWeekStartDate,
      hours: hours || Array(7).fill('00:00'),
      loginTimes: loginTimes || Array(7).fill(null),
      logoutTimes: logoutTimes || Array(7).fill(null),
    });

    await timesheet.save({ session });
    await session.commitTransaction();
    res.status(201).json({ message: 'Timesheet created successfully', timesheet });
  } catch (error) {
    await session.abortTransaction();
    console.error('Timesheet save error:', error);
    res.status(500).json({ message: 'Server error during timesheet save', error: error.message });
  } finally {
    session.endSession();
  }
});

// Timesheet Endpoint - GET
app.get('/api/timesheet', verifyToken, async (req, res) => {
  try {
    const { employeeId, weekStartDate, projectName, activityName } = req.query;

    if (!employeeId || !weekStartDate) {
      return res.status(400).json({ message: 'Employee ID and week start date are required' });
    }

    const parsedWeekStartDate = moment(weekStartDate, 'YYYY-MM-DD').startOf('day').toDate();
    if (!moment(parsedWeekStartDate).isValid()) {
      return res.status(400).json({ message: 'Invalid week start date format' });
    }

    const query = {
      employeeId,
      weekStartDate: parsedWeekStartDate,
    };

    if (projectName && activityName) {
      query.projectName = projectName;
      query.activityName = activityName;
    }

    const timesheets = await Timesheet.find(query);

    const timesheetsWithIST = timesheets.map(timesheet => ({
      ...timesheet.toObject(),
      createdAt: moment(timesheet.createdAt).tz('Asia/Kolkata').format('YYYY-MM-DD HH:mm:ss Z'),
      weekStartDate: moment(timesheet.weekStartDate).tz('Asia/Kolkata').format('YYYY-MM-DD'),
    }));

    res.status(200).json({ timesheets: timesheetsWithIST });
  } catch (error) {
    console.error('Timesheet fetch error:', error);
    res.status(500).json({ message: 'Server error during timesheet retrieval' });
  }
});


// Get Timesheet endpoint
app.get('/api/timesheet/:employeeId', verifyToken, async (req, res) => {
  try {
    const { employeeId } = req.params;

    const timesheets = await Timesheet.find({ employeeId });
    console.log('Fetched timesheets for employee:', employeeId, timesheets.map(t => ({
      _id: t._id,
      weekStartDate: t.weekStartDate.toISOString(),
      projectName: t.projectName,
      activityName: t.activityName,
      loginTimes: t.loginTimes,
    })));

    const timesheetsWithIST = timesheets.map(timesheet => ({
      ...timesheet.toObject(),
      createdAt: moment(timesheet.createdAt).tz('Asia/Kolkata').format('YYYY-MM-DD HH:mm:ss Z'),
      weekStartDate: moment(timesheet.weekStartDate).tz('Asia/Kolkata').format('YYYY-MM-DD'),
    }));

    res.status(200).json({ timesheets: timesheetsWithIST });
  } catch (error) {
    console.error('Timesheet fetch error:', error);
    res.status(500).json({ message: 'Server error during timesheet retrieval' });
  }
});

// Get all employee details (Admin only)
app.get('/api/admin/employees', verifyToken, isAdmin, async (req, res) => {
  try {
    const { page = 1, limit = 10, roleType, department } = req.query;
    let query = {};
    if (roleType) query.roleType = roleType;
    if (department) query.department = department;

    const employees = await User.find(query, { password: 0, __v: 0 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));
    const total = await User.countDocuments(query);

    const employeesWithIST = employees.map(employee => ({
      ...employee.toObject(),
      createdAt: moment(employee.createdAt).tz('Asia/Kolkata').format('YYYY-MM-DD HH:mm:ss Z'),
    }));

    res.status(200).json({
      message: 'Employee details retrieved successfully',
      employees: employeesWithIST,
      total,
      page: parseInt(page),
      pages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error('Fetch employees error:', error);
    res.status(500).json({ message: 'Server error during employee retrieval' });
  }
});

// Update employee (Admin only)
app.put('/api/admin/employees/:employeeId', verifyToken, isAdmin, async (req, res) => {
  try {
    const { employeeId } = req.params;
    const { initial, name, role, department, roleType, phoneNo, email, createdAt, address } = req.body;

    if (!initial || !name || !role || !department || !roleType || !phoneNo || !email) {
      return res.status(400).json({ message: 'All fields except address and createdAt are required' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ message: 'Invalid email format' });
    }

    const phoneRegex = /^\d{10}$/;
    if (!phoneNo || !phoneRegex.test(phoneNo)) {
      return res.status(400).json({ message: 'Phone number must be 10 digits' });
    }

    const prefix = roleType === 'Employee' ? 'E' : roleType === 'Manager' ? 'M' : 'A';
    if (!employeeId.startsWith(prefix)) {
      return res.status(400).json({ message: `Employee ID must start with '${prefix}'` });
    }

    const existingUser = await User.findOne({ email, employeeId: { $ne: employeeId } });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    const updatedUser = await User.findOneAndUpdate(
      { employeeId },
      {
        initial,
        name,
        role,
        department,
        roleType,
        phoneNo,
        email,
        address,
        createdAt: createdAt ? moment.tz(createdAt, 'Asia/Kolkata').toDate() : undefined,
      },
      { new: true, runValidators: true, select: '-password -__v' }
    );

    if (!updatedUser) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    const updatedUserResponse = {
      ...updatedUser.toObject(),
      createdAt: moment(updatedUser.createdAt).tz('Asia/Kolkata').format('YYYY-MM-DD HH:mm:ss Z'),
    };

    res.status(200).json({ message: 'Employee updated successfully', employee: updatedUserResponse });
  } catch (error) {
    console.error('Update employee error:', error);
    res.status(500).json({ message: 'Server error during employee update' });
  }
});

// Delete employee (Admin only)
app.delete('/api/admin/employees/:employeeId', verifyToken, isAdmin, async (req, res) => {
  try {
    const { employeeId } = req.params;

    const deletedUser = await User.findOneAndDelete({ employeeId });
    if (!deletedUser) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    await Task.deleteMany({ employeeId });
    await Timesheet.deleteMany({ employeeId });
    await Assignment.deleteMany({ $or: [{ employeeId: deletedUser._id }, { managerId: employeeId }] });
    await LeaveRequest.deleteMany({ employeeId });

    res.status(200).json({ message: 'Employee deleted successfully' });
  } catch (error) {
    console.error('Delete employee error:', error);
    res.status(500).json({ message: 'Server error during employee deletion' });
  }
});

// Assign employee to manager (Admin only)
app.post('/api/admin/assign-employee', verifyToken, isAdmin, async (req, res) => {
  try {
    const { employeeId, managerId } = req.body;

    if (!employeeId || !managerId) {
      return res.status(400).json({ message: 'Employee ID and Manager ID are required' });
    }

    const employee = await User.findOne({ employeeId, roleType: 'Employee' });
    if (!employee) {
      return res.status(404).json({ message: 'Employee not found or invalid role type' });
    }

    const manager = await User.findOne({ employeeId: managerId, roleType: 'Manager' });
    if (!manager) {
      return res.status(404).json({ message: 'Manager not found or invalid role type' });
    }

    const admin = await User.findOne({ employeeId: req.user.employeeId });
    if (!admin) {
      return res.status(404).json({ message: 'Admin not found' });
    }

    const existingAssignment = await Assignment.findOne({ employeeId: employee._id, managerId, status: 'Pending' });
    if (existingAssignment) {
      return res.status(400).json({ message: 'Employee is already assigned to this manager and pending approval' });
    }

    const assignment = new Assignment({
      employeeId: employee._id,
      managerId,
      assignedBy: admin._id,
      status: 'Pending',
      createdAt: moment().tz('Asia/Kolkata').toDate(),
    });

    await assignment.save();

    await User.findOneAndUpdate(
      { employeeId },
      { managerId },
      { new: true }
    );

    res.status(201).json({ message: 'Employee assigned to manager successfully', assignment });
  } catch (error) {
    console.error('Assign employee error:', error);
    res.status(500).json({ message: 'Server error during employee assignment' });
  }
});

// Get pending assignments for a manager
app.get('/api/manager/assignments', verifyToken, async (req, res) => {
  try {
    const { employeeId, roleType } = req.user;

    if (roleType !== 'Manager') {
      return res.status(403).json({ message: 'Access denied: Managers only' });
    }

    const assignments = await Assignment.find({ managerId: employeeId, status: 'Pending' })
      .populate('employeeId', 'name initial employeeId email')
      .populate('assignedBy', 'name employeeId');

    const assignmentsWithIST = assignments.map(assignment => ({
      ...assignment.toObject(),
      createdAt: moment(assignment.createdAt).tz('Asia/Kolkata').format('YYYY-MM-DD HH:mm:ss Z'),
    }));

    res.status(200).json({ assignments: assignmentsWithIST });
  } catch (error) {
    console.error('Fetch assignments error:', error);
    res.status(500).json({ message: 'Server error during assignments retrieval' });
  }
});

// Accept or reject assignment (Manager only)
app.put('/api/manager/assignments/:assignmentId', verifyToken, async (req, res) => {
  try {
    const { assignmentId } = req.params;
    const { status } = req.body;
    const { employeeId, roleType } = req.user;

    if (roleType !== 'Manager') {
      return res.status(403).json({ message: 'Access denied: Managers only' });
    }

    if (!['Accepted', 'Rejected'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status. Must be Accepted or Rejected' });
    }

    const assignment = await Assignment.findOne({ _id: assignmentId, managerId: employeeId });
    if (!assignment) {
      return res.status(404).json({ message: 'Assignment not found or you are not authorized' });
    }

    assignment.status = status;
    await assignment.save();

    if (status === 'Accepted') {
      await User.findOneAndUpdate(
        { employeeId: assignment.managerId },
        { $addToSet: { assignedEmployees: assignment.employeeId } },
        { new: true }
      );
    }

    const assignmentResponse = {
      ...assignment.toObject(),
      createdAt: moment(assignment.createdAt).tz('Asia/Kolkata').format('YYYY-MM-DD HH:mm:ss Z'),
    };

    res.status(200).json({ message: `Assignment ${status.toLowerCase()} successfully`, assignment: assignmentResponse });
  } catch (error) {
    console.error('Update assignment error:', error);
    res.status(500).json({ message: 'Server error during assignment update' });
  }
});

// Get assigned employees for a manager
app.get('/api/manager/employees', verifyToken, async (req, res) => {
  try {
    const { employeeId, roleType } = req.user;

    if (roleType !== 'Manager') {
      return res.status(403).json({ message: 'Access denied: Managers only' });
    }

    const manager = await User.findOne({ employeeId }).populate('assignedEmployees', 'name initial employeeId email department role');
    if (!manager) {
      return res.status(404).json({ message: 'Manager not found' });
    }

    const employeesWithIST = manager.assignedEmployees.map(employee => ({
      ...employee.toObject(),
      createdAt: moment(employee.createdAt).tz('Asia/Kolkata').format('YYYY-MM-DD HH:mm:ss Z'),
    }));

    res.status(200).json({ employees: employeesWithIST });
  } catch (error) {
    console.error('Fetch assigned employees error:', error);
    res.status(500).json({ message: 'Server error during assigned employees retrieval' });
  }
});

// Get attendance report for a manager's assigned employees
  app.get('/api/manager/attendance', verifyToken, isManager, async (req, res) => {
    try {
      const { employeeId } = req.user;
      const today = moment().tz('Asia/Kolkata').format('YYYY-MM-DD');

      // Find the manager and populate assigned employees
      const manager = await User.findOne({ employeeId }).populate('assignedEmployees', 'name employeeId');
      if (!manager) {
        return res.status(404).json({ message: 'Manager not found' });
      }

      const employeeIds = manager.assignedEmployees.map(emp => emp.employeeId);
      if (employeeIds.length === 0) {
        return res.status(200).json({ attendance: [] });
      }

      // Find timesheets for the employees, filtering for the current week
      const weekStart = moment().tz('Asia/Kolkata').startOf('isoWeek').format('YYYY-MM-DD');
      const timesheets = await Timesheet.find({
        employeeId: { $in: employeeIds },
        weekStartDate: weekStart,
      });

      const attendance = [];
      for (const timesheet of timesheets) {
        const employee = manager.assignedEmployees.find(emp => emp.employeeId === timesheet.employeeId);
        const weekStartDate = moment(timesheet.weekStartDate).tz('Asia/Kolkata');
        
        // Calculate the day index for today relative to weekStartDate
        const dayIndex = moment(today).diff(weekStartDate, 'days');
        
        // Only include today's attendance
        if (dayIndex >= 0 && dayIndex < 7) {
          const loginTime = timesheet.loginTimes[dayIndex] || 'N/A';
          const logoutTime = timesheet.logoutTimes[dayIndex] || 'N/A';
          const status = loginTime !== 'N/A' ? 'Present' : 'Absent';

          attendance.push({
            employeeId: timesheet.employeeId,
            name: employee.name,
            date: today,
            checkInTime: loginTime,
            checkOutTime: logoutTime,
            status,
          });
        }
      }

      res.status(200).json({ attendance });
    } catch (error) {
      console.error('Fetch attendance error:', error);
      res.status(500).json({ message: 'Server error during attendance retrieval', error: error.message });
    }
  });

// Get attendance report for an employee
app.get('/api/employee/attendance', verifyToken, isEmployee, async (req, res) => {
  try {
    const { employeeId } = req.user;

    const timesheets = await Timesheet.find({ employeeId });

    const attendance = [];
    for (const timesheet of timesheets) {
      const weekStartDate = moment(timesheet.weekStartDate).tz('Asia/Kolkata');

      for (let day = 0; day < 7; day++) {
        const currentDate = moment(weekStartDate).add(day, 'days');
        const loginTime = timesheet.loginTimes[day];
        const logoutTime = timesheet.logoutTimes[day];

        let totalWorkedTime = 'N/A';
        if (loginTime && logoutTime) {
          const login = moment.tz(`2025-06-17 ${loginTime}`, 'YYYY-MM-DD HH:mm', 'Asia/Kolkata');
          const logout = moment.tz(`2025-06-17 ${logoutTime}`, 'YYYY-MM-DD HH:mm', 'Asia/Kolkata');
          const hoursWorked = logout.diff(login, 'hours', true);
          totalWorkedTime = `${hoursWorked.toFixed(2)} hrs`;
        }

        if (loginTime || logoutTime) {
          attendance.push({
            date: currentDate.format('YYYY-MM-DD'),
            login: loginTime || 'N/A',
            logout: logoutTime || 'N/A',
            totalWorkedTime,
          });
        }
      }
    }

    res.status(200).json({ attendance });
  } catch (error) {
    console.error('Fetch employee attendance error:', error);
    res.status(500).json({ message: 'Server error during employee attendance retrieval' });
  }
});

// Get user details by employeeId
app.get('/api/user/:employeeId', verifyToken, async (req, res) => {
  try {
    const { employeeId } = req.params;

    const user = await User.findOne({ employeeId }, { password: 0, __v: 0 });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const userResponse = {
      ...user.toObject(),
      createdAt: moment(user.createdAt).tz('Asia/Kolkata').format('YYYY-MM-DD HH:mm:ss Z'),
    };

    res.status(200).json({ user: userResponse });
  } catch (error) {
    console.error('Fetch user error:', error);
    res.status(500).json({ message: 'Server error during user retrieval' });
  }
});




// Submit Leave Request (Employee only)
app.post('/api/leave/apply', verifyToken, isEmployee, async (req, res) => {
  try {
    const { employeeId, leaveType, fromDate, toDate, reason, status } = req.body;

    if (!employeeId || !leaveType || !fromDate || !toDate || !reason) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    if (!['sick', 'casual', 'emergency'].includes(leaveType)) {
      return res.status(400).json({ message: 'Invalid leave type. Must be sick, casual, or emergency' });
    }

    const dateRegex = /^\d{2}-\d{2}-\d{4}$/;
    if (!dateRegex.test(fromDate) || !dateRegex.test(toDate)) {
      return res.status(400).json({ message: 'Dates must be in DD-MM-YYYY format' });
    }

    const fromDateObj = moment(fromDate, 'DD-MM-YYYY').tz('Asia/Kolkata');
    const toDateObj = moment(toDate, 'DD-MM-YYYY').tz('Asia/Kolkata');
    if (fromDateObj.isAfter(toDateObj)) {
      return res.status(400).json({ message: 'From date cannot be later than to date' });
    }

    const employee = await User.findOne({ employeeId });
    if (!employee) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    let manager = null;
    if (employee.managerId) {
      manager = await User.findOne({ employeeId: employee.managerId });
      if (!manager) {
        return res.status(404).json({ message: 'Manager not found' });
      }
    }

    const leaveRequest = new LeaveRequest({
      employeeId,
      employeeName: employee.name,
      leaveType,
      fromDate,
      toDate,
      reason,
      status: status || 'pending',
      createdAt: moment().tz('Asia/Kolkata').toDate(),
    });
    await leaveRequest.save();

    const employeeEmail = generateEmailTemplate(leaveRequest, employee.name, 'employee');
    const adminEmail = generateEmailTemplate(leaveRequest, employee.name, 'admin');
    const emails = [
      {
        from: process.env.EMAIL_USER,
        to: employee.email,
        subject: employeeEmail.subject,
        html: employeeEmail.html,
      },
      {
        from: process.env.EMAIL_USER,
        to: process.env.ADMIN_EMAIL || 'admin@company.com',
        subject: adminEmail.subject,
        html: adminEmail.html,
      },
    ];

    if (manager) {
      const managerEmail = generateEmailTemplate(leaveRequest, employee.name, 'manager');
      emails.push({
        from: process.env.EMAIL_USER,
        to: manager.email,
        subject: managerEmail.subject,
        html: managerEmail.html,
      });
    }

    await Promise.all(emails.map(email => transporter.sendMail(email)));

    io.to('managers').emit('newLeaveRequest', {
      leaveId: leaveRequest._id,
      employeeId,
      employeeName: employee.name,
      leaveType,
      fromDate,
      toDate,
      reason,
      status: 'pending',
      createdAt: moment(leaveRequest.createdAt).tz('Asia/Kolkata').format('YYYY-MM-DD HH:mm:ss Z'),
    });

    const leaveRequestResponse = {
      ...leaveRequest.toObject(),
      createdAt: moment(leaveRequest.createdAt).tz('Asia/Kolkata').format('YYYY-MM-DD HH:mm:ss Z'),
    };

    res.status(201).json({ message: 'Leave request submitted successfully', leaveRequest: leaveRequestResponse });
  } catch (error) {
    console.error('Submit leave request error:', error);
    res.status(500).json({ message: 'Server error during leave request submission' });
  }
});

// Approve or Reject Leave Request via GET (for email links, Manager or Admin only)
app.get('/api/leave/update/:leaveId', verifyToken, isManagerOrAdmin, async (req, res) => {
  try {
    const { leaveId } = req.params;
    const { status } = req.query;
    const { employeeId, roleType } = req.user;

    if (!['approved', 'rejected'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status. Must be approved or rejected' });
    }

    const leaveRequest = await LeaveRequest.findById(leaveId);
    if (!leaveRequest) {
      return res.status(404).json({ message: 'Leave request not found' });
    }

    if (roleType === 'Manager') {
      const manager = await User.findOne({ employeeId }).populate('assignedEmployees', 'employeeId');
      if (!manager) {
        return res.status(404).json({ message: 'Manager not found' });
      }
      const employeeIds = manager.assignedEmployees.map(emp => emp.employeeId);
      if (!employeeIds.includes(leaveRequest.employeeId)) {
        return res.status(403).json({ message: 'You are not authorized to review this leave request' });
      }
    }

    leaveRequest.status = status;
    leaveRequest.reviewedBy = employeeId;
    leaveRequest.reviewedAt = new Date();
    await leaveRequest.save();

    const employee = await User.findOne({ employeeId: leaveRequest.employeeId });
    if (!employee) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    const statusEmail = {
      subject: `Leave Request ${status.charAt(0).toUpperCase() + status.slice(1)}`,
      html: `
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Leave Request Status Update</title>
          <style>
            body {
              font-family: 'Helvetica Neue', Arial, sans-serif;
              background-color: #f4f4f4;
              margin: 0;
              padding: 0;
            }
            .container {
              max-width: 600px;
              margin: 20px auto;
              background-color: #ffffff;
              border-radius: 12px;
              box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
              overflow: hidden;
            }
            .header {
              background: linear-gradient(90deg, #003087, #0059b3);
              padding: 30px;
              text-align: center;
            }
            .header h1 {
              color: #ffffff;
              margin: 0;
              font-size: 28px;
              font-weight: 700;
            }
            .content {
              padding: 30px;
            }
            .content h2 {
              color: #003087;
              font-size: 22px;
              margin-bottom: 20px;
              text-align: center;
            }
            .content p {
              color: #333333;
              font-size: 16px;
              line-height: 1.6;
              margin: 10px 0;
            }
            .details-table {
              width: 100%;
              border-collapse: collapse;
              margin: 20px 0;
              background-color: #f9f9f9;
              border-radius: 8px;
              overflow: hidden;
            }
            .details-table th,
            .details-table td {
              padding: 15px;
              text-align: left;
              border-bottom: 1px solid #e0e0e0;
            }
            .details-table th {
              background-color: #003087;
              color: #ffffff;
              width: 35%;
              font-weight: 600;
            }
            .details-table td {
              color: #333333;
            }
            .footer {
              background-color: #003087;
              padding: 15px;
              text-align: center;
            }
            .footer p {
              color: #ffffff;
              margin: 0;
              font-size: 12px;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Leave Request Status Update</h1>
            </div>
            <div class="content">
              <h2>Your Leave Request Has Been ${status.charAt(0).toUpperCase() + status.slice(1)}</h2>
              <p>Dear ${employee.name},</p>
              <p>Your leave request has been ${status} by ${roleType} (${employeeId}).</p>
              <table class="details-table">
                <tr>
                  <th>Leave Type</th>
                  <td>${leaveRequest.leaveType.charAt(0).toUpperCase() + leaveRequest.leaveType.slice(1)} Leave</td>
                </tr>
                <tr>
                  <th>From Date</th>
                  <td>${leaveRequest.fromDate}</td>
                </tr>
                <tr>
                  <th>To Date</th>
                  <td>${leaveRequest.toDate}</td>
                </tr>
                <tr>
                  <th>Reason</th>
                  <td>${leaveRequest.reason}</td>
                </tr>
              </table>
            </div>
            <div class="footer">
              <p>© 2025 Intellisurge Technologies. All Rights Reserved.</p>
            </div>
          </div>
        </body>
        </html>
      `,
    };

    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: employee.email,
      subject: statusEmail.subject,
      html: statusEmail.html,
    });

    io.to(leaveRequest.employeeId).emit('leaveStatusUpdate', {
      leaveId,
      status,
      reviewedBy: employeeId,
      reviewedAt: new Date(),
    });
    io.to('managers').emit('leaveStatusUpdate', {
      leaveId,
      status,
      employeeId: leaveRequest.employeeId,
      reviewedBy: employeeId,
      reviewedAt: new Date(),
    });

    const redirectUrl = `${process.env.APP_URL}/leave-decisions?leaveId=${leaveId}&status=${status}&employeeId=${employeeId}`;
    res.redirect(redirectUrl);
  } catch (error) {
    console.error('Update leave request error:', error);
    res.status(500).send(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Error</title>
        <style>
          body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
          }
          .container {
            max-width: 600px;
            background-color: #ffffff;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
          }
          .header h1 {
            color: #333333;
            font-size: 24px;
            margin-bottom: 20px;
          }
          p {
            color: #555555;
            font-size: 16px;
            margin-bottom: 20px;
          }
          a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #003087;
            color: #ffffff;
            text-decoration: none;
            border-radius: 4px;
            font-weight: 600;
          }
          a:hover {
            background-color: #002343;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Error Updating Leave Request</h1>
          </div>
          <p>An error occurred: ${error.message}</p>
          <a href="${process.env.APP_URL}/dashboard">Return to Dashboard</a>
        </div>
      </body>
      </html>
    `);
  }
});

// Approve or Reject Leave Request via PUT (for frontend API calls, Manager or Admin only)
app.put('/api/leave/update/:leaveId', verifyToken, isManagerOrAdmin, async (req, res) => {
  try {
    const { leaveId } = req.params;
    const { status } = req.body;
    const { employeeId, roleType } = req.user;

    if (!['approved', 'rejected'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status. Must be approved or rejected' });
    }

    const leaveRequest = await LeaveRequest.findById(leaveId);
    if (!leaveRequest) {
      return res.status(404).json({ message: 'Leave request not found' });
    }

    if (roleType === 'Manager') {
      const manager = await User.findOne({ employeeId }).populate('assignedEmployees', 'employeeId');
      if (!manager) {
        return res.status(404).json({ message: 'Manager not found' });
      }
      const employeeIds = manager.assignedEmployees.map(emp => emp.employeeId);
      if (!employeeIds.includes(leaveRequest.employeeId)) {
        return res.status(403).json({ message: 'You are not authorized to review this leave request' });
      }
    }

    leaveRequest.status = status;
    leaveRequest.reviewedBy = employeeId;
    leaveRequest.reviewedAt = new Date();
    await leaveRequest.save();

    const employee = await User.findOne({ employeeId: leaveRequest.employeeId });
    if (!employee) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    const statusEmail = {
      subject: `Leave Request ${status.charAt(0).toUpperCase() + status.slice(1)}`,
      html: `
        <!DOCTYPE html>
        <html lang="en">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Leave Request Status Update</title>
          <style>
            body {
              font-family: 'Helvetica Neue', Arial, sans-serif;
              background-color: #f4f4f4;
              margin: 0;
              padding: 0;
            }
            .container {
              max-width: 600px;
              margin: 20px auto;
              background-color: #ffffff;
              border-radius: 12px;
              box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
              overflow: hidden;
            }
            .header {
              background: linear-gradient(90deg, #003087, #0059b3);
              padding: 30px;
              text-align: center;
            }
            .header h1 {
              color: #ffffff;
              margin: 0;
              font-size: 28px;
              font-weight: 700;
            }
            .content {
              padding: 30px;
            }
            .content h2 {
              color: #003087;
              font-size: 22px;
              margin-bottom: 20px;
              text-align: center;
            }
            .content p {
              color: #333333;
              font-size: 16px;
              line-height: 1.6;
              margin: 10px 0;
            }
            .details-table {
              width: 100%;
              border-collapse: collapse;
              margin: 20px 0;
              background-color: #f9f9f9;
              border-radius: 8px;
              overflow: hidden;
            }
            .details-table th,
            .details-table td {
              padding: 15px;
              text-align: left;
              border-bottom: 1px solid #e0e0e0;
            }
            .details-table th {
              background-color: #003087;
              color: #ffffff;
              width: 35%;
              font-weight: 600;
            }
            .details-table td {
              color: #333333;
            }
            .footer {
              background-color: #003087;
              padding: 15px;
              text-align: center;
            }
            .footer p {
              color: #ffffff;
              margin: 0;
              font-size: 12px;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Leave Request Status Update</h1>
            </div>
            <div class="content">
              <h2>Your Leave Request Has Been ${status.charAt(0).toUpperCase() + status.slice(1)}</h2>
              <p>Dear ${employee.name},</p>
              <p>Your leave request has been ${status} by ${roleType} (${employeeId}).</p>
              <table class="details-table">
                <tr>
                  <th>Leave Type</th>
                  <td>${leaveRequest.leaveType.charAt(0).toUpperCase() + leaveRequest.leaveType.slice(1)} Leave</td>
                </tr>
                <tr>
                  <th>From Date</th>
                  <td>${leaveRequest.fromDate}</td>
                </tr>
                <tr>
                  <th>To Date</th>
                  <td>${leaveRequest.toDate}</td>
                </tr>
                <tr>
                  <th>Reason</th>
                  <td>${leaveRequest.reason}</td>
                </tr>
              </table>
            </div>
            <div class="footer">
              <p>© 2025 Intellisurge Technologies. All Rights Reserved.</p>
            </div>
          </div>
        </body>
        </html>
      `,
    };

    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: employee.email,
      subject: statusEmail.subject,
      html: statusEmail.html,
    });

    io.to(leaveRequest.employeeId).emit('leaveStatusUpdate', {
      leaveId,
      status,
      reviewedBy: employeeId,
      reviewedAt: new Date(),
    });
    io.to('managers').emit('leaveStatusUpdate', {
      leaveId,
      status,
      employeeId: leaveRequest.employeeId,
      reviewedBy: employeeId,
      reviewedAt: new Date(),
    });

    res.status(200).json({
      message: `Leave request ${status} successfully`,
      leaveRequest: {
        _id: leaveRequest._id,
        employeeId: leaveRequest.employeeId,
        employeeName: leaveRequest.employeeName,
        leaveType: leaveRequest.leaveType,
        fromDate: leaveRequest.fromDate,
        toDate: leaveRequest.toDate,
        reason: leaveRequest.reason,
        status: leaveRequest.status,
        reviewedBy: leaveRequest.reviewedBy,
        reviewedAt: leaveRequest.reviewedAt,
        createdAt: leaveRequest.createdAt,
      },
    });
  } catch (error) {
    console.error('Update leave request error:', error);
    res.status(500).json({ message: `Server error during leave request update: ${error.message}` });
  }
});


// Get Pending Leave Requests (Manager or Admin only)
app.get('/api/leave/pending', verifyToken, isManagerOrAdmin, async (req, res) => {
  try {
    const { employeeId, roleType } = req.user;
    let leaveRequests = [];

    if (roleType === 'Manager') {
      const manager = await User.findOne({ employeeId }).populate('assignedEmployees', 'employeeId');
      if (!manager) {
        return res.status(404).json({ message: 'Manager not found' });
      }

      const employeeIds = manager.assignedEmployees.map(emp => emp.employeeId);
      if (employeeIds.length === 0) {
        return res.status(200).json({ leaveRequests: [] });
      }

      leaveRequests = await LeaveRequest.find({
        employeeId: { $in: employeeIds },
        status: 'pending',
      });
    } else if (roleType === 'Admin') {
      leaveRequests = await LeaveRequest.find({ status: 'pending' });
    }

    res.status(200).json({ leaveRequests });
  } catch (error) {
    console.error('Fetch pending leave requests error:', error);
    res.status(500).json({ message: 'Server error during pending leave requests retrieval' });
  }
});

// Get Leave Requests for an Employee (Employee only)
app.get('/api/leave/status', verifyToken, isEmployee, async (req, res) => {
  try {
    const { employeeId } = req.user;

    const leaveRequests = await LeaveRequest.find({ employeeId });

    res.status(200).json({ leaveRequests });
  } catch (error) {
    console.error('Fetch leave status error:', error);
    res.status(500).json({ message: 'Server error during leave status retrieval' });
  }
});

// Health Check Endpoint
app.get('/api/health', async (req, res) => {
  try {
    const mongoStatus = mongoose.connection.readyState === 1 ? 'Connected' : 'Disconnected';
    const serverStartTime = new Date().toLocaleString();

    const html = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Server Health Check</title>
        <style>
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #333;
          }
          .container {
            max-width: 600px;
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
            padding: 40px;
            text-align: center;
            animation: fadeIn 1s ease-in-out;
          }
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
          }
          .header {
            margin-bottom: 20px;
          }
          .header h1 {
            color: #1e3c72;
            font-size: 32px;
            margin: 0;
            text-transform: uppercase;
            letter-spacing: 1px;
          }
          .status-box {
            background-color: #f4f7fc;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            border: 1px solid #e0e0e0;
          }
          .status-box p {
            margin: 10px 0;
            font-size: 18px;
            color: #333;
          }
          .status-success {
            color: #28a745;
            font-weight: bold;
          }
          .status-error {
            color: #dc3545;
            font-weight: bold;
          }
          .footer {
            margin-top: 30px;
            font-size: 14px;
            color: #666;
          }
          .footer a {
            color: #1e3c72;
            text-decoration: none;
            font-weight: bold;
          }
          .footer a:hover {
            text-decoration: underline;
          }
          .icon {
            font-size: 50px;
            margin-bottom: 20px;
            color: #28a745;
          }
          @media (max-width: 600px) {
            .container {
              margin: 20px;
              padding: 20px;
            }
            .header h1 {
              font-size: 24px;
            }
            .status-box p {
              font-size: 16px;
            }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Server Health Check</h1>
          </div>
          <div class="icon">✅</div>
          <div class="status-box">
            <p><strong>Server Status:</strong> <span class="status-success">Running</span></p>
            <p><strong>Server Started At:</strong> ${serverStartTime}</p>
            <p><strong>MongoDB Connection:</strong> <span class="${
              mongoStatus === 'Connected' ? 'status-success' : 'status-error'
            }">${mongoStatus}</span></p>
            <p><strong>Environment:</strong> ${process.env.NODE_ENV || 'Production'}</p>
            <p><strong>Port:</strong> ${PORT}</p>
          </div>
          <div class="footer">
            <p>© 2025 Intellisurge Technologies. All Rights Reserved.</p>
            <p><a href="${process.env.APP_URL}/dashboard">Go to Dashboard</a></p>
          </div>
        </div>
      </body>
      </html>
    `;

    res.status(200).send(html);
  } catch (error) {
    console.error('Health check error:', error);
    res.status(500).send(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Server Health Check</title>
        <style>
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #333;
          }
          .container {
            max-width: 600px;
            background-color: #ffffff;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
            padding: 40px;
            text-align: center;
          }
          .header h1 {
            color: #dc3545;
            font-size: 32px;
            margin: 0;
          }
          .icon {
            font-size: 50px;
            margin-bottom: 20px;
            color: #dc3545;
          }
          p {
            font-size: 18px;
            color: #333;
            margin: 10px 0;
          }
          a {
            color: #1e3c72;
            text-decoration: none;
            font-weight: bold;
          }
          a:hover {
            text-decoration: underline;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>Server Error</h1>
          </div>
          <div class="icon">❌</div>
          <p>Server Status: <span style="color: #dc3545;">Not Running Properly</span></p>
          <p>Error: ${error.message}</p>
          <p><a href="${process.env.APP_URL}/dashboard">Go to Dashboard</a></p>
        </div>
      </body>
      </html>
    `);
  }
});

server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});