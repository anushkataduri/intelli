const mongoose = require('mongoose');

const leaveRequestSchema = new mongoose.Schema({
  employeeId: { type: String, required: true },
  employeeName: { type: String, required: true },
  leaveType: { type: String, enum: ['sick', 'casual', 'emergency'], required: true },
  fromDate: { type: String, required: true },
  toDate: { type: String, required: true },
  reason: { type: String, required: true },
  status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
  reviewedBy: { type: String },
  reviewedAt: { type: Date },
  createdAt: {
    type: Date,
    default: () => require('moment-timezone')().tz('Asia/Kolkata').toDate(),
  },
});

module.exports = mongoose.model('LeaveRequest', leaveRequestSchema);