const mongoose = require('mongoose');

const assignmentSchema = new mongoose.Schema({
  employeeId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  managerId: { type: String, required: true },
  assignedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  status: { type: String, enum: ['Pending', 'Accepted', 'Rejected'], default: 'Pending' },
  createdAt: {
    type: Date,
    default: () => require('moment-timezone')().tz('Asia/Kolkata').toDate(),
  },
});

module.exports = mongoose.model('Assignment', assignmentSchema);